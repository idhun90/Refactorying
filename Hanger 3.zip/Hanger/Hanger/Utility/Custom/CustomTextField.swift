import UIKit

final class CustomTextField: UITextField {
    
    override init(frame: CGRect) {
        super .init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func configureUI(placeholder: String?, fontSize: CGFloat) {
        leftView = UIView(frame: CGRect(x: 0, y: 0, width: 20, height: 0))
        leftViewMode = .always
        self.placeholder = placeholder
        font = .systemFont(ofSize: fontSize)
        borderStyle = .none
        clearButtonMode = .whileEditing
    }
}
