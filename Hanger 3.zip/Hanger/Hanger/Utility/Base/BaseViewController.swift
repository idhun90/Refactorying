import UIKit

class BaseViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        configureUI()
        setConstraints()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //navigationController?.isToolbarHidden = true
        //navigationController?.setToolbarHidden(true, animated: false)
    }
    
    func configureUI() { }
    func setConstraints() { }
}
