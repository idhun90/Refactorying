//
//  BackupAndRestoreView.swift
//  Hanger
//
//  Created by 이도헌 on 2022/10/22.
//

enum BackupRestoreSection {
    case main
    
    var item: [String] {
        switch self {
        case .main:
            return ["백업", "복원"]
        }
    }
    
    static let footer = "앱을 재설치하거나 또는 기기를 잃어버렸거나 새로운 기기로 교체할 때 사용자의 데이터를 복원할 수 있습니다.\n\n생성된 백업 파일을 '파일'앱 > 'iCloud Drive' 또는 외부 위치에 저장하세요.\n"//\n\n백업 파일명은 변경하지 마시기 바랍니다."
}

import UIKit

import Zip

final class BackupAndRestoreViewController: BaseViewController {
    
    private let mainView = BackupAndRestoreView()
    
    private var dataSource: UICollectionViewDiffableDataSource<BackupRestoreSection, String>!
    
    override func loadView() {
        view = mainView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupNavigation()
        configureDataSource()
        mainView.collectionView.delegate = self
        isModalInPresentation = true // 화면 내려짐 방지
    }
    
    private func setupNavigation() {
        navigationItem.title = "백업 및 복원"
        navigationItem.largeTitleDisplayMode = .never
    }
}

// MARK: - CollectionView
extension BackupAndRestoreViewController {
    
    private func configureDataSource() {
        
        let cellRegistration = UICollectionView.CellRegistration<UICollectionViewListCell, String> { cell, indexPath, itemIdentifier in
            
            var content = UIListContentConfiguration.valueCell()
            content.text = itemIdentifier
            cell.contentConfiguration = content
            cell.accessories = [.disclosureIndicator()]
            
            var backgroundContent = UIBackgroundConfiguration.listPlainCell()
            backgroundContent.backgroundColor = .customCellBackgroundColor
            cell.backgroundConfiguration = backgroundContent
            
        }
        
        let footerRegistration = UICollectionView.SupplementaryRegistration<UICollectionViewListCell>(elementKind: UICollectionView.elementKindSectionFooter) { supplementaryView, elementKind, indexPath in
            var content = UIListContentConfiguration.groupedFooter()
            content.text = BackupRestoreSection.footer
            content.secondaryText = "백업 파일명은 변경하지 마시기 바랍니다."
            content.secondaryTextProperties.color = .customTintColor
            supplementaryView.contentConfiguration = content
        }
        
        dataSource = UICollectionViewDiffableDataSource(collectionView: mainView.collectionView, cellProvider: { collectionView, indexPath, itemIdentifier in
            
            return collectionView.dequeueConfiguredReusableCell(using: cellRegistration, for: indexPath, item: itemIdentifier)
        })
        
        dataSource.supplementaryViewProvider = { collectionView, elementKind, indexPath in
            return collectionView.dequeueConfiguredReusableSupplementary(using: footerRegistration, for: indexPath)
        }
        
        var snapshot = NSDiffableDataSourceSnapshot<BackupRestoreSection, String>()
        snapshot.appendSections([.main])
        snapshot.appendItems(BackupRestoreSection.main.item)
        dataSource.apply(snapshot, animatingDifferences: true)
    }
    
}

extension BackupAndRestoreViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        
        guard let item = dataSource.itemIdentifier(for: indexPath) else { return }
        
        switch item {
        case BackupRestoreSection.main.item[0]: backupDate() // 백업
        case BackupRestoreSection.main.item[1]: restoreData() // 복원
        default: print("오류")
        }
    }
}

// MARK: - Backup, Restore
extension BackupAndRestoreViewController {
    
    private func backupDate() {
        var urlPaths = [URL]() // 백업할 파일에 대한 URL 배열
        
        guard let path = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            print("도큐먼트 경로에 오류가 있습니다.")
            return
        }
        
        let imageDirectory = path.appendingPathComponent("image")
        let realmFile = path.appendingPathComponent("default.realm")
        
        if FileManager.default.fileExists(atPath: imageDirectory.path) {
            urlPaths.append(URL(string: imageDirectory.path)!)
        } else {
            print("백업할 이미지 폴더가 존재하지 않습니다.")
        }
        
        if FileManager.default.fileExists(atPath: realmFile.path) {
            urlPaths.append(URL(string: realmFile.path)!)
        } else {
            print("백업할 realm 파일이 존재하지 않습니다.")
        }
        print(urlPaths)
        
        if FileManager.default.fileExists(atPath: path.appendingPathComponent("archive.zip").path) {
            let alert = UIAlertController(title: "기존 백업을 대치하겠습니까?", message: "Hanger 앱 내부에 이미 생성된 백업 파일이 존재합니다. 새로운 백업 파일로 대치하겠습니까? 기존 백업 데이터는 삭제됩니다.", preferredStyle: .actionSheet)
            let ok = UIAlertAction(title: "대치", style: .destructive) { [weak self] _ in
                do {
                    let zipFilePath = try Zip.quickZipFiles(urlPaths, fileName: "archive")
                    print("압축을 성공했습니다. 압축 경로: \(zipFilePath)")
                    self?.presentActivityViewController()
                } catch {
                    print("압축이 실패했습니다.")
                }
            }
            let cancel = UIAlertAction(title: "취소", style: .cancel)
            cancel.setValue(UIColor.label, forKey: "titleTextColor")
            alert.addAction(ok)
            alert.addAction(cancel)
            present(alert, animated: true)
        } else {
            do {
                let zipFilePath = try Zip.quickZipFiles(urlPaths, fileName: "archive")
                print("압축을 성공했습니다. 압축 경로: \(zipFilePath)")
                presentActivityViewController()
            } catch {
                print("압축이 실패했습니다.")
            }
        }
    }
    
    private func presentActivityViewController() {
        guard let path = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first?.appendingPathComponent("archive.zip") else {
            print("백업 파일 경로 오류")
            return
        }
        
        let vc = UIActivityViewController(activityItems: [path], applicationActivities: nil)
        present(vc, animated: true)
    }
    
    private func restoreData() {
        let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: [.archive], asCopy: true)
        documentPicker.delegate = self
        documentPicker.allowsMultipleSelection = false
        present(documentPicker, animated: true)
    }
}

extension BackupAndRestoreViewController: UIDocumentPickerDelegate {
    
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        print("취소 버튼을 누르셨습니다.")
    }
    
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let backupFileInFileAppURL = urls.first else { // 파일 앱에서 선택한 파일 경로
            print("선택하신 파일을 찾을 수 없습니다.")
            return
        }
        
        guard let backupFileURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { // 도큐먼트 경로
            print("도큐먼트의 백업 파일 경로에 문제가 있습니다.")
            return
        }
        
        let sandboxFileURL = backupFileURL.appendingPathComponent(backupFileInFileAppURL.lastPathComponent) // 도큐먼트에서 백업 파일 경로
        
        if FileManager.default.fileExists(atPath: sandboxFileURL.path) {
            let fileURL = backupFileURL.appendingPathComponent("archive.zip")
            
            do {
                try Zip.unzipFile(fileURL, destination: backupFileURL, overwrite: true, password: nil, progress: { progress in
                    print("진행 현황: \(progress)")
                }, fileOutputHandler: { [weak self] unzippedFile in
                    guard let self = self else { return }
                    print("압축 해제된 파일: \(unzippedFile)")
                    print("복원이 완료되었습니다.")
                    self.showAlret(title: "복원이 완료되었습니다.", message: "앱을 완전히 종료 후 다시 실행해주세요.")
                })
            } catch {
                print("도큐먼트 파일에 백업 파일 존재, 압축 해제 실패")
            }
            
        } else {
            
            do {
                try FileManager.default.copyItem(at: backupFileInFileAppURL, to: sandboxFileURL)
                
                let fileURL = backupFileURL.appendingPathComponent("archive.zip")
                
                try Zip.unzipFile(fileURL, destination: backupFileURL, overwrite: true, password: nil, progress: { progress in
                    print("진행 현황: \(progress)")
                }, fileOutputHandler: { [weak self] unzippedFile in
                    guard let self = self else { return }
                    print("압축 해제된 파일: \(unzippedFile)")
                    print("복원이 완료되었습니다.")
                    self.showAlret(title: "복원이 완료되었습니다.", message: "앱을 완전히 종료 후 다시 실행해주세요.")
                })
            } catch {
                print("도큐먼트 파일에 백업 파일 없음, 압축 해제 실패")
            }
        }
    }
}

