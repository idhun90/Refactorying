//
//  SettingView.swift
//  Hanger
//
//  Created by 이도헌 on 2022/10/21.
//

import UIKit

import SnapKit

final class SettingView: BaseView {
    
    lazy var collectionView: UICollectionView = {
        let layout = createLayout()
        let view = UICollectionView(frame: .zero, collectionViewLayout: layout)
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func configureUI() {
        super.configureUI()
        addSubview(collectionView)
        
    }
    
    override func setConstraints() {
        super.setConstraints()
        collectionView.snp.makeConstraints {
            $0.edges.equalToSuperview()
        }
    }
}

extension SettingView {
    private func createLayout() -> UICollectionViewLayout {
        var config = UICollectionLayoutListConfiguration(appearance: .insetGrouped)
        config.backgroundColor = .customBackgroundColor
        config.headerMode = .supplementary
        //config.footerMode = .supplementary
        return UICollectionViewCompositionalLayout.list(using: config)
    }
}

