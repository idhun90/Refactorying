//
//  SettingViewController.swift
//  Hanger
//
//  Created by 이도헌 on 2022/10/21.
//

import UIKit
import MessageUI

import Zip

enum SettingSection: CaseIterable, Hashable {
    
    case backupRestore
    case support
    case Information
    //case update
    
    var numberOfItem: [String] {
        switch self {
        case .backupRestore:
            return ["백업 및 복원"]
        case .support:
            return ["문의하기", "리뷰 남기기"]
        case .Information:
            return ["버전"]
//        case .update:
//            return ["업데이트"]
        }
    }
    
    var header: String {
        switch self {
        case .backupRestore:
            return "데이터"
        case .support:
            return "지원"
        case .Information:
            return "정보"
//        case .update:
//            return ""
        }
    }
    
    var footer: String {
        switch self {
        case .backupRestore:
            return "앱을 다시 설치하거나 기기 분실 또는 새로운 기기로 교체했을 때 사용자의 데이터를 복원할 수 있도록 생성된 백업 파일을 '파일'앱 > 'iCloud Drive' 또는 안전한 위치로 옮겨주세요.\n\n생성된 백업 파일의 파일명은 변경하지 마시기 바랍니다."

        case .support:
            return "기본 Mail 앱에 메일 계정이 등록되어야 사용할 수 있습니다."
        case .Information:
            return ""
//        case .update:
//            return "앱 업데이트를 위해 앱스토어로 이동합니다."
        }
    }
}

final class SettingViewController: BaseViewController {
    
    private let mainView = SettingView()
    
    private var dataSource: UICollectionViewDiffableDataSource<SettingSection, String>!
    
    override func loadView() {
        view = mainView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureDataSourse()
        applyInitialSnapshots()
        
        mainView.collectionView.delegate = self
    }
    
    override func configureUI() {
        super.configureUI()
        setupNavigationBar()
        setupSheetPresentationController()
    }
    
    private func setupSheetPresentationController() {
        if let sheet = sheetPresentationController {
            //sheet.detents = [.medium(), .large()]
            //sheet.selectedDetentIdentifier = .large
            sheet.preferredCornerRadius = 20 // 기본값 10
            sheet.prefersGrabberVisible = false
            sheet.prefersScrollingExpandsWhenScrolledToEdge = true
        }
    }
    
    private func setupNavigationBar() {
        title = "설정"
        navigationController?.navigationBar.prefersLargeTitles = true
        //let rightBarButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(dissmissViewController))
        let rightBarButton = UIBarButtonItem(barButtonSystemItem: .close, target: self, action: #selector(dissmissViewController))
        navigationItem.rightBarButtonItems = [rightBarButton]
    }
    
    @objc private func dissmissViewController() {
        unwind(style: .dismiss)
    }
}

// MARK: - CollectionView
extension SettingViewController {
    
    private func configureDataSourse() {
        
        let cellRegistration = UICollectionView.CellRegistration<UICollectionViewListCell, String> { [weak self] cell, indexPath, itemIdentifier in
            guard let self = self else { return }
            var content = UIListContentConfiguration.valueCell()
            content.text = itemIdentifier
            content.secondaryText = indexPath.section == self.dataSource.indexPath(for: SettingSection.Information.numberOfItem[0])?.section ? self.getCurrentAppVersion() : nil
            content.textProperties.color = indexPath.section == 3 ? .customTintColor : .label
            cell.contentConfiguration = content
            
            var backgroundContent = UIBackgroundConfiguration.listPlainCell()
            backgroundContent.backgroundColor = .customCellBackgroundColor
            cell.backgroundConfiguration = backgroundContent
            
//            cell.accessories = indexPath.section == self.dataSource.indexPath(for: SettingSection.Information.numberOfItem[0])?.section ? [] : [.disclosureIndicator()]
//
            switch indexPath.section {
            case 0: cell.accessories = [.disclosureIndicator()]
            case 1: cell.accessories = [.disclosureIndicator()]
            default: cell.accessories = []
            }
            
        }
        
        //header
        let headerRegistration = UICollectionView.SupplementaryRegistration<UICollectionViewListCell>(elementKind: UICollectionView.elementKindSectionHeader) { supplementaryView, elementKind, indexPath in
            var content = UIListContentConfiguration.groupedHeader()
            content.text = SettingSection.allCases[indexPath.section].header
            supplementaryView.contentConfiguration = content
        }
        
        // footer
//        let footerRegistration = UICollectionView.SupplementaryRegistration<UICollectionViewListCell>(elementKind: UICollectionView.elementKindSectionFooter) { supplementaryView, elementKind, indexPath in
//            var content = UIListContentConfiguration.groupedFooter()
//            content.text = indexPath.section == 3 ? SettingSection.update.footer : nil
//            supplementaryView.contentConfiguration = content
//        }
        
        dataSource = UICollectionViewDiffableDataSource(collectionView: self.mainView.collectionView, cellProvider: { collectionView, indexPath, itemIdentifier in
            return collectionView.dequeueConfiguredReusableCell(using: cellRegistration, for: indexPath, item: itemIdentifier)
        })
        
        dataSource.supplementaryViewProvider = { collectionView, elementKind, indexPath in
            
            return collectionView.dequeueConfiguredReusableSupplementary(using: headerRegistration, for: indexPath)
            
            //return elementKind == UICollectionView.elementKindSectionHeader ? collectionView.dequeueConfiguredReusableSupplementary(using: headerRegistration, for: indexPath) : collectionView.dequeueConfiguredReusableSupplementary(using: footerRegistration, for: indexPath)
            
        }
    }
    
    private func applyInitialSnapshots() {
        
        for section in SettingSection.allCases {
            var sectionSnapshot = NSDiffableDataSourceSectionSnapshot<String>()
            let items = section.numberOfItem
            sectionSnapshot.append(items)
            dataSource.apply(sectionSnapshot, to: section, animatingDifferences: true)
        }
    }

}


extension SettingViewController: UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        collectionView.deselectItem(at: indexPath, animated: true)
        
        guard let item = self.dataSource.itemIdentifier(for: indexPath) else { return }
        
        switch item {
        // 백업 및 복원
        case SettingSection.backupRestore.numberOfItem[0]: transition(viewController: BackupAndRestoreViewController(), style: .push, animated: true)
        // 문의하기
        case SettingSection.support.numberOfItem[0]: sendFeedback()
        // 리뷰남기기
        case SettingSection.support.numberOfItem[1]: openAppStore(appleID: "1645004892")
        // 버전
        case SettingSection.Information.numberOfItem[0]: print("\(item): \(getCurrentAppVersion())")
        // 업데이트
        //case SettingSection.update.numberOfItem[0]: openAppStoreForUpdate(appleID: "1645004892")
        default: print("오류 발생")
        }
        

    }
}

// MARK: - 문의하기 & 리뷰 남기기
extension SettingViewController {
    
    private func sendFeedback() {
        if MFMailComposeViewController.canSendMail() {
            
            let mail = MFMailComposeViewController()
            let message = """
                          내용:
                          
                          
                          
                          
                          
                          
                          
                          
                          
                          ---
                          iOS 버전: \(UIDevice.current.systemVersion)
                          Hanger 버전: \(getCurrentAppVersion())
                          """
            
            mail.setToRecipients(["idhun90@me.com"])
            mail.setSubject("[Hanger] 문의")
            mail.setMessageBody(message, isHTML: false)
            mail.mailComposeDelegate = self
            
            present(mail, animated: true)
            
        } else {
            
            print("문의하기 실패")
            let sendMailErrorAlert = UIAlertController(title: "'Mail'앱에 메일 계정을 추가하시겠습니까?", message: "'Mail'앱에 메일 계정이 등록되어야 사용할 수 있습니다.", preferredStyle: .actionSheet)
            
            let goSetting = UIAlertAction(title: "설정으로 이동", style: .default) { _ in
                if let url = URL(string: UIApplication.openSettingsURLString),
                   UIApplication.shared.canOpenURL(url) {
                    UIApplication.shared.open(url)
                }
            }
            
            let cancel = UIAlertAction(title: "취소", style: .destructive)
            
            sendMailErrorAlert.addAction(goSetting)
            sendMailErrorAlert.addAction(cancel)
            present(sendMailErrorAlert, animated: true)
            
        }
    }
    
    // 현재 사용 중인 버전
    private func getCurrentAppVersion() -> String {
        guard let dictionary = Bundle.main.infoDictionary,
              let appVersion = dictionary["CFBundleShortVersionString"] as? String else { return "" }
        return appVersion
    }
    
    // 리뷰 남기기
    private func openAppStore(appleID: String) {
        let url = "itms-apps://itunes.apple.com/app/itunes-u/id\(appleID)?ls=1&mt=8&action=write-review"
        if let reviewURL = URL(string: url), UIApplication.shared.canOpenURL(reviewURL) {
            UIApplication.shared.open(reviewURL)
        }
    }

    private func openAppStoreForUpdate(appleID: String) {
        let url = "itms-apps://itunes.apple.com/app/itunes-u/id\(appleID)"
        if let reviewURL = URL(string: url), UIApplication.shared.canOpenURL(reviewURL) {
            UIApplication.shared.open(reviewURL)
        }
    }
    
}

extension SettingViewController: MFMailComposeViewControllerDelegate {
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        dismiss(animated: true)
    }
}

