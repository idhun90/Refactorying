import UIKit

extension UIViewController {
    
    enum TransitionStyle {
        case present
        case push
    }
    
    enum unwindStyle {
        case dismiss
        case pop
    }
    
    func transition<T: UIViewController>(viewController: T, style: TransitionStyle, animated: Bool) {
        switch style {
        case .present:
            let nav = UINavigationController(rootViewController: viewController)
            nav.modalPresentationStyle = .fullScreen
            self.present(nav, animated: animated)
        case .push:
            self.navigationController?.pushViewController(viewController, animated: animated)
        }
    }
    
    func unwind(style: unwindStyle) {
        switch style {
        case .dismiss:
            self.dismiss(animated: true)
        case .pop:
            self.navigationController?.popViewController(animated: true)
        }
    }
}
