import UIKit

extension UIColor {
    static let customTintColor = UIColor(named: "CustomTintColor")!
    //static let customBackgroundColorForView = UIColor(named: "CustomBackGroundColor")
    static let customBackgroundColor = UIColor(named: "CustomBackGroundColor")!//UIColor.systemGroupedBackground
    static let customCellBackgroundColor = UIColor(named: "CustomCellBackGroundColor")!
    static let customSecondaraySystemBackgroundColor = UIColor.secondarySystemGroupedBackground
    static let customTiarySystemBackgroundColor = UIColor.tertiarySystemGroupedBackground
    static let CustomTapColor = UIColor(named: "CustomTapColor")!
}
