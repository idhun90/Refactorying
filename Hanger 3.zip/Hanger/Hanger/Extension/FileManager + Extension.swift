import UIKit

extension UIViewController {
    
    // 이미지를 저장할 폴더 생성
    func creatImageDirectory(name: String) {
        guard let documentDirectoryURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { return }
        let imageDirectoryURL = documentDirectoryURL.appendingPathComponent(name)
        do {
            try FileManager.default.createDirectory(at: imageDirectoryURL, withIntermediateDirectories: false)
        } catch let error {
            print("이미지 폴더 생성 실패", error)
        }
    }
    
    func saveImageToImageDirectory(fileName: String, image: UIImage?) {
        guard let documentDirectoryURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { return }
        let imageDirectoryURL = documentDirectoryURL.appendingPathComponent("image")
        if !FileManager.default.fileExists(atPath: imageDirectoryURL.path) {
            creatImageDirectory(name: "image")
            print("image 폴더가 존재하지 않습니다. 새로운 image 폴더를 생성합니다.")
        }
        
        guard let imageDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first?.appendingPathComponent("image") else { return }
        let imageFileURL = imageDirectory.appendingPathComponent(fileName)
        //guard let data = image.pngData() else {
        guard let image = image else {
            print("이미지가 nil이어서 압축할 수 없습니다.")
            return 
        }
        //guard let data = image.pngData() else {
        guard let data = image.jpegData(compressionQuality: 0.8) else {
            print("압축 실패")
            return
        }
        
        do {
            try data.write(to: imageFileURL)
        } catch let error {
            print("이미지 파일 저장 실패", error)
        }
    }
    
    func loadImageFromImageDirectory(fileName: String) -> UIImage? {
        guard let imageDirectoryURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first?.appendingPathComponent("image") else {
            return nil
        }
        let fileURL = imageDirectoryURL.appendingPathComponent(fileName)
        
        if FileManager.default.fileExists(atPath: fileURL.path) {
            return UIImage(contentsOfFile: fileURL.path)
        } else {
            return UIImage(named: "Hanger")
        }
    }
    
    func removeImage(fileName: String) {
        guard let imageDirectoryURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first?.appendingPathComponent("image") else { return }
        let fileURL = imageDirectoryURL.appendingPathComponent(fileName)
        
        if FileManager.default.fileExists(atPath: fileURL.path) {
            do {
                try FileManager.default.removeItem(at: fileURL)
                print("이미지가 삭제되었습니다.")
            } catch let error {
                print("이미지 제거 실패", error)
            }
        } else {
            print("삭제할 이미지가 존재하지 않습니다")
        }
        
    }
}
