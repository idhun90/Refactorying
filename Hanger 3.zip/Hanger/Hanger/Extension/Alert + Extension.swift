import UIKit

extension UIViewController {
    
    func showDismissAlert(alert: String?, ok: String?) {
        let alert = UIAlertController(title: alert, message: nil, preferredStyle: .actionSheet)
        let dissmiss = UIAlertAction(title: ok, style: .destructive) { _ in
            self.resignFirstResponder()
            self.dismiss(animated: true)
        }
        let cancel = UIAlertAction(title: "계속 편집하기", style: .cancel)
        
        cancel.setValue(UIColor.label, forKey: "titleTextColor") // 취소 버튼 색상 변경
        
        alert.addAction(dissmiss)
        alert.addAction(cancel)
        present(alert, animated: true)
    }
    
    func showAlret(title: String?, message: String?) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let ok = UIAlertAction(title: "확인", style: .default)
        alert.addAction(ok)
        present(alert, animated: true)
    }
}
