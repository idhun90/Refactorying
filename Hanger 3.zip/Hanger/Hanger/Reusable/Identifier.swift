import UIKit

protocol ReusableIdentifier {
    static var reusableIdentifier: String { get }
}

extension UIViewController: ReusableIdentifier {
    static var reusableIdentifier: String {
        return String(describing: self)
    }
}

extension UITableViewCell: ReusableIdentifier {
    static var reusableIdentifier: String {
        return String(describing: self)
    }
}

//extension UICollectionViewCell: ReusableIdentifier {
//    static var reusableIdentifier: String {
//        return String(describing: self)
//    }
//}

extension UITableViewHeaderFooterView: ReusableIdentifier {
    static var reusableIdentifier: String {
        return String(describing: self)
    }
}

extension UICollectionReusableView: ReusableIdentifier {
    static var reusableIdentifier: String {
        return String(describing: self)
    }
}
