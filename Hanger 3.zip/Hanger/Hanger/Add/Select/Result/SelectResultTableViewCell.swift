import UIKit

final class SelectResultTableViewCell: BaseTableViewCell {
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: .value1, reuseIdentifier: reuseIdentifier)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func configureUI() {
        super.configureUI()
        backgroundColor = .customCellBackgroundColor
    }

    func setup(text: String) {
        var content = defaultContentConfiguration()
        content.attributedText = NSAttributedString(string: text, attributes: [.font: UIFont.systemFont(ofSize: 17)])
        contentConfiguration = content
    }

}
