import UIKit

protocol SelectedResultCellDelegate: AnyObject {
    func sendSelectedResultData(indexPathRow: Int)
}

final class SelectResultViewController: BaseViewController {
    
    private let mainView = SelectResultView()
    
    private var selected: Int = 1
    weak var delegate: SelectedResultCellDelegate?
    
    override func loadView() {
        view = mainView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        delegate?.sendSelectedResultData(indexPathRow: selected)
        print(#function, "\(InfoList.infoResult.secondaryText[selected]) 전송됨")
    }
    
    override func configureUI() {
        super.configureUI()
        setTableView()
        setNavigationController()
    }
    
    private func setTableView() {
        mainView.tableView.delegate = self
        mainView.tableView.dataSource = self
    }
    
    func loadSelectedIndex(_ indexPath: Int) {
        selected = indexPath
    }
    
    private func setNavigationController() {
        navigationItem.title = "후기"
    }
    
    @objc private func cancelButtonClicked() {
        unwind(style: .dismiss)
    }
}

extension SelectResultViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return InfoList.infoResult.secondaryText.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: SelectResultTableViewCell.reusableIdentifier, for: indexPath) as? SelectResultTableViewCell else { return UITableViewCell() }
        
        cell.setup(text: String(describing: InfoList.infoResult.secondaryText[indexPath.row]))
        cell.accessoryType = indexPath.row == selected ? .checkmark : .none
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: false)
        
        let selectedFilterRow = selected
        if selectedFilterRow == indexPath.row {
            return
        }
        
        if let previousCell = tableView.cellForRow(at: IndexPath(row: selectedFilterRow, section: indexPath.section)) {
            previousCell.accessoryType = .none
        }
        if let cell = tableView.cellForRow(at: indexPath) {
            cell.accessoryType = .checkmark
        }
        selected = indexPath.row
        print("\(InfoList.infoResult.secondaryText[selected]) 선택함")
    }
    
}
