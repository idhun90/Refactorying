import UIKit
import PhotosUI

import RealmSwift

final class AddViewController: BaseViewController {
    
    private let mainView = AddView()
    
    private let itemRepository = ItemRepository()
    var itemData: Item?
    
    var selectedCategory: String = ""
    private var createdImageData: Date? {
        didSet {
            checkDateChanged()
        }
    }
    
    private var inputValue = [String](repeating: "", count: 6) {
        didSet {
            checkDateChanged()
        }
    }
    
    private var selectedFitIndexPathRow: Int? = 1 { // 디폴트 값: "정사이즈"
        didSet {
            checkDateChanged()
        }
    }
    
    private var selectedResultIndexPathRow: Int = 1 { // 디폴트 값: "잘 맞아요"
        didSet {
            checkDateChanged()
        }
    }
    
    private var realSizeValue = [String](repeating: "", count: 5) {
        didSet {
            checkDateChanged()
        }
    }
    
    private var urlValue: String = "" {
        didSet {
            checkDateChanged()
        }
    }
    private var memoValue: String = "" { // 디폴트값 변경 시 취소버튼 수정 필요
        didSet {
            checkDateChanged()
        }
    }
    
    override func loadView() {
        self.view = mainView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //navigationController?.presentationController?.delegate = self // 화면전환 방식 변경으로 불필요
        // self.isModalInPresentation = true // 화면전환 방식 변경으로 불필요
        
        setupUIMenu()
        navigationItem.rightBarButtonItems![0].isEnabled = false
        
        
        mainView.addTableHeaderView.addOrEditImageButton.setTitle(self.mainView.addTableHeaderView.itemImageView.image == UIImage(named: "Hanger") ? "사진 추가" : "편집", for: .normal)
        
        // realSizeValueList 마지막 배열 삭제
        if selectedCategory == String(describing: SelectedCategory.outer) || selectedCategory == String(describing: SelectedCategory.top) {
            if realSizeValue.count == 5 { // 데이터 값을 가져온 후 즉 편집 화면일 땐 이미 4개이기 때문이다.
                realSizeValue.removeLast()
                print("실측 사이즈 배열 마지막 배열 삭제됨", realSizeValue)
            }
        }
        
        mainView.pickerView.addTarget(self, action: #selector(datePickerValueDidChanged), for: .valueChanged)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func configureUI() {
        super.configureUI()
        setTableView()
        setNavigationController()
    }
    
    private func setTableView() {
        self.mainView.tableView.delegate = self
        self.mainView.tableView.dataSource = self
    }
    
    func loadItemData(data: Item?) {
        guard let itemData = data else {
            print("itemData가 존재하지 않습니다.")
            return
        }
        self.itemData = itemData
        mainView.addTableHeaderView.itemImageView.image = loadImageFromImageDirectory(fileName: "\(itemData.objectId).jpg") // 분기처리필요
        createdImageData = itemData.createdImageData
        selectedCategory = itemData.category
        inputValue = itemData.inputArray
        selectedFitIndexPathRow = itemData.fit
        selectedResultIndexPathRow = itemData.result
        realSizeValue = itemData.realSizeArray!
        urlValue = itemData.url
        memoValue = itemData.memo
    }
    
    private func setNavigationController() {
        navigationItem.title = itemData == nil ? "새로운 \(selectedCategory)" : "\(selectedCategory) 편집"//itemData?.inputArray[0]
        
        let leftBarButtonItem = UIBarButtonItem(title: "취소", style: .plain ,target: self, action: #selector(cancelButtonClicked))
        let rightBarButtonItem = UIBarButtonItem(title: itemData == nil ? "추가" : "완료", style: .done ,target: self, action: #selector(saveButtonClicked))
        
        navigationItem.leftBarButtonItem = leftBarButtonItem
        navigationItem.rightBarButtonItem = rightBarButtonItem
    }
    
    @objc private func cancelButtonClicked() {
        
        // 값 비교
        if itemData == nil { // 추가화면일 때
            // 아우터, 상의일 때
            if selectedCategory == String(describing: SelectedCategory.outer) || selectedCategory == String(describing: SelectedCategory.top) {
                if createdImageData == nil && inputValue == ["", "", "", "", "", ""] && selectedFitIndexPathRow == 1 && selectedResultIndexPathRow == 1 && realSizeValue == ["", "", "", ""] && urlValue == "" && memoValue == "" {
                    unwind(style: .dismiss)
                } else {
                    showDismissAlert(alert: "아이템 추가를 취소하겠습니까?", ok: "추가 취소")
                }
            } else if selectedCategory == String(describing: SelectedCategory.bottom) {
                if createdImageData == nil && inputValue == ["", "", "", "", "", ""] && selectedFitIndexPathRow == 1 && selectedResultIndexPathRow == 1 && realSizeValue == ["", "", "", "", ""] && urlValue == "" && memoValue == "" {
                    unwind(style: .dismiss)
                } else {
                    showDismissAlert(alert: "아이템 추가를 취소하겠습니까?", ok: "추가 취소")
                }
            } else {
                if createdImageData == nil && inputValue == ["", "", "", "", "", ""] && selectedFitIndexPathRow == 1 && selectedResultIndexPathRow == 1 && urlValue == "" && memoValue == "" {
                    unwind(style: .dismiss)
                } else {
                    showDismissAlert(alert: "아이템 추가를 취소하겠습니까?", ok: "추가 취소")
                }
            }
        } else {
            if itemData!.inputArray != inputValue || itemData!.fit != selectedFitIndexPathRow || itemData!.result != selectedResultIndexPathRow || itemData!.realSizeArray != realSizeValue || itemData!.url != urlValue || itemData!.memo != memoValue || itemData!.createdImageData != createdImageData {
                showDismissAlert(alert: "아이템 편집을 취소하겠습니까?", ok: "편집 취소")
            } else {
                unwind(style: .dismiss)
            }
        }
    }
    
    @objc private func saveButtonClicked() {
        checkRealSizeLastAndCountDot()
        saveItemDataToRealm()
    }
    
    private func setupUIMenu() {
        var children: [UIAction] {
            let camera = UIAction(title: "카메라 찍기", image: UIImage(systemName: "camera")) { [weak self] _ in
                guard let self = self else { return }
                let picker = UIImagePickerController()
                guard UIImagePickerController.isSourceTypeAvailable(.camera) else { return }
                picker.sourceType = .camera
                picker.allowsEditing = true
                picker.delegate = self
                
                self.present(picker, animated: true)
            }
            
            let photoAlbum = UIAction(title: "사진 보관함", image: UIImage(systemName: "photo")) { [weak self] _ in
                guard let self = self else { return }
                var configuration = PHPickerConfiguration()
                configuration.selectionLimit = 1
                configuration.filter = .images
                let picker = PHPickerViewController(configuration: configuration)
                
                picker.delegate = self
                
                self.present(picker, animated: true)
            }
            
            return [camera, photoAlbum]
        }
        mainView.addTableHeaderView.addOrEditImageButton.menu = UIMenu(title: "", options: .displayInline, children: children)
        mainView.addTableHeaderView.addOrEditImageButton.showsMenuAsPrimaryAction = true
    }
    
    // MARK: - datePicker 메소드
    @objc private func datePickerValueDidChanged(_ datePicker: UIDatePicker) {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy년 MM월 dd일"
        formatter.locale = Locale(identifier: "ko_KR")
        //self.selecteDate = datePicker.date
        
        inputValue[5] = formatter.string(from: datePicker.date)
        print(datePicker.date)
        guard let cell = mainView.tableView.cellForRow(at: [0, 5]) as? AddInputTableViewCell else { return }
        cell.textField.text = inputValue[5]
    }
    
    // MARK: - 텍스트필드 값 실시간 저장 메소드
    @objc private func saveTextFieldValue(textField: UITextField) {
        
        guard let text = textField.text else { return }
        
        switch textField.tag {
        case 0:
            if textField.placeholder == "제품명" {
                inputValue[0] = text
            } else if textField.placeholder == "어깨 너비" || textField.placeholder == "허리 단면" {
                realSizeValue[0] = text
            } else if textField.placeholder == "URL" {
                urlValue = text
            }
        case 1:
            if textField.placeholder == "브랜드" {
                inputValue[1] = text
            } else if textField.placeholder == "가슴 단면" || textField.placeholder == "허벅지 단면" {
                realSizeValue[1] = text
            }
        case 2:
            if textField.placeholder == "사이즈" {
                inputValue[2] = text
            } else if textField.placeholder == "소매 길이" || textField.placeholder == "밑위" {
                realSizeValue[2] = text
            }
        case 3:
            if textField.placeholder == "색상" {
                inputValue[3] = text
            } else if textField.placeholder == "총장" || textField.placeholder == "밑단 단면" {
                realSizeValue[3] = text
            }
        case 4:
            if textField.placeholder == "가격" {
                //inputValue[4] = text
                inputValue[4] = addDecimalNumberFormat(text: text)
                textField.text = addDecimalNumberFormat(text: text)

            } else if textField.placeholder == "총장" {
                realSizeValue[4] = text
            }
        case 5:
            if textField.placeholder == "구매일" {
                inputValue[5] = text
            }
        default:
            print("저장 오류")
        }
        
        print("현재 입력된 텍스트:", textField.text!)
        print("inputValue 값:", inputValue)
        print("realSizeValue 값:", realSizeValue)
        print("urlValue 값:", urlValue)
        print("memoValue 값:", memoValue)
    }
    
    // MARK: - 가격 실시간 컴마 추가
    private func addDecimalNumberFormat(text: String) -> String {
        let numberFormat = NumberFormatter()
        numberFormat.numberStyle = .decimal
        let text = text.replacingOccurrences(of: ",", with: "")
        guard let number = Int(text) else { return "" }
        let result = numberFormat.string(for: number)!
        return result
    }
    
    // MARK: - 실측 사이즈 마지막에 소수점이 있거나 소수점이 하나 이상 있는지 체크
    private func checkRealSizeLastAndCountDot() {
        for count in 0...realSizeValue.count-1 {
            if realSizeValue[count].filter({ $0 == "."}).count > 1 { // 소수점이 한 개 이상 테스트
                realSizeValue[count] = realSizeValue[count].components(separatedBy: ["."]).joined()
            }
            
            if realSizeValue[count].last == "." { // 마지막 항목 소수점 테스트
                realSizeValue[count].removeLast()
            }
        }
    }
    
    // MARK: - Realm 저장 메소드
    private func saveItemDataToRealm() {
        
        if itemData == nil { // 새로운 아이템 추가
            switch selectedCategory {
                //아우터, 상의, 하의
            case String(describing: SelectedCategory.outer), String(describing: SelectedCategory.top), String(describing: SelectedCategory.bottom):
                saveItemDataFilteredByCategory(category: selectedCategory, createdImageData: createdImageData, fit: selectedFitIndexPathRow, result: selectedResultIndexPathRow, createdDate: Date(), url: urlValue, memo: memoValue, inputValue: inputValue, realSizeValue: realSizeValue)
                //신발, 액세서리
            case String(describing: SelectedCategory.shoes), String(describing: SelectedCategory.acc):
                saveItemDataFilteredByCategory(category: selectedCategory, createdImageData: createdImageData, fit: nil, result: selectedResultIndexPathRow, createdDate: Date(), url: urlValue, memo: memoValue, inputValue: inputValue, realSizeValue: nil)
            default:
                print("저장 오류 발생")
            }
        } else { // 아이템 수정
            
            if itemData!.inputArray != inputValue || itemData!.fit != selectedFitIndexPathRow || itemData!.result != selectedResultIndexPathRow || itemData!.realSizeArray != realSizeValue || itemData!.url != urlValue || itemData!.memo != memoValue || itemData!.createdImageData != createdImageData {
                
                do {
                    try itemRepository.localRealm.write {
                        itemRepository.localRealm.create(Item.self, value: ["objectId": itemData!.objectId, "url": urlValue, "memo": memoValue, "fit": selectedFitIndexPathRow, "result": selectedResultIndexPathRow, "createdImageData": createdImageData], update: .modified)
                        itemData!.inputArray = inputValue
                        itemData!.realSizeArray = realSizeValue
                        guard let image = mainView.addTableHeaderView.itemImageView.image else {
                            print("수정할 이미지가 없습니다, 다른 데이터만 수정됩니다.")
                            return
                        }
                        if image != UIImage(named: "Hanger") {
                            saveImageToImageDirectory(fileName: "\(itemData!.objectId).jpg", image: image)
                        }
                    }
                } catch let error {
                    print("아이템 수정 실패", error)
                }
                
            } else {
                print("값 변화 없음")
            }
            
        }
        unwind(style: .dismiss)
    }
    
    private func saveItemDataFilteredByCategory(category: String, createdImageData: Date?, fit: Int?, result: Int, createdDate: Date, url: String, memo: String, inputValue: [String], realSizeValue: [String]?) {
        let itemData = Item(category: category, createdImageData: createdImageData, fit: fit, result: result, createdDate: createdDate, url: url, memo: memo)
        
        do {
            try itemRepository.localRealm.write {
                itemRepository.localRealm.add(itemData)
                itemData.inputArray = inputValue
                itemData.realSizeArray = realSizeValue
                
                guard let image = mainView.addTableHeaderView.itemImageView.image else {
                    print("저장할 이미지가 없습니다, 다른 데이터만 저장됩니다.")
                    return
                }
                if image != UIImage(named: "Hanger") {
                    saveImageToImageDirectory(fileName: "\(itemData.objectId).jpg", image: image)
                }
                
            }
        } catch let error {
            print("아이템 추가 실패", error)
        }
        
    }
    
    //MARK: - 필수입력항목 체크
    
    private func checkInputValueIsEmpty() -> Bool { // 필수입력항목 입력 여부 체크
        if inputValue[0].trimmingCharacters(in: .whitespaces).isEmpty || inputValue[1].trimmingCharacters(in: .whitespaces).isEmpty || inputValue[2].trimmingCharacters(in: .whitespaces).isEmpty {
            return true
        } else {
            return false
        }
    }
    
//    private func checkRealSizeValueIsEmpty() -> Bool { //필수입력항목(실측사이즈) 입력 여부 체크
//
//        switch realSizeValue.count {
//        case 4: // 아우터, 상의 카테고리
//            if realSizeValue[0].trimmingCharacters(in: .whitespaces).isEmpty ||
//                realSizeValue[1].trimmingCharacters(in: .whitespaces).isEmpty ||
//                realSizeValue[2].trimmingCharacters(in: .whitespaces).isEmpty ||
//                realSizeValue[3].trimmingCharacters(in: .whitespaces).isEmpty {
//                return true
//            } else {
//                return false
//            }
//        case 5: // 하의 카테고리
//            if realSizeValue[0].trimmingCharacters(in: .whitespaces).isEmpty ||
//                realSizeValue[1].trimmingCharacters(in: .whitespaces).isEmpty ||
//                realSizeValue[2].trimmingCharacters(in: .whitespaces).isEmpty ||
//                realSizeValue[3].trimmingCharacters(in: .whitespaces).isEmpty ||
//                realSizeValue[4].trimmingCharacters(in: .whitespaces).isEmpty {
//                return true
//            } else {
//                return false
//            }
//        default:
//            return false // 신발, 액세서리 카테고리
//        }
//    }
    
    private func checkDateChanged() {
        if itemData != nil { // 데이터 변화가 있고, 필수 입력 항목이 비어있지 않을 때
            navigationItem.rightBarButtonItems?[0].isEnabled = (itemData!.inputArray == inputValue &&
                                                                itemData!.fit == selectedFitIndexPathRow &&
                                                                itemData!.result == selectedResultIndexPathRow &&
                                                                itemData!.realSizeArray == realSizeValue &&
                                                                itemData!.url == urlValue &&
                                                                itemData!.memo == memoValue &&
                                                                itemData!.createdImageData == createdImageData) || checkInputValueIsEmpty() ? false : true // (checkInputValueIsEmpty() || checkRealSizeValueIsEmpty()) ? false : true
        }
    }
}

//MARK: - extension UITableView
extension AddViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        switch selectedCategory {
        case String(describing: SelectedCategory.outer), String(describing: SelectedCategory.top), String(describing: SelectedCategory.bottom) :
            return 4 // 아우터, 상의, 하의 선택 시
        case String(describing: SelectedCategory.shoes), String(describing: SelectedCategory.acc):
            return 3 // 신발, 액세서리 선택 시
        default :
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return CGFloat.leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        switch selectedCategory {
        case String(describing: SelectedCategory.outer), String(describing: SelectedCategory.top), String(describing: SelectedCategory.bottom):
            return indexPath == [3, 1] ? 44 * 3.5 : 44
        case String(describing: SelectedCategory.shoes), String(describing: SelectedCategory.acc):
            return indexPath == [2, 1] ? 44 * 3.5 : 44
        default :
            return 0
        }
        
    }
    
    func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        
        guard let section = Section(rawValue: section) else { return nil }
        
        switch section {
        case .input:
            return "필수 입력항목: 제품명, 브랜드, 사이즈\n화폐 단위: 원"
        case .realSize:
            if selectedCategory == String(describing: SelectedCategory.outer) || selectedCategory == String(describing: SelectedCategory.top) || selectedCategory == String(describing: SelectedCategory.bottom) {
                
                return "단위: cm"
            } else {
                return nil
            }
        default:
            return nil
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        guard let section = Section(rawValue: section) else { return 0 }
        
        switch section {
        case .input: // 입력항목(첫번째 섹션)
            return InputList.allCases.count
        case .info: // 정보항목(두번째 섹션)
            if selectedCategory == String(describing: SelectedCategory.outer) || selectedCategory == String(describing: SelectedCategory.top) || selectedCategory == String(describing: SelectedCategory.bottom) {
                return InfoList.allCases.count
            } else {
                return 1
            }
        case .realSize: // 실측사이즈(세번째 섹션, 신발, 액세서리 카테고리 선택 시 실측 사이즈가 아니라 url&메모 섹션이됨)
            if selectedCategory == String(describing: SelectedCategory.outer) || selectedCategory == String(describing: SelectedCategory.top) {
                return RealSizeOptions.realSizeOuterOrTop.contents.count
            } else if selectedCategory == String(describing: SelectedCategory.bottom) {
                return RealSizeOptions.realSizeBottom.contents.count
            } else {
                return UrlAndMemoList.allCases.count
            }
        case .urlAndMemo:
            if selectedCategory == String(describing: SelectedCategory.outer) || selectedCategory == String(describing: SelectedCategory.top) || selectedCategory == String(describing: SelectedCategory.bottom) {
                return UrlAndMemoList.allCases.count
            } else {
                return 0
            }
            //        default:
            //            return 0
            // section(rawValue: section)으로 사용하니 default를 안 써도 됨
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        switch indexPath.section {
            
        case Section.input.rawValue: // 입력항목
            guard let cell = tableView.dequeueReusableCell(withIdentifier: AddInputTableViewCell.reusableIdentifier, for: indexPath) as? AddInputTableViewCell else { return UITableViewCell() }
            cell.textField.delegate = self
            cell.textField.tag = indexPath.row
            cell.textField.text = inputValue[indexPath.row]
            cell.setupTextField(inputList: String(describing: InputList.allCases[indexPath.row]))
            
            cell.textField.addTarget(self, action: #selector(saveTextFieldValue), for: .editingChanged)
            cell.textField.addAction(UIAction(handler: { [weak self] _ in // 네비게이션바 추가 버튼 활성화 여부
                guard let self = self else { return }
                if self.itemData == nil { // 추가화면일 때
                    self.navigationItem.rightBarButtonItems![0].isEnabled = self.checkInputValueIsEmpty() ? false : true
                }
            }), for: .editingChanged)
            return cell
            
        case Section.info.rawValue: // 핏/후기
            guard let cell = tableView.dequeueReusableCell(withIdentifier: AddInfoTableViewCell.reusableIdentifier, for: indexPath) as? AddInfoTableViewCell else { return UITableViewCell() }
            
            if selectedCategory == String(describing: SelectedCategory.outer) || selectedCategory == String(describing: SelectedCategory.top) || selectedCategory == String(describing: SelectedCategory.bottom) {
                
                switch indexPath {
                case [Section.info.rawValue, 0]:
                    cell.setup(text: String(describing: InfoList.infoFit), secondaryText: InfoList.infoFit.secondaryText[selectedFitIndexPathRow!])
                    return cell
                    
                case [Section.info.rawValue, 1]:
                    cell.setup(text: String(describing: InfoList.infoResult), secondaryText: InfoList.infoResult.secondaryText[selectedResultIndexPathRow])
                    return cell
                    
                default:
                    return UITableViewCell()
                }
                
            } else if selectedCategory == String(describing: SelectedCategory.shoes) || selectedCategory == String(describing: SelectedCategory.acc) {
                
                cell.setup(text: String(describing: InfoList.infoResult), secondaryText: InfoList.infoResult.secondaryText[selectedResultIndexPathRow])
                return cell
                
            } else {
                return UITableViewCell()
            }
            
        case Section.realSize.rawValue: // 실측사이즈
            if selectedCategory == String(describing: SelectedCategory.outer) || selectedCategory == String(describing: SelectedCategory.top) {
                guard let cell = tableView.dequeueReusableCell(withIdentifier: AddRealSizeTableViewCell.reusableIdentifier, for: indexPath) as? AddRealSizeTableViewCell else { return UITableViewCell() }
                cell.textField.delegate = self
                cell.textField.tag = indexPath.row
                cell.textField.text = realSizeValue[indexPath.row]
                cell.setupTextField(inputList: RealSizeOptions.realSizeOuterOrTop.contents[indexPath.row])
                
                cell.textField.addTarget(self, action: #selector(saveTextFieldValue), for: .editingChanged)
                cell.textField.addAction(UIAction(handler: { [weak self] _ in // 네비게이션바 추가 버튼 활성화 여부
                    guard let self = self else { return }
                    if self.itemData == nil { // 추가화면일 때
                        self.navigationItem.rightBarButtonItems![0].isEnabled = self.checkInputValueIsEmpty() ? false : true
                    }
                }), for: .editingChanged)
                return cell
                
            } else if selectedCategory == String(describing: SelectedCategory.bottom) {
                guard let cell = tableView.dequeueReusableCell(withIdentifier: AddRealSizeTableViewCell.reusableIdentifier, for: indexPath) as? AddRealSizeTableViewCell else { return UITableViewCell() }
                cell.textField.delegate = self
                cell.textField.tag = indexPath.row
                cell.textField.text = realSizeValue[indexPath.row]
                cell.setupTextField(inputList: RealSizeOptions.realSizeBottom.contents[indexPath.row])
                
                cell.textField.addTarget(self, action: #selector(saveTextFieldValue), for: .editingChanged)
                cell.textField.addAction(UIAction(handler: { [weak self] _ in // 네비게이션바 추가 버튼 활성화 여부
                    guard let self = self else { return }
                    if self.itemData == nil { // 추가화면일 때
                        self.navigationItem.rightBarButtonItems![0].isEnabled = self.checkInputValueIsEmpty() ? false : true
                    }
                }), for: .editingChanged)
                return cell
                
            } else if selectedCategory == String(describing: SelectedCategory.shoes) || selectedCategory == String(describing: SelectedCategory.acc) {
                
                switch indexPath {
                case [Section.realSize.rawValue, 0]:
                    guard let cell = tableView.dequeueReusableCell(withIdentifier: AddUrlTableViewCell.reusableIdentifier, for: indexPath) as? AddUrlTableViewCell else { return UITableViewCell() }
                    cell.urlTextField.delegate = self
                    cell.urlTextField.tag = indexPath.row
                    cell.urlTextField.text = urlValue
                    
                    cell.urlTextField.addTarget(self, action: #selector(saveTextFieldValue), for: .editingChanged)
                    cell.urlTextField.addAction(UIAction(handler: { [weak self] _ in // 네비게이션바 추가 버튼 활성화 여부
                        guard let self = self else { return }
                        if self.itemData == nil { // 추가화면일 때
                            self.navigationItem.rightBarButtonItems![0].isEnabled = self.checkInputValueIsEmpty() ? false : true
                        }
                    }), for: .editingChanged)
                    return cell
                case [Section.realSize.rawValue, 1]:
                    guard let cell = tableView.dequeueReusableCell(withIdentifier: AddMemoTableViewCell.reusableIdentifier, for: indexPath) as? AddMemoTableViewCell else { return UITableViewCell() }
                    cell.memoTextView.delegate = self
                    cell.memoTextView.text = memoValue
                    return cell
                default:
                    return UITableViewCell()
                }
                
            } else {
                return UITableViewCell()
            }
            
        case Section.urlAndMemo.rawValue: //URL&메모
            if selectedCategory == String(describing: SelectedCategory.outer) || selectedCategory == String(describing: SelectedCategory.top) || selectedCategory == String(describing: SelectedCategory.bottom) {
                
                switch indexPath {
                case [Section.urlAndMemo.rawValue, 0]:
                    guard let cell = tableView.dequeueReusableCell(withIdentifier: AddUrlTableViewCell.reusableIdentifier, for: indexPath) as? AddUrlTableViewCell else { return UITableViewCell() }
                    cell.urlTextField.delegate = self
                    cell.urlTextField.tag = indexPath.row
                    cell.urlTextField.text = urlValue
                    
                    cell.urlTextField.addTarget(self, action: #selector(saveTextFieldValue), for: .editingChanged)
                    cell.urlTextField.addAction(UIAction(handler: { [weak self] _ in // 네비게이션바 추가 버튼 활성화 여부
                        guard let self = self else { return }
                        if self.itemData == nil { // 추가화면일 때
                            self.navigationItem.rightBarButtonItems![0].isEnabled = self.checkInputValueIsEmpty() ? false : true
                        }
                    }), for: .editingChanged)
                    return cell
                case [Section.urlAndMemo.rawValue, 1]:
                    guard let cell = tableView.dequeueReusableCell(withIdentifier: AddMemoTableViewCell.reusableIdentifier, for: indexPath) as? AddMemoTableViewCell else { return UITableViewCell() }
                    cell.memoTextView.delegate = self
                    cell.memoTextView.text = memoValue
                    return cell
                default:
                    return UITableViewCell()
                }
                
            } else {
                return UITableViewCell()
            }
        default:
            return UITableViewCell()
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        print("\(indexPath)선택됨")
        tableView.deselectRow(at: indexPath, animated: false)
        
        switch selectedCategory {
            
        case String(describing: SelectedCategory.outer), String(describing: SelectedCategory.top), String(describing: SelectedCategory.bottom):
            if indexPath == [1, 0] {
                let vc = SelectFitViewController()
                vc.delegate = self
                vc.loadSelectedIndex(selectedFitIndexPathRow!)
                transition(viewController: vc, style: .push, animated: true)
                
            } else if indexPath == [1, 1] {
                let vc = SelectResultViewController()
                vc.delegate = self
                vc.loadSelectedIndex(selectedResultIndexPathRow)
                transition(viewController: vc, style: .push, animated: true)
            } else {
                print("\(indexPath)누름")
            }
            
        case String(describing: SelectedCategory.shoes), String(describing: SelectedCategory.acc):
            if indexPath == [1, 0] {
                let vc = SelectResultViewController()
                vc.delegate = self
                vc.loadSelectedIndex(selectedResultIndexPathRow)
                transition(viewController: vc, style: .push, animated: true)
            } else {
                print("\(indexPath)누름")
            }
            
        default:
            print("선택 오류 발생")
        }
    }
}

//MARK: - extension UITextField
extension AddViewController: UITextFieldDelegate {
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
//        textField.addTarget(self, action: #selector(saveTextFieldValue), for: .editingChanged)
//        //MARK: 네비게이션바 추가 버튼 활성화 여부(아이템 추가)
//        textField.addAction(UIAction(handler: { [weak self] _ in // 네비게이션바 추가 버튼 활성화 여부
//            guard let self = self else { return }
//
//            if self.itemData == nil { // 추가화면일 때
//
//                self.navigationItem.rightBarButtonItems![0].isEnabled = self.checkInputValueIsEmpty() ? false : true
//
////                if self.selectedCategory == String(describing: SelectedCategory.shoes) ||
////                    self.selectedCategory == String(describing: SelectedCategory.acc) { // 신발, 액세서리 선택 시
////                    self.navigationItem.rightBarButtonItems![0].isEnabled = self.checkInputValueIsEmpty() ? false : true
////                } else { // 아우터, 상의, 하의 선택 시
////                    self.navigationItem.rightBarButtonItems![0].isEnabled = (self.checkInputValueIsEmpty() || self.checkRealSizeValueIsEmpty()) ? false : true
////                }
//            }
//        }), for: .editingChanged)
        
        switch textField.tag {
        case 0: // 제품명/어깨너비/허리단면//URL
            if textField.placeholder == String(describing: InputList.inputName) {
                textField.keyboardType = .default
                textField.returnKeyType = .done
                textField.autocapitalizationType = .none
            } else if textField.placeholder == RealSizeOptions.realSizeOuterOrTop.contents[0] || textField.placeholder == RealSizeOptions.realSizeBottom.contents[0] {
                textField.keyboardType = .decimalPad
            } else if textField.placeholder == String(describing: UrlAndMemoList.url) {
                textField.keyboardType = .URL
                textField.returnKeyType = .done
                textField.autocapitalizationType = .none
            }
        case 1: // 브랜드/가슴단면/허벅지단면
            if textField.placeholder == String(describing: InputList.inputBrand) {
                textField.keyboardType = .default
                textField.returnKeyType = .done
                textField.autocapitalizationType = .none
            } else if textField.placeholder == RealSizeOptions.realSizeOuterOrTop.contents[1] || textField.placeholder == RealSizeOptions.realSizeBottom.contents[1] {
                textField.keyboardType = .decimalPad
            }
        case 2: // 사이즈/소매길이/밑위
            if textField.placeholder == String(describing: InputList.inputSize) {
                textField.autocapitalizationType = .allCharacters
                textField.keyboardType = .asciiCapable
                textField.returnKeyType = .done
            } else if textField.placeholder == RealSizeOptions.realSizeOuterOrTop.contents[2] || textField.placeholder == RealSizeOptions.realSizeBottom.contents[2] {
                textField.keyboardType = .decimalPad
            }
        case 3: // 색상/총장/밑단단면
            if textField.placeholder == String(describing: InputList.inputColor) {
                textField.keyboardType = .default
                textField.returnKeyType = .done
                textField.autocapitalizationType = .none
            } else if textField.placeholder == RealSizeOptions.realSizeOuterOrTop.contents[3] || textField.placeholder == RealSizeOptions.realSizeBottom.contents[3] {
                textField.keyboardType = .decimalPad
            }
        case 4: // 가격/총장(바지)
            if textField.placeholder == String(describing: InputList.inputPrice) {
                textField.keyboardType = .numberPad
            } else if textField.placeholder == RealSizeOptions.realSizeBottom.contents[4] {
                textField.keyboardType = .decimalPad
                
            }
        case 5: // 날짜
            if textField.placeholder == String(describing: InputList.inputDate) {
                
                textField.inputView = mainView.pickerView
                //textField.clearButtonMode = .never
                textField.tintColor = .clear // 커서 안 보이게 하는 속임수
                
                let formatter = DateFormatter()
                formatter.dateFormat = "yyyy년 MM월 dd일"
                formatter.locale = Locale(identifier: "ko_KR")
                
                if itemData != nil {
                    mainView.pickerView.date = formatter.date(from: inputValue[5]) ?? Date()
                }
                
                if (textField.text!.isEmpty || textField.text == nil) { // 필수항목이 아니여서 빈 값일 때도 현재 시간이 나타나도록 변경
                    //inputValue[5] = formatter.string(from: Date())
                    inputValue[5] = formatter.string(from: mainView.pickerView.date)
                    textField.text = inputValue[5]
                }
            }
        default:
            textField.keyboardType = .default
        }
        
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        guard let text = textField.text else { return }
        print(text)
        
        print("inputValue 값:", inputValue)
        print("realSizeValue 값:", realSizeValue)
        print("urlValue 값:", urlValue)
        print("memoValue 값:", memoValue)
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        return true
    }
    //MARK: 실측 사이즈 글자수 제한 (총장: 5자리, 나머지 4자리)
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        guard let text = textField.text else { return false }
        if let char = string.cString(using: String.Encoding.utf8) { // 백스페이스 허용
            let isBackSpase = strcmp(char, "\\b")
            if isBackSpase == -92 {
                return true
            }
        }
        
        switch textField.tag {
        case 0: // 어깨/허리
            if textField.placeholder == String(describing: RealSizeOptions.realSizeOuterOrTop.contents[0]) || textField.placeholder == String(describing: RealSizeOptions.realSizeBottom.contents[0]) {
                
                guard text.count < 4 else { return false }
                return true
                
            } else {
                
                return true
                
            }
        case 1: // 가슴/허벅지
            if textField.placeholder == String(describing: RealSizeOptions.realSizeOuterOrTop.contents[1]) || textField.placeholder == String(describing: RealSizeOptions.realSizeBottom.contents[1]) {
                
                guard text.count < 4 else { return false }
                return true
                
            } else {
                
                return true
                
            }
        case 2: // 소매/밑위
            if textField.placeholder == String(describing: RealSizeOptions.realSizeOuterOrTop.contents[2]) || textField.placeholder == String(describing: RealSizeOptions.realSizeBottom.contents[2]) {
                
                guard text.count < 4 else { return false }
                return true
                
            } else {
                
                return true
                //11자리
            }
        case 3: // 총장(아우터,상의)/밑단
            if textField.placeholder == String(describing: RealSizeOptions.realSizeOuterOrTop.contents[3]) {
                
                guard text.count < 5 else { return false }
                return true
                
            } else if textField.placeholder == String(describing: RealSizeOptions.realSizeBottom.contents[3]) {
                
                guard text.count < 4 else { return false }
                return true
                
            } else {
                
                return true
                
            }
        case 4: // 총장(바지)
            if textField.placeholder == String(describing: RealSizeOptions.realSizeBottom.contents[4]) {
                print("총장이에요")
                
                guard text.count < 5 else {
                    print("5자 제한")
                    return false }
                return true
                
            } else if textField.placeholder == String(describing: InputList.inputPrice) {
                guard text.count < 11 else {
                    print("11자 제한")
                    return false
                }
                return true
            } else {
                return true
            }
        default:
            return true
        }
    }
    
}

//MARK: - extension UIAdaptivePresentationController
//extension AddViewController: UIAdaptivePresentationControllerDelegate {
//    func presentationControllerDidAttemptToDismiss(_ presentationController: UIPresentationController) {
//        // 데이터가 있거나 데이터가 변경됐을 때 분기 필요
//        showDismissAlert()
//    }
//}

//MARK: - extension UITextView
extension AddViewController: UITextViewDelegate {
    
    func textViewDidChange(_ textView: UITextView) {
        guard let text = textView.text else {
            print("텍스트뷰 실시간 작성 오류")
            return
        }
        
        memoValue = text
        
        //        if text.isEmpty || text == "메모를 입력하세요." {
        //            memoValue = ""
        //        } else {
        //            memoValue = text
        //        }
        
        print("MemoValue 값", memoValue) // 값 저장
    }
    // 플레이스 홀더 관련 설정
    //    func textViewDidBeginEditing(_ textView: UITextView) {
    //        if textView.textColor == .placeholderText || textView.text == "메모를 입력하세요." {
    //            textView.text = nil
    //            textView.textColor = .label
    //        }
    //    }
    //    // 플레이스 홀더 관련 설정
    //    func textViewDidEndEditing(_ textView: UITextView) {
    //        if textView.text.isEmpty || textView.text == "메모를 입력하세요." {
    //            //textView.text = String(describing: UrlAndMemoList.memo)
    //            //textView.text = "메모를 입력하세요."
    //            //textView.textColor = .placeholderText
    //
    //        }
    //    }
}

//MARK: - extension UIImagePicker
extension AddViewController: UIImagePickerControllerDelegate,  UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            mainView.addTableHeaderView.addOrEditImageButton.setTitle("편집", for: .normal)
            mainView.addTableHeaderView.itemImageView.image = image
            createdImageData = Date()
            print(image)
            print("카메라로 촬영된 이미지 가져옴")
            unwind(style: .dismiss)
            
        }
    }
}

//MARK: - extension PHPIckerViewController
extension AddViewController: PHPickerViewControllerDelegate {
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        
        picker.dismiss(animated: true)
        
        let itemProvider = results.first?.itemProvider
        
        if let itemProvider = itemProvider, itemProvider.canLoadObject(ofClass: UIImage.self) {
            itemProvider.loadObject(ofClass: UIImage.self) { [weak self] image, error in
                guard let self = self else { return }
                DispatchQueue.main.async {
                    self.mainView.addTableHeaderView.addOrEditImageButton.setTitle("편집", for: .normal)
                    self.mainView.addTableHeaderView.itemImageView.image = image as? UIImage
                    self.createdImageData = Date()
                }
            }
        } else {
            print("PHPickerViewController 오류 발생")
        }
    }
}

//MARK: - extension 값전달 프로토콜
extension AddViewController: SelectedFitCellDelegate {
    func sendSelectedFitData(indexPathRow: Int) {
        selectedFitIndexPathRow = indexPathRow
        mainView.tableView.reloadSections(IndexSet(Section.info.rawValue...Section.info.rawValue), with: .none)
        print(#function)
    }
}

extension AddViewController: SelectedResultCellDelegate {
    func sendSelectedResultData(indexPathRow: Int) {
        selectedResultIndexPathRow = indexPathRow
        mainView.tableView.reloadSections(IndexSet(Section.info.rawValue...Section.info.rawValue), with: .none)
        print(#function)
    }
}
