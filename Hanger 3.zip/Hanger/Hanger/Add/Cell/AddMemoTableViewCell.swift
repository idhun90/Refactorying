import UIKit

import SnapKit

final class AddMemoTableViewCell: BaseTableViewCell {
    
    let memoTextView: UITextView = {
        let view = UITextView(frame: .zero)
        view.text = ""
        //view.textColor = .placeholderText
        view.font = .systemFont(ofSize: 17)
        view.backgroundColor = .customSecondaraySystemBackgroundColor
        let spacing: CGFloat = 15
        view.textContainerInset = UIEdgeInsets(top: spacing, left: spacing, bottom: 0, right: spacing)
        view.keyboardType = .default
        view.returnKeyType = .next
        return view
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super .init(style: style, reuseIdentifier: reuseIdentifier)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func configureUI() {
        super.configureUI()
        backgroundColor = .customCellBackgroundColor
        
        contentView.addSubview(memoTextView)
    }
    
    override func setConstraints() {
        super.setConstraints()
        memoTextView.snp.makeConstraints {
            $0.top.leading.trailing.equalTo(contentView)
            $0.bottom.equalTo(contentView).offset(-10)
        }
    }
}

