import UIKit

final class AddRealSizeTableViewCell: BaseTableViewCell {
    
    let textField: CustomTextField = {
        let view = CustomTextField()
        view.configureUI(placeholder: nil, fontSize: 17)
        view.returnKeyType = .done
        return view
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: .value1, reuseIdentifier: reuseIdentifier)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupTextField(inputList: String) {
        textField.placeholder = inputList
    }
    
    override func configureUI() {
        super.configureUI()
        selectionStyle = .none
        backgroundColor = .customCellBackgroundColor
        
        contentView.addSubview(textField)
    }
    
    override func setConstraints() {
        super.setConstraints()
        textField.snp.makeConstraints {
            let spacing = 20
            $0.top.bottom.leading.equalTo(contentView)
            $0.trailing.equalTo(contentView).offset(-spacing)
        }
    }
}
