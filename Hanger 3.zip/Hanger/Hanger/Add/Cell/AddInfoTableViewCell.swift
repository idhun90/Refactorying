import UIKit

import SnapKit

final class AddInfoTableViewCell: BaseTableViewCell {
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super .init(style: .value1, reuseIdentifier: reuseIdentifier)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func configureUI() {
        super.configureUI()
        accessoryType = .disclosureIndicator //accessoryView 쓰면 안 써도 됨
        //accessoryView = UIImageView(image: UIImage(systemName: "chevron.up.chevron.down")) //캘린더처럼 하려면 swiftUI로 구현해야 한다고 함.
        //accessoryView?.tintColor = .secondaryLabel
        backgroundColor = .customCellBackgroundColor
    }
    
    func setup(text: String, secondaryText: String) {
        var content = defaultContentConfiguration()
        content.attributedText = NSAttributedString(string: text, attributes: [.font: UIFont.systemFont(ofSize: 17), .foregroundColor: UIColor.label])
        content.secondaryAttributedText = NSAttributedString(string: secondaryText, attributes: [.font: UIFont.systemFont(ofSize: 17), .foregroundColor: UIColor.secondaryLabel])
        contentConfiguration = content
    }
}
