import UIKit

import SnapKit

final class AddView: BaseView {
    
    let addTableHeaderView: AddTableHeaderView = {
        let view = AddTableHeaderView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.width * 0.55))
        return view
    }()
    
    lazy var tableView: UITableView = {
        let view = UITableView(frame: .zero, style: .insetGrouped)
        view.register(AddInputTableViewCell.self, forCellReuseIdentifier: AddInputTableViewCell.reusableIdentifier)
        view.register(AddInfoTableViewCell.self, forCellReuseIdentifier: AddInfoTableViewCell.reusableIdentifier)
        view.register(AddRealSizeTableViewCell.self, forCellReuseIdentifier: AddRealSizeTableViewCell.reusableIdentifier)
        view.register(AddUrlTableViewCell.self, forCellReuseIdentifier: AddUrlTableViewCell.reusableIdentifier)
        view.register(AddMemoTableViewCell.self, forCellReuseIdentifier: AddMemoTableViewCell.reusableIdentifier)
        view.tableHeaderView = addTableHeaderView
        view.keyboardDismissMode = .onDrag
        view.backgroundColor = .customBackgroundColor
        //print(view.sectionHeaderHeight)
        //print(view.sectionFooterHeight)
        //view.sectionFooterHeight = 0 // 효과 있음
        //view.sectionHeaderHeight =  // 이건 잘 모르겠음
        //view.sectionHeaderTopPadding = 0.0 // insetGrouped에서 안 됨
        return view
    }()
    
    let pickerView: UIDatePicker = {
        let view = UIDatePicker()
        view.datePickerMode = .date
        view.preferredDatePickerStyle = .wheels
        view.backgroundColor = .customSecondaraySystemBackgroundColor
        view.tintColor = .label
        view.maximumDate = Date()
        view.locale = Locale(identifier: "ko_KR")
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func configureUI() {
        super.configureUI()
        [tableView].forEach {
            addSubview($0)
        }
    }
    
    override func setConstraints() {
        super.setConstraints()
        tableView.snp.makeConstraints {
            $0.edges.equalToSuperview()
            //$0.bottom.equalTo(self.keyboardLayoutGuide.snp.top) //오픈소스 대체
        }
    }
}
