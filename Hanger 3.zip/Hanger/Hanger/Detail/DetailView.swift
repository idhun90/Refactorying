import UIKit

import SnapKit

final class DetailView: BaseView {
    
    let outerOrTopTableHeaderView: DetailTableHeaderView = {
        let view = DetailTableHeaderView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.width * 0.55))
        return view
    }()
    
    lazy var tableView: UITableView = {
        let view = UITableView(frame: .zero, style: .insetGrouped)
        view.tableHeaderView = outerOrTopTableHeaderView
        view.keyboardDismissMode = .onDrag
        view.backgroundColor = .customBackgroundColor
        view.register(DetailTableViewCell.self, forCellReuseIdentifier: DetailTableViewCell.reusableIdentifier)
        return view
        
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func configureUI() {
        super.configureUI()
        addSubview(tableView)
    }
    
    override func setConstraints() {
        super.setConstraints()
        tableView.snp.makeConstraints {
            $0.edges.equalToSuperview()
        }
    }
    
}
