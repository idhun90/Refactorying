import UIKit
import SafariServices

final class DetailViewController: BaseViewController {
    
    private let mainView = DetailView()
    
    private let itemRepository = ItemRepository()
    var itemData: Item?
    
    private var selectedCategory: String = ""
    private var inputValue: [String]?
    private var fitIndexPathRow: Int?
    private var resultIndexPathRow: Int?
    private var realSizeValue: [String]?
    private var urlValue: String?
    private var memoValue: String?
    
    // [입력항목] 빈 값 cell 가리기 위한 목적
    private var filteredEmptyInputList: [String] = []
    private var filteredEmptyInputValue: [String] = []
    
    // [실측사이즈] 모든 실측 사이즈 빈값인지 체크
    private var isRealSizeAllEmpty: Bool = false
    
    // [구매링크 및 메모]
    private var isUrlEmpty: Bool = false
    private var isMemoEmpty: Bool = false
    
    override func loadView() {
        view = mainView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setNavigationController()
        setTableView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadItemData()
        setupFilteredEmpty()
        isRealSizeAllEmpty = isAllRealSizeEmpty()
        isUrlEmpty = checkUrlOrMemoIsEmpty(value: urlValue)
        isMemoEmpty = checkUrlOrMemoIsEmpty(value: memoValue)
        mainView.tableView.reloadData()
    }
    
    private func loadItemData() {
        guard let itemData = itemData else {
            print("데이터가 없습니다.")
            return
        }
        
        selectedCategory = itemData.category
        mainView.outerOrTopTableHeaderView.itemImageView.image = loadImageFromImageDirectory(fileName: "\(itemData.objectId).jpg")
        inputValue = itemData.inputArray
        //inputValue![4] = formatterDecimal(money: itemData.inputArray[4])
        fitIndexPathRow = itemData.fit
        resultIndexPathRow = itemData.result
        realSizeValue = itemData.realSizeArray
        urlValue = itemData.url
        memoValue = itemData.memo
        
    }
    
    private func setupFilteredEmpty() {
        guard let inputValue = inputValue else {
            print("필터할 데이터가 없습니다.")
            return
        }
        
        let inputListArray = InputList.allCases.map { "\($0)" }
        filteredEmptyInputList = deletedEmptySectionTitleArray(title: inputListArray, subTitle: inputValue, deleteValue: "")
        
        filteredEmptyInputValue = inputValue.filter { $0.trimmingCharacters(in: .whitespacesAndNewlines) != "" }
    }
    
    // 뷰에 보여줄 때만 컴마 추가
//    private func formatterDecimal(money: String) -> String {
//        let numberFormatter = NumberFormatter()
//        numberFormatter.numberStyle = .decimal
//        let formatted = numberFormatter.string(for: Int(money))!
//
//        return formatted
//    }
    
    //MARK: - 테이블뷰 항목 배열 빈 요소 필터링(입력항목)
    private func deletedEmptySectionTitleArray(title: [String], subTitle: [String], deleteValue: String) -> [String] {
        var titleArray = title // 테이블 뷰 항목 배열
        var subTitleArray = subTitle // 테이블 뷰에 입력될 값 배열

        for item in subTitleArray {
            if item.trimmingCharacters(in: .whitespacesAndNewlines) == deleteValue, let index = subTitleArray.firstIndex(of: item) {
                subTitleArray.remove(at: index)
                titleArray.remove(at: index)
            }
        }
        
        return titleArray
    }
    
    //MARK: - 실측 사이즈 배열 모든 값이 빈값인지 체크(실측사이즈)
    private func isAllRealSizeEmpty() -> Bool {
        guard let realSizeValue = realSizeValue else { return false }
        
        let testArray = realSizeValue.filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        let result = testArray.isEmpty
        
        return result
    }
    
    //MARK: - 구매 링크 또는 메모 값이 빈값인지 체크
    private func checkUrlOrMemoIsEmpty(value: String?) -> Bool {
        guard let testValue = value else { return false }
        return testValue.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
    
    private func openUrlWithSafari() {
        guard let urlValue = urlValue else { return }
        
        let encodedUrlString = urlValue.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)! // 한글 인코딩
        
        guard let url = URL(string: encodedUrlString) else {
            showAlret(title: "유효한 URL이 아닙니다.", message: nil)
            return
        }
        
        if url.scheme == nil {
            guard let addedSchemeUrl = URL(string: "https://\(url.absoluteString)") else {
                showAlret(title: "scheme 추가 실패", message: nil)
                return }
            let safariController = SFSafariViewController(url: addedSchemeUrl)
            safariController.preferredControlTintColor = .label
            present(safariController, animated: true)
        } else {
            let safariController = SFSafariViewController(url: url)
            safariController.preferredControlTintColor = .label
            present(safariController, animated: true)
        }
    }

    private func setTableView() {
        mainView.tableView.dataSource = self
        mainView.tableView.delegate = self
    }
    
    private func setNavigationController() {
        navigationItem.largeTitleDisplayMode = .never
        let rightBarButton = UIBarButtonItem(image: UIImage(systemName: "ellipsis.circle"), primaryAction: nil, menu: setupUIMenu())
        navigationItem.rightBarButtonItems = [rightBarButton]
    }
    
    private func setupUIMenu() -> UIMenu {
        var children: [UIAction] {
            let editButton = UIAction(title: "편집", image: UIImage(systemName: "pencil")) { [weak self] _ in
                guard let self = self else { return }
                let vc = AddViewController()
                vc.loadItemData(data: self.itemData)
                print("데이터 전달")
                self.transition(viewController: vc, style: .present, animated: true)
            }
            
            let deleteButton = UIAction(title: "삭제", image: UIImage(systemName: "trash"), attributes: .destructive) { [weak self] _ in
                guard let self = self else { return }
                guard let itemData = self.itemData else {
                    print("itemData가 없어서 삭제에 실패했습니다")
                    return
                }
                
                let alert = UIAlertController(title: "아이템을 삭제하겠습니까?", message: nil, preferredStyle: .actionSheet)
                let ok = UIAlertAction(title: "삭제", style: .destructive) { [weak self] _ in
                    guard let self = self else { return }
                    self.removeImage(fileName: "\(itemData.objectId).jpg")
                    self.itemRepository.fetchDeleteItem(item: itemData)
                    self.unwind(style: .pop)
                }
                let cancel = UIAlertAction(title: "취소", style: .cancel)
                cancel.setValue(UIColor.label, forKey: "titleTextColor")
                
                alert.addAction(ok)
                alert.addAction(cancel)
                self.present(alert, animated: true)
            }
            
            return [editButton, deleteButton]
        }
        let menu = UIMenu(title: "", options: .displayInline, children: children)
        return menu
    }
}

extension DetailViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        switch selectedCategory {
        case String(describing: SelectedCategory.outer), String(describing: SelectedCategory.top), String(describing: SelectedCategory.bottom) :
            
            if isRealSizeAllEmpty {
                
                return (isUrlEmpty && isMemoEmpty) ? 2 : 3
                
            } else {
                
                return (isUrlEmpty && isMemoEmpty) ? 3 : 4
                
            }

        case String(describing: SelectedCategory.shoes), String(describing: SelectedCategory.acc):
            return (isUrlEmpty && isMemoEmpty) ? 2 : 3
            
        default :
            return 0
        }
        
    }
    
//    func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
//        
//        guard let section = Section(rawValue: section) else { return nil }
//        
//        switch section {
//        case .input:
//            return filteredEmptyInputList.contains("가격") ? "화폐 단위는 원입니다." : nil
//            
//        case .realSize:
//            if selectedCategory == String(describing: SelectedCategory.outer) || selectedCategory == String(describing: SelectedCategory.top) || selectedCategory == String(describing: SelectedCategory.bottom) {
//                
//                return isRealSizeAllEmpty ? nil : "단위는 cm입니다."
//                
//            } else {
//                return nil
//            }
//        default:
//            return nil
//        }
//    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        guard let section = Section(rawValue: section) else { return 0 }
        
        switch section {
        case .input:
            return filteredEmptyInputList.count
            
        case .info:
            if selectedCategory == String(describing: SelectedCategory.outer) || selectedCategory == String(describing: SelectedCategory.top) || selectedCategory == String(describing: SelectedCategory.bottom) {
                return InfoList.allCases.count
            } else {
                return InfoList.infoResult.rawValue
            }
        case .realSize:
            if selectedCategory == String(describing: SelectedCategory.outer) || selectedCategory == String(describing: SelectedCategory.top) {
                
                if isRealSizeAllEmpty {
                    if (isUrlEmpty && isMemoEmpty) {
                        return 0
                    } else if (!isUrlEmpty && !isMemoEmpty) {
                        return UrlAndMemoList.allCases.count
                    } else {
                        return 1
                    }
                } else {
                    return RealSizeOptions.realSizeOuterOrTop.contents.count
                }

            } else if selectedCategory == String(describing: SelectedCategory.bottom) {
                
                if isRealSizeAllEmpty {
                    if (isUrlEmpty && isMemoEmpty) {
                        return 0
                    } else if (!isUrlEmpty && !isMemoEmpty) {
                        return UrlAndMemoList.allCases.count
                    } else {
                        return 1
                    }
                } else {
                    return RealSizeOptions.realSizeBottom.contents.count
                }
            } else {
                
                if (isUrlEmpty && isMemoEmpty) {
                    return 0
                } else if (!isUrlEmpty && !isMemoEmpty) {
                    return UrlAndMemoList.allCases.count
                } else {
                    return 1
                }
            }
        case .urlAndMemo:
            if selectedCategory == String(describing: SelectedCategory.outer) || selectedCategory == String(describing: SelectedCategory.top) || selectedCategory == String(describing: SelectedCategory.bottom) {
                
                if !isRealSizeAllEmpty {
                    if (isUrlEmpty && isMemoEmpty) {
                        return 0
                    } else if (!isUrlEmpty && !isMemoEmpty) {
                        return UrlAndMemoList.allCases.count
                    } else {
                        return 1
                    }
                } else {
                    return 0
                }
            } else {
                return 0
            }
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: DetailTableViewCell.reusableIdentifier, for: indexPath) as? DetailTableViewCell else { return UITableViewCell() }
        
        switch indexPath.section {
        case Section.input.rawValue:

            cell.setup(text: filteredEmptyInputList[indexPath.row],
                       secondText: filteredEmptyInputList[indexPath.row] == "가격" ? "\(filteredEmptyInputValue[indexPath.row])원" : filteredEmptyInputValue[indexPath.row],
                       numberOfLines: 1,
                       secondaryTextColor: .label,
                       selectionStyle: .none,
                       SideBySideTextAndSecondaryText: false,
                       accessoryType: .none)
            
            return cell
            
        case Section.info.rawValue:
            
            if selectedCategory == String(describing: SelectedCategory.outer) || selectedCategory == String(describing: SelectedCategory.top) || selectedCategory == String(describing: SelectedCategory.bottom) {
                
                switch indexPath {
                case [Section.info.rawValue, 0]:
                    
                    cell.setup(text: String(describing: InfoList.infoFit),
                               secondText: InfoList.infoFit.secondaryText[fitIndexPathRow!],
                               numberOfLines: 1,
                               secondaryTextColor: .label,
                               selectionStyle: .none,
                               SideBySideTextAndSecondaryText: false,
                               accessoryType: .none)
                    
                case [Section.info.rawValue, 1]:
                    
                    cell.setup(text: String(describing: InfoList.infoResult),
                               secondText: InfoList.infoResult.secondaryText[resultIndexPathRow!],
                               numberOfLines: 1,
                               secondaryTextColor: .label,
                               selectionStyle: .none,
                               SideBySideTextAndSecondaryText: false,
                               accessoryType: .none)
                default:
                    return UITableViewCell()
                    
                }
                
            } else {
                
                cell.setup(text: String(describing: InfoList.infoResult),
                           secondText: InfoList.infoResult.secondaryText[resultIndexPathRow!],
                           numberOfLines: 1,
                           secondaryTextColor: .label,
                           selectionStyle: .none,
                           SideBySideTextAndSecondaryText: false,
                           accessoryType: .none)
            }
            
            return cell
            
        case Section.realSize.rawValue:
            
            guard let realSizeValue = realSizeValue else {
                print("realSize 데이터가 없습니다.")
                return UITableViewCell()
            }
            
            if selectedCategory == String(describing: SelectedCategory.outer) || selectedCategory == String(describing: SelectedCategory.top) {
                
                if isRealSizeAllEmpty {
                    
                    if (isUrlEmpty && isMemoEmpty) {
                        
                        return UITableViewCell()
                        
                    } else if (!isUrlEmpty && isMemoEmpty) {
                        
                        cell.setup(text: String(describing: UrlAndMemoList.url),
                                   secondText: urlValue!,
                                   numberOfLines: 1,
                                   secondaryTextColor: .link,
                                   selectionStyle: .default,
                                   SideBySideTextAndSecondaryText: false,
                                   accessoryType: .disclosureIndicator)
                        
                    } else if (isUrlEmpty && !isMemoEmpty) {
                        
                        cell.setup(text: String(describing: UrlAndMemoList.memo),
                                   secondText: memoValue!,
                                   numberOfLines: 0,
                                   secondaryTextColor: .label,
                                   selectionStyle: .none,
                                   SideBySideTextAndSecondaryText: false,
                                   accessoryType: .none)
                        
                    } else {
                        
                        if indexPath == [Section.realSize.rawValue, 0] {
                            cell.setup(text: String(describing: UrlAndMemoList.url),
                                       secondText: urlValue!,
                                       numberOfLines: 1,
                                       secondaryTextColor: .link,
                                       selectionStyle: .default,
                                       SideBySideTextAndSecondaryText: false,
                                       accessoryType: .disclosureIndicator)
                            
                        } else if indexPath == [Section.realSize.rawValue, 1] {
                            cell.setup(text: String(describing: UrlAndMemoList.memo),
                                       secondText: memoValue!,
                                       numberOfLines: 0,
                                       secondaryTextColor: .label,
                                       selectionStyle: .none,
                                       SideBySideTextAndSecondaryText: false,
                                       accessoryType: .none)
                        }
                    }

                } else {
                    
                    cell.setup(text: String(describing: RealSizeOptions.realSizeOuterOrTop.contents[indexPath.row]),
                               secondText: realSizeValue[indexPath.row] == "" ? "-" : "\(realSizeValue[indexPath.row])cm",
                               numberOfLines: 1,
                               secondaryTextColor: .label,
                               selectionStyle: .none,
                               SideBySideTextAndSecondaryText: false,
                               accessoryType: .none)
                }

            } else if selectedCategory == String(describing: SelectedCategory.bottom) {
                
                if isRealSizeAllEmpty {
                    
                    if (isUrlEmpty && isMemoEmpty) {
                        
                        return UITableViewCell()
                        
                    } else if (!isUrlEmpty && isMemoEmpty) {
                        
                        cell.setup(text: String(describing: UrlAndMemoList.url),
                                   secondText: urlValue!,
                                   numberOfLines: 1,
                                   secondaryTextColor: .link,
                                   selectionStyle: .default,
                                   SideBySideTextAndSecondaryText: false,
                                   accessoryType: .disclosureIndicator)
                        
                    } else if (isUrlEmpty && !isMemoEmpty) {
                        
                        cell.setup(text: String(describing: UrlAndMemoList.memo),
                                   secondText: memoValue!,
                                   numberOfLines: 0,
                                   secondaryTextColor: .label,
                                   selectionStyle: .none,
                                   SideBySideTextAndSecondaryText: false,
                                   accessoryType: .none)
                        
                    } else {
                        
                        if indexPath == [Section.realSize.rawValue, 0] {
                            cell.setup(text: String(describing: UrlAndMemoList.url),
                                       secondText: urlValue!,
                                       numberOfLines: 1,
                                       secondaryTextColor: .link,
                                       selectionStyle: .default,
                                       SideBySideTextAndSecondaryText: false,
                                       accessoryType: .disclosureIndicator)
                            
                        } else if indexPath == [Section.realSize.rawValue, 1] {
                            cell.setup(text: String(describing: UrlAndMemoList.memo),
                                       secondText: memoValue!,
                                       numberOfLines: 0,
                                       secondaryTextColor: .label,
                                       selectionStyle: .none,
                                       SideBySideTextAndSecondaryText: false,
                                       accessoryType: .none)
                        }
                    }

                } else {
                    
                    cell.setup(text: String(describing: RealSizeOptions.realSizeBottom.contents[indexPath.row]),
                               secondText: realSizeValue[indexPath.row] == "" ? "-" : "\(realSizeValue[indexPath.row])cm",
                               numberOfLines: 1,
                               secondaryTextColor: .label,
                               selectionStyle: .none,
                               SideBySideTextAndSecondaryText: false,
                               accessoryType: .none)
                }
                
            } else {
                
                if (isUrlEmpty && isMemoEmpty) {
                    
                    return UITableViewCell()
                    
                } else if (!isUrlEmpty && isMemoEmpty) {
                    
                    cell.setup(text: String(describing: UrlAndMemoList.url),
                               secondText: urlValue!,
                               numberOfLines: 1,
                               secondaryTextColor: .link,
                               selectionStyle: .default,
                               SideBySideTextAndSecondaryText: false,
                               accessoryType: .disclosureIndicator)
                    
                } else if (isUrlEmpty && !isMemoEmpty) {
                    
                    cell.setup(text: String(describing: UrlAndMemoList.memo),
                               secondText: memoValue!,
                               numberOfLines: 0,
                               secondaryTextColor: .label,
                               selectionStyle: .none,
                               SideBySideTextAndSecondaryText: false,
                               accessoryType: .none)
                    
                } else {
                    
                    if indexPath == [Section.realSize.rawValue, 0] {
                        cell.setup(text: String(describing: UrlAndMemoList.url),
                                   secondText: urlValue!,
                                   numberOfLines: 1,
                                   secondaryTextColor: .link,
                                   selectionStyle: .default,
                                   SideBySideTextAndSecondaryText: false,
                                   accessoryType: .disclosureIndicator)
                        
                    } else if indexPath == [Section.realSize.rawValue, 1] {
                        cell.setup(text: String(describing: UrlAndMemoList.memo),
                                   secondText: memoValue!,
                                   numberOfLines: 0,
                                   secondaryTextColor: .label,
                                   selectionStyle: .none,
                                   SideBySideTextAndSecondaryText: false,
                                   accessoryType: .none)
                    }
                }
            }
            
            return cell
            
        case Section.urlAndMemo.rawValue:
            
            if selectedCategory == String(describing: SelectedCategory.outer) || selectedCategory == String(describing: SelectedCategory.top) || selectedCategory == String(describing: SelectedCategory.bottom) {
                
                if !isRealSizeAllEmpty {
                    
                    if (isUrlEmpty && isMemoEmpty) {
                        
                        return UITableViewCell()
                        
                    } else if (!isUrlEmpty && isMemoEmpty) {
                        
                        cell.setup(text: String(describing: UrlAndMemoList.url),
                                   secondText: urlValue!,
                                   numberOfLines: 1,
                                   secondaryTextColor: .link,
                                   selectionStyle: .default,
                                   SideBySideTextAndSecondaryText: false,
                                   accessoryType: .disclosureIndicator)
                        
                    } else if (isUrlEmpty && !isMemoEmpty) {
                        
                        cell.setup(text: String(describing: UrlAndMemoList.memo),
                                   secondText: memoValue!,
                                   numberOfLines: 0,
                                   secondaryTextColor: .label,
                                   selectionStyle: .none,
                                   SideBySideTextAndSecondaryText: false,
                                   accessoryType: .none)
                        
                    } else {
                        
                        if indexPath == [Section.urlAndMemo.rawValue, 0] {
                            cell.setup(text: String(describing: UrlAndMemoList.url),
                                       secondText: urlValue!,
                                       numberOfLines: 1,
                                       secondaryTextColor: .link,
                                       selectionStyle: .default,
                                       SideBySideTextAndSecondaryText: false,
                                       accessoryType: .disclosureIndicator)
                            
                        } else if indexPath == [Section.urlAndMemo.rawValue, 1] {
                            cell.setup(text: String(describing: UrlAndMemoList.memo),
                                       secondText: memoValue!,
                                       numberOfLines: 0,
                                       secondaryTextColor: .label,
                                       selectionStyle: .none,
                                       SideBySideTextAndSecondaryText: false,
                                       accessoryType: .none)
                        }
                    }
                    
                    return cell
                    
                } else {
                    return UITableViewCell()
                }
                
            } else {
                return UITableViewCell()
            }

        default:
            return UITableViewCell()
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        
        switch selectedCategory {
        case String(describing: SelectedCategory.outer), String(describing: SelectedCategory.top), String(describing: SelectedCategory.bottom) : // 아우터/상의/하의
            
            if !isUrlEmpty {
                if isRealSizeAllEmpty {
                    if indexPath == [2, 0] {
                        openUrlWithSafari()
                    }
                } else {
                    if indexPath == [3, 0] {
                        openUrlWithSafari()
                    }
                }
            }
            
        case String(describing: SelectedCategory.shoes), String(describing: SelectedCategory.acc) : // 신발/액세서리
            
            if !isUrlEmpty {
                if indexPath == [2, 0] {
                    openUrlWithSafari()
                }
            }
            
        default:
            print("URL 작업 오류")
        }
    }
}

