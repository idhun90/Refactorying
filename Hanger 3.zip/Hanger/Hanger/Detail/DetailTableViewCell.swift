import UIKit

final class DetailTableViewCell: BaseTableViewCell {
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: .value1, reuseIdentifier: reuseIdentifier)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setup(text: String, secondText: String, numberOfLines: Int, secondaryTextColor: UIColor, selectionStyle: UITableViewCell.SelectionStyle, SideBySideTextAndSecondaryText: Bool, accessoryType: UITableViewCell.AccessoryType) {
        var content = self.defaultContentConfiguration()
//        content.attributedText = NSAttributedString(string: text, attributes: [.font: UIFont.systemFont(ofSize: 14), .foregroundColor: UIColor.secondaryLabel])
//        content.secondaryAttributedText = NSAttributedString(string: secondText, attributes: [.font: UIFont.systemFont(ofSize: 16, weight: .regular), .foregroundColor: secondaryTextColor])

        content.attributedText = NSAttributedString(string: text, attributes: [.font: UIFont.preferredFont(forTextStyle: .footnote), .foregroundColor: UIColor.secondaryLabel])
        content.secondaryAttributedText = NSAttributedString(string: secondText, attributes: [.font: UIFont.preferredFont(forTextStyle: .body), .foregroundColor: secondaryTextColor])

        //content.attributedText = NSAttributedString(string: text, attributes: [.font: UIFont.systemFont(ofSize: 13), .foregroundColor: UIColor.secondaryLabel])
        //content.secondaryAttributedText = NSAttributedString(string: secondText, attributes: [.font: UIFont.systemFont(ofSize: 16), .foregroundColor: secondaryTextColor])
        
        content.secondaryTextProperties.numberOfLines = numberOfLines
        content.prefersSideBySideTextAndSecondaryText = SideBySideTextAndSecondaryText
        //content.textToSecondaryTextVerticalPadding = 4
        //print(content.textToSecondaryTextVerticalPadding)
    
        contentConfiguration = content
        self.selectionStyle = selectionStyle
        self.accessoryType = accessoryType
    }
    
    override func configureUI() {
        super.configureUI()
        selectionStyle = .none
        backgroundColor = .customCellBackgroundColor
    }
    
}
