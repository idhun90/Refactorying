import UIKit

import SnapKit

final class DetailTableHeaderView: BaseView {
    
    let itemImageView: UIImageView = {
        let view = UIImageView()
        //view.backgroundColor = .customSecondaraySystemBackgroundColor
        view.backgroundColor = .customCellBackgroundColor
        view.layer.masksToBounds = true
        view.layer.cornerRadius = 10
        view.layer.borderWidth = 1.0 / view.traitCollection.displayScale
        view.contentMode = .scaleAspectFill
        return view
    }()
    
    let addOrEditImageButton: UIButton = {
        let view = UIButton(type: .system)
        view.setTitle("사진 추가", for: .normal)
        view.titleLabel?.font = .systemFont(ofSize: 15)
        view.tintColor = .label
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        itemImageView.layer.borderColor = UIColor.systemGray5.cgColor
    }
    
    override func configureUI() {
        super.configureUI()
        addSubview(itemImageView)
        addSubview(addOrEditImageButton)
        backgroundColor = .customBackgroundColor
    }
    
    override func setConstraints() {
        itemImageView.snp.makeConstraints {
            //$0.center.equalToSuperview()
            $0.centerY.equalToSuperview().offset(-10)
            $0.centerX.equalToSuperview()
            $0.height.equalTo(self.frame.height * 0.8)
            $0.width.equalTo(itemImageView.snp.height)
        }
    }
}

