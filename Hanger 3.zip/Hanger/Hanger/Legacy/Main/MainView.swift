import UIKit

import SnapKit

final class MainView: BaseView {
    
    lazy var tableView: UITableView = {
        let view = UITableView(frame: .zero, style: .grouped)
        view.register(MainTableViewCell.self, forCellReuseIdentifier: MainTableViewCell.reusableIdentifier)
        view.register(MainTableViewHeaderFooterView.self, forHeaderFooterViewReuseIdentifier: MainTableViewHeaderFooterView.reusableIdentifier)
        view.backgroundColor = .customBackgroundColor
//        view.separatorStyle = .none
        view.separatorColor = .clear
        //print("이건 뭐였지", view.separatorInset) // 기본 inset값
        return view
    }()
    
    let emptyLabel: UILabel = {
        let view = UILabel()
        view.text = "추가된 아이템이 없어요."
        view.font = .systemFont(ofSize: 16, weight: .bold)
        view.textColor = .secondaryLabel
        return view
    }()
    
    let emptySubLabel: UILabel = {
        let view = UILabel()
        view.text = "+ 버튼으로 새로운 아이템을 등록해 보세요."
        view.font = .systemFont(ofSize: 14, weight: .regular)
        view.textColor = .secondaryLabel
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func configureUI() {
        self.addSubview(tableView)
        self.addSubview(emptyLabel)
        self.addSubview(emptySubLabel)
        
    }
    
    override func setConstraints() {
        tableView.snp.makeConstraints {
            $0.edges.equalToSuperview()
        }
        emptyLabel.snp.makeConstraints {
            $0.center.equalToSuperview()
        }
        emptySubLabel.snp.makeConstraints {
            $0.centerX.equalToSuperview()
            $0.top.equalTo(emptyLabel.snp.bottom).offset(10)
        }
    }
}
