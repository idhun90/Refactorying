import UIKit

import SnapKit

final class MainTableViewHeaderFooterView: BaseTableViewHeaderFooterView {
    
    let sectionTitleLabel: UILabel = {
        let view = UILabel()
        view.font = .systemFont(ofSize: 22, weight: .bold)
        return view
    }()
    
    let moreButton: UIButton = {
        let view = UIButton()
        var configuration = UIButton.Configuration.plain()
        configuration.title = "모두 보기"
        configuration.baseForegroundColor = .secondaryLabel
        configuration.buttonSize = .medium
        view.configuration = configuration
        view.isHidden = true
        return view
    }()
    
    override init(reuseIdentifier: String?) {
        super .init(reuseIdentifier: reuseIdentifier)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func configureUI() {
        self.contentView.addSubview(sectionTitleLabel)
        self.contentView.addSubview(moreButton)
        self.contentView.backgroundColor = .clear
        
    }
    
    override func setConstraints() {
        sectionTitleLabel.snp.makeConstraints {
            let spacing = 20
            $0.top.bottom.equalTo(self.contentView)
            $0.leading.equalTo(self.contentView.snp.leading).offset(spacing)
            $0.trailing.lessThanOrEqualTo(self.contentView.snp.trailing).offset(-spacing)
        }
        
        moreButton.snp.makeConstraints {
            $0.trailing.equalTo(self.contentView).offset(-7)
            $0.centerY.equalTo(self.contentView)
        }
    }
}
