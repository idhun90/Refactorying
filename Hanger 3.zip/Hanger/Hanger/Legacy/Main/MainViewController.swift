import UIKit
import SafariServices

import SnapKit
import RealmSwift
import FirebaseAnalytics

final class MainViewController: BaseViewController {
    
    let mainView = MainView()
    
    let itemRepository = ItemRepository()
    var items: Results<Item>!

    override func loadView() {
        self.view = mainView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //print("네비 큰 타이틀 리딩 패딩:", self.navigationController?.systemMinimumLayoutMargins.leading ?? 0) // 라지타이틀 리딩 값
        items = itemRepository.fetchItem()
        print(itemRepository.fetchItemPath())
        
        //Analytics.logEvent("테스트", parameters: nil)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        showHiddenEmptyLabel()
        self.mainView.tableView.reloadData()
    }

    override func configureUI() {
        setNavigationController()
        setBarButtonItems()
        setTableView()
    }
    
    func setTableView() {
        self.mainView.tableView.delegate = self
        self.mainView.tableView.dataSource = self
    }
    
    func setNavigationController() {
        self.navigationItem.title = "나의 옷"
        self.navigationController?.navigationBar.prefersLargeTitles = true
    }
    
    func setBarButtonItems() {
        let rightBarButton = UIBarButtonItem(systemItem: .add, primaryAction: nil, menu: setupUIMenu())
        navigationItem.rightBarButtonItems = [rightBarButton]
    }

    func setupUIMenu() -> UIMenu {
        var childeren: [UIAction] {
            let outer = UIAction(title: "\(String(describing: SelectedCategory.outer)) 추가") { _ in
                let vc = AddViewController()
                vc.selectedCategory = String(describing: SelectedCategory.outer)
                self.transition(viewController: vc, style: .present, animated: true)
            }
            let top = UIAction(title: "\(String(describing: SelectedCategory.top)) 추가") { _ in
                let vc = AddViewController()
                vc.selectedCategory = String(describing: SelectedCategory.top)
                self.transition(viewController: vc, style: .present, animated: true)
            }
            let bottom = UIAction(title: "\(String(describing: SelectedCategory.bottom)) 추가") { _ in
                let vc = AddViewController()
                vc.selectedCategory = String(describing: SelectedCategory.bottom)
                self.transition(viewController: vc, style: .present, animated: true)
            }
            let shoes = UIAction(title: "\(String(describing: SelectedCategory.shoes)) 추가") { _ in
                let vc = AddViewController()
                vc.selectedCategory = String(describing: SelectedCategory.shoes)
                self.transition(viewController: vc, style: .present, animated: true)
            }
            let acc = UIAction(title: "\(String(describing: SelectedCategory.acc)) 추가") { _ in
                let vc = AddViewController()
                vc.selectedCategory = String(describing: SelectedCategory.acc)
                self.transition(viewController: vc, style: .present, animated: true)
            }
            
            return [outer, top, bottom, shoes, acc]
        }
        let menu = UIMenu(title: "", options: .displayInline, children: childeren)
        return menu
    }
    
    func showHiddenEmptyLabel() {
        if items.count == 0 {
            self.mainView.emptyLabel.isHidden = false
            self.mainView.emptySubLabel.isHidden = false
        } else {
            self.mainView.emptyLabel.isHidden = true
            self.mainView.emptySubLabel.isHidden = true
        }
    }
    
    func showSFSafariViewController(itemUrl: String) {
        
        if itemUrl != "" {
            
            let encodedUrlValue = itemUrl.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
            
            guard let url = URL(string: encodedUrlValue) else {
                self.showAlret(title: "유효한 URL이 아닙니다.", message: nil)
                return
            }
            
            if url.scheme == nil {
                guard let url = URL(string: "https://\(url.absoluteString)") else {
                    self.showAlret(title: "유효한 URL이 아닙니다.", message: nil)
                    return
                }
                
                let safariController = SFSafariViewController(url: url)
                safariController.preferredControlTintColor = .label
                self.present(safariController, animated: true)
                
            } else {
                let safariController = SFSafariViewController(url: url)
                safariController.preferredControlTintColor = .label
                self.present(safariController, animated: true)
            }
        }
    }
    
    func checkAlertToDeleteItem(fileName: String, item: Item, IndexSet: IndexSet) {
        let alert = UIAlertController(title: "아이템을 삭제하시겠습니까?", message: nil, preferredStyle: .actionSheet)
        let delete = UIAlertAction(title: "삭제", style: .destructive) { [weak self] _ in
            guard let self = self else { return }
            self.removeImage(fileName: fileName)
            self.itemRepository.fetchDeleteItem(item: item)
            self.mainView.tableView.reloadSections(IndexSet, with: .automatic)
        }
        let cancel = UIAlertAction(title: "취소", style: .cancel)
        
        alert.addAction(delete)
        alert.addAction(cancel)
        
        present(alert, animated: true)
    }
}

extension MainViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return SelectedCategory.allCases.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        //return 30
        guard let section = SelectedCategory(rawValue: section) else {
            print("섹션헤더 높이 오류")
            return 0
        }
        
        switch section {
        case .outer:
            return itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.outer)).count == 0 ? 0 : 30
        case .top:
            return itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.top)).count == 0 ? 0 : 30
        case .bottom:
            return itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.bottom)).count == 0 ? 0 : 30
        case .shoes:
            return itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.shoes)).count == 0 ? 0 : 30
        case .acc:
            return itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.acc)).count == 0 ? 0 : 30
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        guard let header = tableView.dequeueReusableHeaderFooterView(withIdentifier: MainTableViewHeaderFooterView.reusableIdentifier) as? MainTableViewHeaderFooterView else { return UIView() }
        
        header.sectionTitleLabel.text = String(describing: SelectedCategory.allCases[section])
        
        return header
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        switch indexPath.section {
        case SelectedCategory.outer.rawValue:
            return itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.outer)).count == 0 ? 0 : 160 //UIScreen.main.bounds.height * 0.188
        case SelectedCategory.top.rawValue:
            return itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.top)).count == 0 ? 0 : 160 //UIScreen.main.bounds.height * 0.188
        case SelectedCategory.bottom.rawValue:
            return itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.bottom)).count == 0 ? 0 : 160 //UIScreen.main.bounds.height * 0.188
        case SelectedCategory.shoes.rawValue:
            return itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.shoes)).count == 0 ? 0 : 160 //UIScreen.main.bounds.height * 0.188
        case SelectedCategory.acc.rawValue:
            return itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.acc)).count == 0 ? 0 : 160 //UIScreen.main.bounds.height * 0.188
        default:
            return 0
        }

    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: MainTableViewCell.reusableIdentifier, for: indexPath) as? MainTableViewCell else { return UITableViewCell() }
        
        cell.collectionView.delegate = self
        cell.collectionView.dataSource = self
        cell.collectionView.tag = indexPath.section
        
        cell.collectionView.reloadData()

        return cell
    }

}

extension MainViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch collectionView.tag {
        case SelectedCategory.outer.rawValue:
            return itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.outer)).count
        case SelectedCategory.top.rawValue:
            return itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.top)).count
        case SelectedCategory.bottom.rawValue:
            return itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.bottom)).count
        case SelectedCategory.shoes.rawValue:
            return itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.shoes)).count
        case SelectedCategory.acc.rawValue:
            return itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.acc)).count
        default: return 0
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: MainCollectionViewCell.reusableIdentifier, for: indexPath) as? MainCollectionViewCell else { return UICollectionViewCell() }
        //print("MainViewController ->", #function, "->", "[section:item] = [\(indexPath.section), \(indexPath.item)]")
        
        switch collectionView.tag {
        case SelectedCategory.outer.rawValue:
            

            let ImageString = itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.outer))[indexPath.item].objectId

            cell.loadItemData(item: itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.outer))[indexPath.item], fitHidden: false)
            cell.productImage.image = loadImageFromImageDirectory(fileName: "\(ImageString).jpg")

            return cell

        case SelectedCategory.top.rawValue:
            
            let ImageString = itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.top))[indexPath.item].objectId
            
            cell.loadItemData(item: itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.top))[indexPath.item], fitHidden: false)
            cell.productImage.image = loadImageFromImageDirectory(fileName: "\(ImageString).jpg")
            
            return cell

        case SelectedCategory.bottom.rawValue:
            
            let ImageString = itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.bottom))[indexPath.item].objectId

            cell.loadItemData(item: itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.bottom))[indexPath.item], fitHidden: false)
            cell.productImage.image = loadImageFromImageDirectory(fileName: "\(ImageString).jpg")
            
            return cell

        case SelectedCategory.shoes.rawValue:
            
            let ImageString = itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.shoes))[indexPath.item].objectId

            cell.loadItemData(item: itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.shoes))[indexPath.item], fitHidden: true)
            cell.productImage.image = loadImageFromImageDirectory(fileName: "\(ImageString).jpg")
            
            return cell

        case SelectedCategory.acc.rawValue:
            
            let ImageString = itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.acc))[indexPath.item].objectId

            cell.loadItemData(item: itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.acc))[indexPath.item], fitHidden: true)
            cell.productImage.image = loadImageFromImageDirectory(fileName: "\(ImageString).jpg")
            
            return cell

        default:
            return UICollectionViewCell()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {

        let vc = DetailViewController()
        
        switch collectionView.tag { // 테이블뷰 섹션
        case SelectedCategory.outer.rawValue:
            vc.itemData = itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.outer))[indexPath.row]

        case SelectedCategory.top.rawValue:
            vc.itemData = itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.top))[indexPath.row]
            
        case SelectedCategory.bottom.rawValue:
            vc.itemData = itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.bottom))[indexPath.row]
            
        case SelectedCategory.shoes.rawValue:
            vc.itemData = itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.shoes))[indexPath.row]
            
        case SelectedCategory.acc.rawValue:
            vc.itemData = itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.acc))[indexPath.row]
            
        default :
            print("문제 발생")
        }
        
        transition(viewController: vc, style: .push, animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, contextMenuConfigurationForItemAt indexPath: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {

                let config = UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { _ in

                    switch collectionView.tag {
                    case SelectedCategory.outer.rawValue :
                        let item = self.itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.outer))[indexPath.item]
                        let realSize = item.realSizeArray!
                        let itemUrl = item.url

                        let shoulder = UIAction(title: "어깨 너비: \(realSize[0])cm", image: UIImage(systemName: "ruler")) { _ in }
                        let chest = UIAction(title: "가슴 단면: \(realSize[1])cm", image: UIImage(systemName: "ruler")) { _ in }
                        let sleeve = UIAction(title: "소매 길이: \(realSize[2])cm", image: UIImage(systemName: "ruler")) { _ in }
                        let length = UIAction(title: "총장: \(realSize[3])cm", image: UIImage(systemName: "ruler")) { _ in }

                        let url = UIAction(title: "링크 열기",image: UIImage(systemName: "safari"), attributes: itemUrl == "" ? .disabled : []) { [weak self] _ in
                            guard let self = self else { return }
                            self.showSFSafariViewController(itemUrl: itemUrl)
                        }
                        let urlOrMemo = UIMenu(title: "", image: nil, options: .displayInline, children: [url])

                        let delete = UIAction(title: "삭제", image: UIImage(systemName: "trash"), attributes: .destructive) { [weak self] _ in
                            guard let self = self else { return }

                            self.checkAlertToDeleteItem(fileName: "\(item.objectId).jpg", item: item, IndexSet: IndexSet(collectionView.tag...collectionView.tag))

                        }

                        return UIMenu(title: "", image: UIImage(systemName: "ruler"), identifier: nil, options: .displayInline, children: [shoulder, chest, sleeve, length, urlOrMemo, delete])

                    case SelectedCategory.top.rawValue :
                        let item = self.itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.top))[indexPath.item]
                        let realSize = item.realSizeArray!
                        let itemUrl = item.url

                        let shoulder = UIAction(title: "어깨 너비: \(realSize[0])cm", image: UIImage(systemName: "ruler")) { _ in }
                        let chest = UIAction(title: "가슴 단면: \(realSize[1])cm", image: UIImage(systemName: "ruler")) { _ in }
                        let sleeve = UIAction(title: "소매 길이: \(realSize[2])cm", image: UIImage(systemName: "ruler")) { _ in }
                        let length = UIAction(title: "총장: \(realSize[3])cm", image: UIImage(systemName: "ruler")) { _ in }

                        let url = UIAction(title: "링크 열기",image: UIImage(systemName: "safari"), attributes: itemUrl == "" ? .disabled : []) { [weak self] _ in
                            guard let self = self else { return }
                            self.showSFSafariViewController(itemUrl: itemUrl)
                        }
                        let urlOrMemo = UIMenu(title: "", image: nil, options: .displayInline, children: [url])

                        let delete = UIAction(title: "삭제", image: UIImage(systemName: "trash"), attributes: .destructive) { [weak self] _ in
                            guard let self = self else { return }

                            self.checkAlertToDeleteItem(fileName: "\(item.objectId).jpg", item: item, IndexSet: IndexSet(collectionView.tag...collectionView.tag))

                        }

                        return UIMenu(title: "", image: nil, identifier: nil, options: .displayInline, children: [shoulder, chest, sleeve, length, urlOrMemo, delete])

                    case SelectedCategory.bottom.rawValue :
                        let item = self.itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.bottom))[indexPath.item]
                        let realSize = item.realSizeArray!
                        let itemUrl = item.url

                        let waist = UIAction(title: "허리 단면: \(realSize[0])cm", image: UIImage(systemName: "ruler")) { _ in }
                        let thigh = UIAction(title: "허벅지 단면: \(realSize[1])cm", image: UIImage(systemName: "ruler")) { _ in }
                        let rise = UIAction(title: "밑위: \(realSize[2])cm", image: UIImage(systemName: "ruler")) { _ in }
                        let ankle = UIAction(title: "밑단 단면: \(realSize[3])cm", image: UIImage(systemName: "ruler")) { _ in }
                        let length = UIAction(title: "총장: \(realSize[4])cm", image: UIImage(systemName: "ruler")) { _ in }

                        let url = UIAction(title: "링크 열기",image: UIImage(systemName: "safari"), attributes: itemUrl == "" ? .disabled : []) { [weak self] _ in
                            guard let self = self else { return }
                            self.showSFSafariViewController(itemUrl: itemUrl)
                        }
                        let urlOrMemo = UIMenu(title: "", image: nil, options: .displayInline, children: [url])

                        let delete = UIAction(title: "삭제", image: UIImage(systemName: "trash"), attributes: .destructive) { [weak self] _ in
                            guard let self = self else { return }

                            self.checkAlertToDeleteItem(fileName: "\(item.objectId).jpg", item: item, IndexSet: IndexSet(collectionView.tag...collectionView.tag))

                        }

                        return UIMenu(title: "", image: nil, identifier: nil, options: .displayInline, children: [waist, thigh, rise, ankle, length, urlOrMemo, delete])

                    case SelectedCategory.shoes.rawValue :

                        let item = self.itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.shoes))[indexPath.item]
                        let itemUrl = item.url
                        let url = UIAction(title: "링크 열기",image: UIImage(systemName: "safari"), attributes: itemUrl == "" ? .disabled : []) { [weak self] _ in
                            guard let self = self else { return }
                            self.showSFSafariViewController(itemUrl: itemUrl)
                        }
                        let urlMenu = UIMenu(title: "", options: .displayInline, children: [url])

                        let delete = UIAction(title: "삭제", image: UIImage(systemName: "trash"), attributes: .destructive) { [weak self] _ in
                            guard let self = self else { return }

                            self.checkAlertToDeleteItem(fileName: "\(item.objectId).jpg", item: item, IndexSet: IndexSet(collectionView.tag...collectionView.tag))

                        }
                        return UIMenu(title: "", image: nil, identifier: nil, options: .displayInline, children: [urlMenu, delete])

                    case SelectedCategory.acc.rawValue :
                        let item = self.itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.acc))[indexPath.item]
                        let itemUrl = item.url
                        let url = UIAction(title: "링크 열기",image: UIImage(systemName: "safari"), attributes: itemUrl == "" ? .disabled : []) { [weak self] _ in
                            guard let self = self else { return }
                            self.showSFSafariViewController(itemUrl: itemUrl)
                        }
                        let urlMenu = UIMenu(title: "", options: .displayInline, children: [url])

                        let delete = UIAction(title: "삭제", image: UIImage(systemName: "trash"), attributes: .destructive) { [weak self] _ in
                            guard let self = self else { return }

                            self.checkAlertToDeleteItem(fileName: "\(item.objectId).jpg", item: item, IndexSet: IndexSet(collectionView.tag...collectionView.tag))

                        }
                        return UIMenu(title: "", image: nil, identifier: nil, options: .displayInline, children: [urlMenu, delete])

                    default :
                        print("오류 발생")
                        return nil
                    }
                }

                return config
    }


//    func collectionView(_ collectionView: UICollectionView, contextMenuConfigurationForItemsAt indexPaths: [IndexPath], point: CGPoint) -> UIContextMenuConfiguration? {
//
//
//        return UIContextMenuConfiguration(actionProvider: { suggestedActions in
//               if indexPaths.count == 0 {
//                   // Construct an empty-space menu.
//                   return nil
//               }
//               else if indexPaths.count == 1 {
//                   // Construct a single-item menu.
//                   return UIMenu(children: [
//                       UIAction(title: "Copy") { _ in /* Implement the action. */ },
//                       UIAction(title: "Delete", attributes: .destructive) { _ in /* Implement the action. */ }
//                   ])
//               }
//               else {
//                   // Construct a multiple-item menu.
//                   return nil
//               }
//           })

        //        let config = UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { _ in
        //
        //            let size = UIAction(title: "어깨 넓이: \(self.items[0].realSizeArray?[0])") { _ in
        //                print("\(indexPaths)")
        //            }
        //
        //            return UIMenu(title: "실측 사이즈", image: nil, identifier: nil, options: .displayInline, children: [size])
        //        }
        //
        //        return config
        //    }
//    }
}
