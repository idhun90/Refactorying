import UIKit

import SnapKit

final class MainTableViewCell: BaseTableViewCell {
    
    lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        let spacing: CGFloat = 10
        
        let tableViewCellHeight: CGFloat = 160 //UIScreen.main.bounds.height * 0.188
        let height = tableViewCellHeight - 20
        let width = UIScreen.main.bounds.width * 0.445 //0.535, 0.438~0.439가 단축키 앱 가로와 같음
        
        layout.itemSize = CGSize(width: width, height: height)
        layout.sectionInset = UIEdgeInsets(top: 0, left: 16, bottom: 0, right: spacing) // nav 라지 타이틀 leading 이랑 맞추기 위해
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = 10
        layout.minimumInteritemSpacing = spacing
        
        let view = UICollectionView(frame: .zero, collectionViewLayout: layout)
        
        view.register(MainCollectionViewCell.self, forCellWithReuseIdentifier: MainCollectionViewCell.reusableIdentifier)
        view.backgroundColor = .customBackgroundColor
        view.showsHorizontalScrollIndicator = false
        
        return view
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func configureUI() {
        [collectionView].forEach {
            self.contentView.addSubview($0)
            self.contentView.backgroundColor = .customBackgroundColor
        }
    }
    
    override func setConstraints() {
        collectionView.snp.makeConstraints {
            $0.edges.equalTo(self.contentView)
        }
    }
}
