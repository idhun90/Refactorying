import UIKit

import SnapKit

final class MainCollectionViewCell: BaseCollectionViewCell {
    
    let productImage: UIImageView = {
        let view = UIImageView(frame: .zero)
        view.backgroundColor = .customTiarySystemBackgroundColor
        view.layer.cornerRadius = 10
        view.layer.masksToBounds = true
        view.contentMode = .scaleAspectFill
        return view
    }()
    
    let productName: CustomLabel = {
        let view = CustomLabel()
        view.configure(FontSize: 16, weight: .semibold, color: .label)
        return view
    }()
    
    let brandName: CustomLabel = {
        let view = CustomLabel()
        view.configure(FontSize: 14, weight: .regular, color: .secondaryLabel)
        
        return view
    }()
    
    let productSize: CustomLabel = {
        let view = CustomLabel()
        view.configure(FontSize: 14, weight: .regular, color: .secondaryLabel)
        
        return view
    }()
    
    let fit: CustomLabel = {
        let view = CustomLabel()
        view.configure(FontSize: 14, weight: .regular, color: .secondaryLabel)
        
        return view
    }()
    
    let result: CustomLabel = {
        let view = CustomLabel()
        view.configure(FontSize: 14, weight: .bold, color: .customTintColor)
        
        return view
    }()
    
    lazy var stackView: UIStackView = {
        let view = UIStackView(arrangedSubviews: [productSize, fit, result])
        view.axis = .horizontal
        view.alignment = .fill
        view.distribution = .equalSpacing
        view.spacing = 5
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func configureUI() {
        self.backgroundColor = .customSecondaraySystemBackgroundColor
        self.layer.cornerRadius = 12
        
        [productImage, productName, brandName, stackView].forEach {
            self.contentView.addSubview($0)
        }
        
    }
    
    func loadItemData(item: Item, fitHidden: Bool) {
        self.productName.text = item.inputValue[0]
        self.brandName.text = item.inputValue[1]
        self.productSize.text = item.inputValue[2]
        self.fit.text = item.fit == nil ? "--" : InfoList.infoFit.secondaryText[item.fit!]
        self.result.text = InfoList.infoResult.secondaryText[item.result]
        self.fit.isHidden = fitHidden
        
    }
    
    override func setConstraints() {
        productImage.snp.makeConstraints {
            let spacing = 10
            $0.top.equalTo(self.contentView).offset(spacing)
            $0.leading.equalTo(self.contentView).offset(spacing)
            $0.width.equalTo(self.contentView).multipliedBy(0.24/*0.22*/)
            $0.height.equalTo(productImage.snp.width)
        }
        
        productName.snp.makeConstraints {
            let spacing = 10
            $0.top.equalTo(productImage.snp.bottom).offset(spacing)
            $0.leading.equalTo(self.contentView).offset(spacing)
            $0.trailing.lessThanOrEqualTo(self.contentView).offset(-spacing)
        }
        
        brandName.snp.makeConstraints {
            let spacing = 10
            $0.top.equalTo(productName.snp.bottom).offset(4)
            $0.leading.equalTo(self.contentView).offset(spacing)
            $0.trailing.lessThanOrEqualTo(self.contentView).offset(-spacing)
        }
        
        stackView.snp.makeConstraints {
            let spacing = 10
            $0.top.equalTo(brandName.snp.bottom).offset(4)
            $0.leading.equalTo(self.contentView).offset(spacing)
            $0.trailing.lessThanOrEqualTo(self.contentView).offset(-spacing)
            $0.bottom.lessThanOrEqualTo(self.contentView).offset(-spacing)
        }
    }
}
