import UIKit

enum TabBar {
    case firstTabBar
    case secondTabBar
    
    var tabBarTitle: String {
        switch self {
        case .firstTabBar:
            return "옷"
        case .secondTabBar:
            return "설정"
        }
    }
    
    var tabBarImage: String {
        switch self {
        case .firstTabBar:
            return "tshirt.fill" //"tray.full.fill"
        case .secondTabBar:
            return "gearshape.fill"
        }
    }
}

class TabBarController: UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureTabBarController()
        tabBar.tintColor = .customTintColor
    }
    
    func configureTabBarController() {
        
        let CompositionalViewController = CompositionalViewController()
        let CompositionalLayoutNavigationController = UINavigationController(rootViewController: CompositionalViewController)
        CompositionalLayoutNavigationController.tabBarItem.title = TabBar.firstTabBar.tabBarTitle// + "테스트"
        CompositionalLayoutNavigationController.tabBarItem.image = UIImage(systemName: TabBar.firstTabBar.tabBarImage)
        
//        let firstViewController = MainViewController()
//        let firstNavigationController = UINavigationController(rootViewController: firstViewController)
//        firstNavigationController.tabBarItem.title = TabBar.firstTabBar.tabBarTitle
//        firstNavigationController.tabBarItem.image = UIImage(systemName: TabBar.firstTabBar.tabBarImage)
        
//        let secondViewController = PreferencesViewController()
//        let secondNavigationController = UINavigationController(rootViewController: secondViewController)
//        secondNavigationController.tabBarItem.title = TabBar.secondTabBar.tabBarTitle//"설정"
//        secondNavigationController.tabBarItem.image = UIImage(systemName: TabBar.secondTabBar.tabBarImage)

        let secondViewController = SettingViewController()
        let secondNavigationController = UINavigationController(rootViewController: secondViewController)
        secondNavigationController.tabBarItem.title = TabBar.secondTabBar.tabBarTitle//"설정"
        secondNavigationController.tabBarItem.image = UIImage(systemName: TabBar.secondTabBar.tabBarImage)
        
        self.setViewControllers([CompositionalLayoutNavigationController, secondNavigationController], animated: false)
    }
}
