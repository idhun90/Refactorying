import UIKit
import MessageUI

import AcknowList
import Zip

enum BackupAndRestore: Int, CaseIterable, CustomStringConvertible {
    
    case backup
    case restore
    
    var description: String {
        switch self {
        case .backup:
            return "데이터 백업"
        case .restore:
            return "데이터 복원"
        }
    }
    
}

final class PreferencesViewController: BaseViewController {
    
    let mainView = PreferencesView()
    
    let titleList = ["데이터 백업", "데이터 복원"]
    
    override func loadView() {
        self.view = mainView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setTableView()
    }
    
    override func configureUI() {
        self.mainView.backgroundColor = .customBackgroundColor
        
        self.navigationItem.title = "설정"
        self.navigationController?.navigationBar.prefersLargeTitles = true
    }
    
    func setTableView() {
        self.mainView.tableView.delegate = self
        self.mainView.tableView.dataSource = self
    }
    
    func backupDate() {
        var urlPaths = [URL]() // 백업할 파일에 대한 URL 배열
        
        guard let path = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            print("도큐먼트 경로에 오류가 있습니다.")
            return
        }
        
        let imageDirectory = path.appendingPathComponent("image")
        let realmFile = path.appendingPathComponent("default.realm")
        
        if FileManager.default.fileExists(atPath: imageDirectory.path) {
            urlPaths.append(URL(string: imageDirectory.path)!)
        } else {
            print("백업할 이미지 폴더가 존재하지 않습니다.")
        }
        
        if FileManager.default.fileExists(atPath: realmFile.path) {
            urlPaths.append(URL(string: realmFile.path)!)
        } else {
            print("백업할 realm 파일이 존재하지 않습니다.")
        }
        print(urlPaths)
        
        if FileManager.default.fileExists(atPath: path.appendingPathComponent("archive.zip").path) {
            let alert = UIAlertController(title: "기존 백업을 대치하겠습니까?", message: "Hanger 앱 내부에 기존 백업 파일이 존재합니다. 새로운 백업 파일로 대치하겠습니까? 기존 백업 데이터는 삭제됩니다.", preferredStyle: .actionSheet)
            let ok = UIAlertAction(title: "대치", style: .destructive) { _ in
                do {
                    let zipFilePath = try Zip.quickZipFiles(urlPaths, fileName: "archive")
                    print("압축을 성공했습니다. 압축 경로: \(zipFilePath)")
                    self.presentActivityViewController()
                } catch {
                    print("압축이 실패했습니다.")
                }
            }
            let cancel = UIAlertAction(title: "취소", style: .cancel)
            cancel.setValue(UIColor.customTintColor, forKey: "titleTextColor")
            alert.addAction(ok)
            alert.addAction(cancel)
            self.present(alert, animated: true)
        } else {
            do {
                let zipFilePath = try Zip.quickZipFiles(urlPaths, fileName: "archive")
                print("압축을 성공했습니다. 압축 경로: \(zipFilePath)")
                presentActivityViewController()
            } catch {
                print("압축이 실패했습니다.")
            }
        }
    }
    
    func presentActivityViewController() {
        guard let path = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first?.appendingPathComponent("archive.zip") else {
            print("백업 파일 경로 오류")
            return
        }
        
        let vc = UIActivityViewController(activityItems: [path], applicationActivities: nil)
        self.present(vc, animated: true)
    }
    
    func restoreData() {
        let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: [.archive], asCopy: true)
        documentPicker.delegate = self
        documentPicker.allowsMultipleSelection = false
        self.present(documentPicker, animated: true)
    }
    
    func sendMail() {
        if MFMailComposeViewController.canSendMail() {
            let mail = MFMailComposeViewController()
            //mail.view.tintColor = .customTintColor //작동되긴함
            
            let message = """
                          내용:
                          
                          
                          
                          
                          
                          
                          
                          
                          
                          ---
                          Device Model: \(self.getDeviceIdentifier())
                          Device iOS: \(UIDevice.current.systemVersion)
                          App Version: \(self.getCurrentAppVersion())
                          """
            
            mail.setToRecipients(["idhun90@me.com"])
            mail.setSubject("[Hanger] 문의")
            mail.setMessageBody(message, isHTML: false)
            mail.mailComposeDelegate = self // 메일이 잘 전송됐는지 체크 필요
            
            self.present(mail, animated: true)
            
        } else {
            print("메일 보내기 실패")
            let sendMailErrorAlert = UIAlertController(title: "기본 Mail 앱에 계정이 추가되어 있지 않습니다.", message: "문의 메일을 보내려면 기본 Mail 앱에 계정을 추가해야 합니다.", preferredStyle: .actionSheet)
            let goSettingAction = UIAlertAction(title: "설정으로 이동", style: .default) { _ in
                if let url = URL(string: UIApplication.openSettingsURLString), UIApplication.shared.canOpenURL(url) { // 설정 화면 이동
                    UIApplication.shared.open(url, options: [:], completionHandler: nil)
                }
            }
            let cancel = UIAlertAction(title: "취소", style: .destructive)
            
            sendMailErrorAlert.addAction(goSettingAction)
            sendMailErrorAlert.addAction(cancel)
            self.present(sendMailErrorAlert, animated: true)
        }
    }
    
    func getDeviceIdentifier() -> String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let machineMirror = Mirror(reflecting: systemInfo.machine)
        let identifier = machineMirror.children.reduce("") { identifier, element in
            guard let value = element.value as? Int8, value != 0 else { return identifier }
            return identifier + String(UnicodeScalar(UInt8(value)))
        }
        
        return identifier
    }
    
    func getCurrentAppVersion() -> String {
        guard let dictionary = Bundle.main.infoDictionary,
              let version = dictionary["CFBundleShortVersionString"] as? String else { return "" }
        return version
    }
}

extension PreferencesViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2 //3 //BackupAndRestore.allCases.count
    }
    
//    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
//        switch section {
//        case 0:
//            return "백업 및 복원"
//        case 1:
//            return "고객센터"
//        case 2:
//            return "약관 및 정책"
//        default:
//            return nil
//        }
//    }

    func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        switch section {
        case 0:
            return "백업 파일은 Hanger 앱 내부에 생성되며, Hanger 앱 삭제 시 저장된 백업 파일도 함께 삭제됩니다.\n\n기기를 잃어버리거나 새로운 기기로 교체하실 때 사용자의 데이터를 복원할 수 있도록 생성된 백업 파일을 '파일'앱 > 'iCloud Drive' 또는 안전한 위치로 옮겨주세요.\n\n데이터 크기에 따라 다소 시간이 걸릴 수 있습니다. 진행 중에 앱을 종료하거나 다른 앱으로 이동하지 말고 잠시만 기다려 주세요.\n\n성공적인 백업, 복구를 위해 파일명은 변경하지 마시기 바랍니다."
        case 1:
            return "기본 Mail 앱에 메일 계정이 등록되어야 사용할 수 있습니다."
        default:
            return nil
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return 2
        case 1:
            return 1
        case 2:
            return 0//1
        default:
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: PreferencesTableViewCell.reusableIdentifier, for: indexPath) as? PreferencesTableViewCell else { return UITableViewCell() }
        
        switch indexPath.section {
        case 0:
            cell.setupCell(text: titleList[indexPath.row])
            cell.accessoryType = .none
        case 1:
            cell.setupCell(text: "문의하기")
            cell.accessoryType = .none
//        case 2:
//            cell.setupCell(text: "오픈소스 라이선스")
//            cell.accessoryType = .disclosureIndicator
        default:
            return UITableViewCell()
        }
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        
        switch indexPath {
        case [0, 0]:
            // 백업
            backupDate()
        case [0, 1]:
            // 복원
            restoreData()
        case [1, 0]:
            sendMail()
//        case [2, 0]:
//            let vc = AcknowListViewController()
//            vc.title = "오픈소스 라이선스"
//            
//            navigationController?.pushViewController(vc, animated: true)
        default:
            print("없음")
        }
    }
}

extension PreferencesViewController: UIDocumentPickerDelegate {
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        print("취소 버튼을 누르셨습니다.")
    }
    
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let backupFileInFileAppURL = urls.first else { // 파일 앱에서 선택한 파일 경로
            print("선택하신 파일을 찾을 수 없습니다.")
            return
        }
        
        guard let backupFileURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { // 도큐먼트 경로
            print("도큐먼트의 백업 파일 경로에 문제가 있습니다.")
            return
        }
        
        let sandboxFileURL = backupFileURL.appendingPathComponent(backupFileInFileAppURL.lastPathComponent) // 도큐먼트에서 백업 파일 경로
        
        if FileManager.default.fileExists(atPath: sandboxFileURL.path) {
            let fileURL = backupFileURL.appendingPathComponent("archive.zip")
            
            do {
                try Zip.unzipFile(fileURL, destination: backupFileURL, overwrite: true, password: nil, progress: { progress in
                    print("진행 현황: \(progress)")
                }, fileOutputHandler: { unzippedFile in
                    print("압축 해제된 파일: \(unzippedFile)")
                    print("복원이 완료되었습니다.")
                    self.showAlret(title: "복원이 완료되었습니다.", message: "앱을 완전히 종료 후 다시 실행해주세요.")
                })
            } catch {
                print("도큐먼트 파일에 백업 파일 존재, 압축 해제 실패")
            }
            
        } else {
            
            do {
                try FileManager.default.copyItem(at: backupFileInFileAppURL, to: sandboxFileURL)
                
                let fileURL = backupFileURL.appendingPathComponent("archive.zip")
                
                try Zip.unzipFile(fileURL, destination: backupFileURL, overwrite: true, password: nil, progress: { progress in
                    print("진행 현황: \(progress)")
                }, fileOutputHandler: { unzippedFile in
                    print("압축 해제된 파일: \(unzippedFile)")
                    print("복원이 완료되었습니다.")
                    self.showAlret(title: "복원이 완료되었습니다.", message: "앱을 완전히 종료 후 다시 실행해주세요.")
                })
            } catch {
                print("도큐먼트 파일에 백업 파일 없음, 압축 해제 실패")
            }
        }
    }
}

extension PreferencesViewController: MFMailComposeViewControllerDelegate {
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        self.dismiss(animated: true)
    }
}
