import UIKit

import SnapKit

final class PreferencesTableViewCell: BaseTableViewCell {
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func configureUI() {
        self.backgroundColor = .customSecondaraySystemBackgroundColor
    }
    
    func setupCell(text: String) {
        var content = self.defaultContentConfiguration()
        content.attributedText = NSAttributedString(string: text, attributes: [.font: UIFont.systemFont(ofSize: 16)])
        self.contentConfiguration = content
    }
    
    override func setConstraints() {
    }
    
}

