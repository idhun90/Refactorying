//
//  MoreView.swift
//  Hanger
//
//  Created by 도헌 on 2023/01/22.
//

import UIKit

import SnapKit

final class MoreView: BaseView {
    
    let searchController: UISearchController = {
        let view = UISearchController(searchResultsController: nil)
        view.searchBar.tintColor = .label
        view.searchBar.autocapitalizationType = .none
        view.searchBar.placeholder = "검색"
        view.searchBar.searchTextField.clearButtonMode = .whileEditing
        view.searchBar.setValue("취소", forKey: "cancelButtonText")
        return view
    }()
    
    lazy var collectionView: UICollectionView = {
        let layout = creatLayout()
        let view = UICollectionView(frame: .zero, collectionViewLayout: layout)
        view.register(MoreViewCell.self, forCellWithReuseIdentifier: MoreViewCell.reusableIdentifier)
        view.backgroundColor = .customBackgroundColor
        view.delaysContentTouches = false
        return view
    }()
    
    let emptyLabel: UILabel = {
        let view = UILabel(frame: .zero)
        view.text = "추가된 아이템이 없어요."
        view.font = .systemFont(ofSize: 16, weight: .bold)
        view.textColor = .secondaryLabel
        return view
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    override func configureUI() {
        super.configureUI()
    }
    
    override func setConstraints() {
        super.setConstraints()
        addSubview(collectionView)
        addSubview(emptyLabel)
        
        collectionView.snp.makeConstraints {
            $0.edges.equalToSuperview()
        }
        
        emptyLabel.snp.makeConstraints {
            $0.center.equalToSuperview()
        }
    }
}

extension MoreView {
    private func creatLayout() -> UICollectionViewLayout {
        //let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0), heightDimension: .fractionalHeight(1.0))
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0), heightDimension: .estimated(120))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0), heightDimension: .absolute(140))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitem: item, count: 2)
        group.interItemSpacing = .fixed(12)
        
        let section = NSCollectionLayoutSection(group: group)
        section.interGroupSpacing = 12
        section.contentInsets = NSDirectionalEdgeInsets(top: 10, leading: 16, bottom: 0, trailing: 16)
        
        let layout = UICollectionViewCompositionalLayout(section: section)
        
        return layout
    }
}
