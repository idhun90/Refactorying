//
//  MoreViewCell.swift
//  Hanger
//
//  Created by 도헌 on 2023/01/22.
//

import UIKit

import SnapKit

final class MoreViewCell: BaseCollectionViewCell {
    
    let productImage: UIImageView = {
        let view = UIImageView(frame: .zero)
        view.backgroundColor = .tertiarySystemGroupedBackground.withAlphaComponent(0.7)
        view.layer.cornerRadius = 10
        view.layer.masksToBounds = true
        view.layer.borderWidth = 1.0 / view.traitCollection.displayScale
        view.contentMode = .scaleAspectFill
        return view
    }()
    
    let productName: CustomLabel = {
        let view = CustomLabel()
        view.configure(FontSize: 14, weight: .semibold, color: .label)
        return view
    }()
    
    let productBrand: CustomLabel = {
        let view = CustomLabel()
        view.configure(FontSize: 14, weight: .regular, color: .secondaryLabel.withAlphaComponent(0.7))
        return view
    }()
    
    let productSize: CustomLabel = {
        let view = CustomLabel()
        view.configure(FontSize: 14, weight: .regular, color: .secondaryLabel.withAlphaComponent(0.7))
        return view
    }()
    
    let productFit: CustomLabel = {
        let view = CustomLabel()
        view.configure(FontSize: 14, weight: .regular, color: .secondaryLabel.withAlphaComponent(0.7))
        return view
    }()
    
    let productResult: CustomLabel = {
        let view = CustomLabel()
        view.configure(FontSize: 14, weight: .semibold, color: .customTintColor)
        return view
    }()
    
    lazy var stackView: UIStackView = {
        let view = UIStackView(arrangedSubviews: [productSize, productFit, productResult])
        view.axis = .horizontal
        view.alignment = .fill
        view.distribution = .equalSpacing
        view.spacing = 5
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        layer.borderColor = UIColor.systemGray5.cgColor
        productImage.layer.borderColor = UIColor.systemGray5.cgColor
        
//        contentView.layer.cornerRadius = 12
//        layer.shadowColor = UIColor.gray.cgColor
//        layer.shadowOpacity = 0.3
//        layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
//        layer.shadowRadius = 12
    }
    
    func setupData(item: Item) {
        productName.text = item.inputValue[0]
        productBrand.text = item.inputValue[1]
        productSize.text = item.inputValue[2]
        productFit.text = item.fit == nil ? "--" : InfoList.infoFit.secondaryText[item.fit!]
        productFit.isHidden = item.fit == nil ? true : false
        productResult.text = InfoList.infoResult.secondaryText[item.result]
    }
    
    override func configureUI() {
        super.configureUI()
        backgroundColor = .customCellBackgroundColor
        layer.cornerRadius = 12
        layer.borderWidth = 1.0 / traitCollection.displayScale
    }
    
    override func setConstraints() {
        super.setConstraints()
        
        [productImage, productName, productBrand, stackView].forEach {
            contentView.addSubview($0)
        }
        
        productImage.snp.makeConstraints {
            let spacing = 10
            $0.top.equalTo(contentView).offset(spacing)
            $0.leading.equalTo(contentView).offset(spacing)
            $0.width.equalTo(contentView).multipliedBy(0.24/*0.22*/)
            $0.height.equalTo(productImage.snp.width)
        }
        
        productName.snp.makeConstraints {
            let spacing = 10
            $0.top.equalTo(productImage.snp.bottom).offset(spacing)
            $0.leading.equalTo(contentView).offset(spacing)
            $0.trailing.lessThanOrEqualTo(contentView).offset(-spacing)
        }
        
        productBrand.snp.makeConstraints {
            let spacing = 10
            $0.top.equalTo(productName.snp.bottom).offset(4)
            $0.leading.equalTo(contentView).offset(spacing)
            $0.trailing.lessThanOrEqualTo(contentView).offset(-spacing)
        }
        
        stackView.snp.makeConstraints {
            let spacing = 10
            $0.top.equalTo(productBrand.snp.bottom).offset(4)
            $0.leading.equalTo(contentView).offset(spacing)
            $0.trailing.lessThanOrEqualTo(contentView).offset(-spacing)
            $0.bottom.lessThanOrEqualTo(contentView).offset(-spacing)
        }
    }
}
