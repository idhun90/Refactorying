//
//  MoreViewController.swift
//  Hanger
//
//  Created by 도헌 on 2023/01/22.
//

import UIKit

import RealmSwift
import SafariServices

final class MoreViewController: BaseViewController {
    
    enum Category: String {
        case outer = "아우터"
        case top = "상의"
        case bottom = "하의"
        case shoes = "신발"
        case acc = "액세서리"
    }
    
    private let mainView = MoreView()
    
    var category: String?
    private let itemRepository = ItemRepository()
    var categoryItems: Results<Item>!
    
    override func loadView() {
        view = mainView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = category ?? "값 없음"
        setupSearchController()
        setupCollectionView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //setupToolbar()
        checkShowOrHiddenEmptyLabel()
        mainView.collectionView.reloadData()
    }
    
    deinit {
        print("MoreViewController deinited")
    }
    
    private func setupSearchController() {
        navigationItem.searchController = mainView.searchController
        navigationItem.hidesSearchBarWhenScrolling = false
        mainView.searchController.searchBar.delegate = self
    }
    
    private func setupCollectionView() {
        mainView.collectionView.dataSource = self
        mainView.collectionView.delegate = self
    }
    
    private func showSFSafariViewController(itemUrl: String) {
        
        if itemUrl != "" {
            
            let encodedUrlValue = itemUrl.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
            
            guard let url = URL(string: encodedUrlValue) else {
                showAlret(title: "유효한 URL이 아닙니다.", message: nil)
                return
            }
            
            if url.scheme == nil {
                guard let url = URL(string: "https://\(url.absoluteString)") else {
                    showAlret(title: "유효한 URL이 아닙니다.", message: nil)
                    return
                }
                
                let safariController = SFSafariViewController(url: url)
                safariController.preferredControlTintColor = .label
                present(safariController, animated: true)
                
            } else {
                let safariController = SFSafariViewController(url: url)
                safariController.preferredControlTintColor = .label
                present(safariController, animated: true)
            }
        }
    }
    
    private func ShowAlertDeleteItem(image: String, item: Item) {
        let alert = UIAlertController(title: "아이템을 삭제하시겠습니까?", message: nil, preferredStyle: .actionSheet)
        let delete = UIAlertAction(title: "삭제", style: .destructive) { [weak self] _ in
            guard let self = self else { return }
            self.removeImage(fileName: image)
            self.itemRepository.fetchDeleteItem(item: item)
            self.mainView.collectionView.reloadData()
            self.checkShowOrHiddenEmptyLabel()
        }
        let cancel = UIAlertAction(title: "취소", style: .cancel)
        
        alert.addAction(delete)
        alert.addAction(cancel)
        
        present(alert, animated: true)
    }
    
    private func checkShowOrHiddenEmptyLabel() {
        mainView.emptyLabel.isHidden = categoryItems.isEmpty ? false : true
    }
    
//    private func setupToolbar() {
//        navigationController?.isToolbarHidden = false
//        //navigationController?.setToolbarHidden(false, animated: false)
//        let label = UILabel(frame: .zero)
//        label.text = "\(categoryItems.count)개의 아이템"
//        label.textAlignment = .center
//        label.textColor = .label
//        label.font = .systemFont(ofSize: 11)
//
//        let leftFlexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: self, action: nil)
//        let rightFlexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: self, action: nil)
//        let labelBarButton = UIBarButtonItem(customView: label)
//        setToolbarItems([leftFlexibleSpace, labelBarButton, rightFlexibleSpace], animated: false)
//    }

}

extension MoreViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return categoryItems.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: MoreViewCell.reusableIdentifier, for: indexPath) as? MoreViewCell else { return UICollectionViewCell() }
        cell.productImage.image = loadImageFromImageDirectory(fileName: "\(categoryItems[indexPath.item].objectId).jpg")
        cell.setupData(item: categoryItems[indexPath.item])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let vc = DetailViewController()
        vc.itemData = categoryItems[indexPath.item]
        transition(viewController: vc, style: .push, animated: true)
        
        
//        let nvc = UINavigationController(rootViewController: vc)
//        if let sheet = nvc.sheetPresentationController {
//            sheet.detents = [.medium()]
//            sheet.prefersGrabberVisible = true
//            sheet.prefersScrollingExpandsWhenScrolledToEdge = false
//        }
//        present(nvc, animated: true)
        
    }
    
    // 탭했을 때 background 색상 변경
    // 참조: https://developer.apple.com/documentation/uikit/uicollectionviewdelegate/changing_the_appearance_of_selected_and_highlighted_cells
    
    func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        if let cell = collectionView.cellForItem(at: indexPath) as? MoreViewCell {
            // 색상변경
            //cell.backgroundColor = .CustomTapColor
            
            // 애니매이션 효과
            UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 1) {
                cell.transform = CGAffineTransform(scaleX: 0.96, y: 0.96)
                cell.layoutIfNeeded()
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        if let cell = collectionView.cellForItem(at: indexPath) as? MoreViewCell {
            
            //cell.backgroundColor = .customCellBackgroundColor
            
            UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0) {
                cell.transform = .identity
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, contextMenuConfigurationForItemAt indexPath: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {
        
        guard let value = category else { return nil }
        guard let category = Category(rawValue: value) else { return nil }
        let item = categoryItems[indexPath.item]
        let realSize = item.realSizeArray ?? []
        let url = item.url
        
        let config = UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { [weak self] _ in
            guard let self = self else { return nil }
            
            switch category {
            case .outer, .top:
                let shoulder = UIAction(title: "어깨 너비: \(realSize[0] == "" ? "-" : realSize[0]) cm" , image: UIImage(systemName: "ruler")) { _ in }
                let chest = UIAction(title: "가슴 단면: \(realSize[1] == "" ? "-" : realSize[1]) cm", image: UIImage(systemName: "ruler")) { _ in }
                let sleeve = UIAction(title: "소매 길이: \(realSize[2] == "" ? "-" : realSize[2]) cm", image: UIImage(systemName: "ruler")) { _ in }
                let length = UIAction(title: "총장: \(realSize[3] == "" ? "-" : realSize[3]) cm", image: UIImage(systemName: "ruler")) { _ in }
                let url = UIAction(title: "링크 열기" , image: UIImage(systemName: "safari"), attributes: url == "" ? .disabled : []) { [weak self] _ in
                    guard let self = self else { return }
                    self.showSFSafariViewController(itemUrl: url)
                }
                let delete = UIAction(title: "삭제", image: UIImage(systemName: "trash"), attributes: .destructive) { [weak self] _ in
                    guard let self = self else { return }
                    self.ShowAlertDeleteItem(image: "\(item.objectId).jpg", item: item)
                }
                
                let urlAndDelete = UIMenu(options: .displayInline, children: [url, delete])
                
                return UIMenu(title: InfoList.infoResult.secondaryText[item.result], options: .displayInline, children: [shoulder, chest, sleeve, length, urlAndDelete])
            case .bottom:
                let waist = UIAction(title: "허리 단면: \(realSize[0] == "" ? "-" : realSize[0]) cm" , image: UIImage(systemName: "ruler")) { _ in }
                let thigh = UIAction(title: "허벅지 단면: \(realSize[1] == "" ? "-" : realSize[1]) cm", image: UIImage(systemName: "ruler")) { _ in }
                let rise = UIAction(title: "밑위: \(realSize[2] == "" ? "-" : realSize[2]) cm", image: UIImage(systemName: "ruler")) { _ in }
                let ankle = UIAction(title: "밑단 단면: \(realSize[3] == "" ? "-" : realSize[3]) cm", image: UIImage(systemName: "ruler")) { _ in }
                let length = UIAction(title: "총장: \(realSize[4] == "" ? "-" : realSize[4]) cm", image: UIImage(systemName: "ruler")) { _ in }
                let url = UIAction(title: "링크 열기" , image: UIImage(systemName: "safari"), attributes: url == "" ? .disabled : []) { [weak self] _ in
                    guard let self = self else { return }
                    self.showSFSafariViewController(itemUrl: url)
                }
                let delete = UIAction(title: "삭제", image: UIImage(systemName: "trash"), attributes: .destructive) { [weak self] _ in
                    guard let self = self else { return }
                    self.ShowAlertDeleteItem(image: "\(item.objectId).jpg", item: item)
                }
                
                let urlAndDelete = UIMenu(options: .displayInline, children: [url, delete])
                
                return UIMenu(title: InfoList.infoResult.secondaryText[item.result], options: .displayInline, children: [waist, thigh, rise, ankle, length, urlAndDelete])
            case .shoes, .acc:
                let url = UIAction(title: "링크 열기" , image: UIImage(systemName: "safari"), attributes: url == "" ? .disabled : []) { [weak self] _ in
                    guard let self = self else { return }
                    self.showSFSafariViewController(itemUrl: url)
                }
                let delete = UIAction(title: "삭제", image: UIImage(systemName: "trash"), attributes: .destructive) { [weak self] _ in
                    guard let self = self else { return }
                    self.ShowAlertDeleteItem(image: "\(item.objectId).jpg", item: item)
                }
                
                let urlAndDelete = UIMenu(options: .displayInline, children: [url, delete])
                
                return UIMenu(title: InfoList.infoResult.secondaryText[item.result], options: .displayInline, children: [urlAndDelete])
            }
        }
        return config
    }
}

extension MoreViewController: UISearchBarDelegate {
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        guard let category = category else { return }
        categoryItems = itemRepository.fetchItemFilterByCategory(category: category)
        mainView.collectionView.reloadData()
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        guard let category = category else { return }
        categoryItems = itemRepository.fetchItemFilterByCategorySearch(category: category, text: searchText)
        
        mainView.collectionView.reloadData()
        
    }
    
}
