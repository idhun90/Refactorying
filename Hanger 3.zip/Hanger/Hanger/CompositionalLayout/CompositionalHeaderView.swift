import UIKit

import SnapKit

final class CompositionalHeaderView: BaseCollectionHeaderReusableView {
    
    let sectionTitleLabel: UILabel = {
        let view = UILabel()
        view.font = .systemFont(ofSize: 22, weight: .bold)
        return view
    }()
    
    let moreButton: UIButton = {
        var attributedTitle = AttributedString.init("모두 보기")
        attributedTitle.font = .systemFont(ofSize: 14)
        var configuration = UIButton.Configuration.plain()
        configuration.attributedTitle = attributedTitle
        configuration.titleAlignment = .trailing
        //configuration.image = UIImage(systemName: "chevron.forward")
        //configuration.imagePlacement = .trailing
        //configuration.imagePadding = 5
        configuration.baseForegroundColor = .customTintColor
        //configuration.baseForegroundColor = .secondaryLabel
        configuration.buttonSize = .small
        let view = UIButton(configuration: configuration)
        //view.isHidden = true
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func configureUI() {
        super.configureUI()
        addSubview(sectionTitleLabel)
        addSubview(moreButton)
        backgroundColor = .clear
    }
    
    override func setConstraints() {
        super.setConstraints()
        sectionTitleLabel.snp.makeConstraints {
            $0.centerY.equalToSuperview()
            $0.leading.equalToSuperview()
        }
        
        moreButton.snp.makeConstraints {
            $0.trailing.equalToSuperview().offset(-10)
            $0.bottom.equalToSuperview()
            
        }
    }
}

