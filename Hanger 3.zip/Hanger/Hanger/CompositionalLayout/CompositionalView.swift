import UIKit

import SnapKit

final class CompositionalView: BaseView {
    
    lazy var collectionView: UICollectionView = {
        let layout = createCompositionalLayout()
        let view = UICollectionView(frame: .zero, collectionViewLayout: layout)
        view.register(CompositionalCell.self, forCellWithReuseIdentifier: CompositionalCell.reusableIdentifier)
        view.register(CompositionalHeaderView.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: CompositionalHeaderView.reusableIdentifier)
        view.backgroundColor = .customBackgroundColor//.systemGroupedBackground
        view.delaysContentTouches = false
        return view
    }()
    
    let emptyLabel: UILabel = {
        let view = UILabel()
        view.text = "추가된 아이템이 없어요."
        view.font = .systemFont(ofSize: 16, weight: .bold)
        view.textColor = .secondaryLabel
        return view
    }()
    
    let emptySubLabel: UILabel = {
        let view = UILabel()
        view.text = "+ 버튼으로 새로운 아이템을 등록해 보세요."
        view.font = .systemFont(ofSize: 14, weight: .regular)
        view.textColor = .secondaryLabel
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func configureUI() {
        self.addSubview(collectionView)
        self.addSubview(emptyLabel)
        self.addSubview(emptySubLabel)
        
    }
    
    override func setConstraints() {
        collectionView.snp.makeConstraints {
            $0.edges.equalToSuperview()
        }
        emptyLabel.snp.makeConstraints {
            $0.center.equalToSuperview()
        }
        emptySubLabel.snp.makeConstraints {
            $0.centerX.equalToSuperview()
            $0.top.equalTo(emptyLabel.snp.bottom).offset(10)
        }
    }
}

extension CompositionalView {
    
    private func createCompositionalLayout() -> UICollectionViewCompositionalLayout {
        return UICollectionViewCompositionalLayout { [weak self] (section: Int, layoutEnvironment: NSCollectionLayoutEnvironment) -> NSCollectionLayoutSection? in

            let itemRepository = ItemRepository()
            
            guard let self = self else { return nil }
            
            switch section {
            case 0: return itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.outer)).count == 0 ? nil : self.setupSection()
            case 1: return itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.top)).count == 0 ? nil : self.setupSection()
            case 2: return itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.bottom)).count == 0 ? nil : self.setupSection()
            case 3: return itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.shoes)).count == 0 ? nil : self.setupSection()
            case 4: return itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.acc)).count == 0 ? nil : self.setupSection()
            default: return nil
            }
        }
    }
    
    private func setupSection() -> NSCollectionLayoutSection {
        //let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0), heightDimension: .fractionalHeight(1.0))
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0), heightDimension: .estimated(120))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        item.contentInsets = .init(top: 0, leading: 0, bottom: 0, trailing: 10)
        
        //let groupSize = NSCollectionLayoutSize(widthDimension: .absolute(200), heightDimension: .absolute(140)) // 135, 고정값
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(0.468), heightDimension: .absolute(140)) // 135, 비율
        //let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(0.93), heightDimension: .absolute(140)) // 135, 비율
        //let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitem: item, count: 2)
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitems: [item])
        
        let section = NSCollectionLayoutSection(group: group)
        section.orthogonalScrollingBehavior = .continuousGroupLeadingBoundary // 한 페이지씩 컨티뉴되도록 96 -> 97번째 줄 수정, 95 -> 94 수정
        section.contentInsets = NSDirectionalEdgeInsets(top: 10, leading: 16, bottom: 25, trailing: 0)
        
        let headerSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0), heightDimension: .absolute(30))
        let header = NSCollectionLayoutBoundarySupplementaryItem(layoutSize: headerSize, elementKind: UICollectionView.elementKindSectionHeader, alignment: .topLeading)
        
        section.boundarySupplementaryItems = [header]
        
//        section.boundarySupplementaryItems = [
//            NSCollectionLayoutBoundarySupplementaryItem(layoutSize: .init(widthDimension: .fractionalWidth(1.0), heightDimension: .absolute(30)), elementKind: UICollectionView.elementKindSectionHeader, alignment: .topLeading)
//        ]
        
        return section
    }
}

