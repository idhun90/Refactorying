import UIKit

import SnapKit

final class CompositionalCell: BaseCollectionViewCell {
    
    let productImage: UIImageView = {
        let view = UIImageView(frame: .zero)
        view.backgroundColor = .tertiarySystemGroupedBackground.withAlphaComponent(0.7)
        view.layer.cornerRadius = 10
        view.layer.masksToBounds = true
        view.layer.borderWidth = 1.0 / view.traitCollection.displayScale
        view.contentMode = .scaleAspectFill
        return view
    }()
    
    let productName: CustomLabel = {
        let view = CustomLabel()
        view.configure(FontSize: 14, weight: .semibold, color: .label)
        
        return view
    }()
    
    let brandName: CustomLabel = {
        let view = CustomLabel()
        view.configure(FontSize: 14, weight: .regular, color: .secondaryLabel.withAlphaComponent(0.7))
        
        return view
    }()
    
    let productSize: CustomLabel = {
        let view = CustomLabel()
        view.configure(FontSize: 14, weight: .regular, color: .secondaryLabel.withAlphaComponent(0.7))
        
        return view
    }()
    
    let fit: CustomLabel = {
        let view = CustomLabel()
        view.configure(FontSize: 14, weight: .regular, color: .secondaryLabel.withAlphaComponent(0.7))
        
        return view
    }()
    
    let result: CustomLabel = {
        let view = CustomLabel()
        view.configure(FontSize: 14, weight: .semibold, color: .customTintColor)
        
        return view
    }()
    
    lazy var stackView: UIStackView = {
        let view = UIStackView(arrangedSubviews: [productSize, fit, result])
        view.axis = .horizontal
        view.alignment = .fill
        view.distribution = .equalSpacing
        view.spacing = 5
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        productImage.layer.borderColor = UIColor.systemGray5.cgColor
        layer.borderColor = UIColor.systemGray5.cgColor
    }
    
    override func configureUI() {
        super.configureUI()
        backgroundColor = .customCellBackgroundColor
        layer.cornerRadius = 12
        
        
        //테두리 두께
        layer.borderWidth = 1.0 / traitCollection.displayScale
        
        // 테두리 색상(여기서 작성하면 다크모드에서 적용이 안 됨 -> layoutSubviews에서 설정하면 다크모드 적용된다
        // https://eunjin3786.tistory.com/301 참조
//        let savedTraicCollection = UITraitCollection.current
//
//        UITraitCollection.current = self.traitCollection
//        self.layer.borderColor = UIColor.systemGray3.cgColor
//
//        UITraitCollection.current = savedTraicCollection
        
        // 그림자 설정
//        self.contentView.layer.cornerRadius = 12
//        self.layer.shadowColor = UIColor.black.cgColor
//        self.layer.shadowOpacity = 0.08
//        self.layer.shadowOffset = CGSize(width: 0, height: 0)
//        self.layer.shadowRadius = self.contentView.layer.cornerRadius
        

        //self.layer.borderWidth = 0.5
        //self.layer.borderColor = UIColor.quaternaryLabel.cgColor // 다크모드 대응 색상 공부하기
        
        //self.contentView.backgroundColor = .secondarySystemGroupedBackground // UIContentMenu 할 때 모서리 체크
        //self.contentView.layer.cornerRadius = 12
        
        
        [productImage, productName, brandName, stackView].forEach {
            contentView.addSubview($0)
        }
        
    }
    
    func loadItemData(item: Item, fitHidden: Bool) {
        productName.text = item.inputValue[0]
        brandName.text = item.inputValue[1]
        productSize.text = item.inputValue[2]
        fit.text = item.fit == nil ? "--" : InfoList.infoFit.secondaryText[item.fit!]
        result.text = InfoList.infoResult.secondaryText[item.result]
        fit.isHidden = fitHidden
        
    }
    
    override func setConstraints() {
        super.setConstraints()
        productImage.snp.makeConstraints {
            let spacing = 10
            $0.top.equalTo(contentView).offset(spacing)
            $0.leading.equalTo(contentView).offset(spacing)
            $0.width.equalTo(contentView).multipliedBy(0.24/*0.22*/)
            $0.height.equalTo(productImage.snp.width)
        }
        
        productName.snp.makeConstraints {
            let spacing = 10
            $0.top.equalTo(productImage.snp.bottom).offset(spacing)
            $0.leading.equalTo(contentView).offset(spacing)
            $0.trailing.lessThanOrEqualTo(contentView).offset(-spacing)
        }
        
        brandName.snp.makeConstraints {
            let spacing = 10
            $0.top.equalTo(productName.snp.bottom).offset(4)
            $0.leading.equalTo(contentView).offset(spacing)
            $0.trailing.lessThanOrEqualTo(contentView).offset(-spacing)
        }
        
        stackView.snp.makeConstraints {
            let spacing = 10
            $0.top.equalTo(brandName.snp.bottom).offset(4)
            $0.leading.equalTo(contentView).offset(spacing)
            $0.trailing.lessThanOrEqualTo(contentView).offset(-spacing)
            $0.bottom.lessThanOrEqualTo(contentView).offset(-spacing)
        }
    }
}

