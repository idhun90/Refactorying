import UIKit
import SafariServices

import SnapKit
import RealmSwift
import FirebaseAnalytics


final class CompositionalViewController: BaseViewController {
    
    private let mainView = CompositionalView()
    
    private let itemRepository = ItemRepository()
    private var items: Results<Item>!
    
    override func loadView() {
        view = mainView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        items = itemRepository.fetchItem()
        print(itemRepository.fetchItemPath())
        
        Analytics.logEvent("테스트", parameters: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        showHiddenEmptyLabel()
        mainView.collectionView.reloadData()
        
    }
    
    override func configureUI() {
        super.configureUI()
        setNavigationController()
        setBarButtonItems()
        setCollectionView()
    }
    
    private func setCollectionView() {
        mainView.collectionView.delegate = self
        mainView.collectionView.dataSource = self
    }
    
    private func setNavigationController() {
        navigationItem.title = "나의 옷"
        navigationController?.navigationBar.prefersLargeTitles = true
    }
    
    private func setBarButtonItems() {
        let addItemButton = UIBarButtonItem(systemItem: .add, primaryAction: nil, menu: setupAddUIMenu())
        let moreButton = UIBarButtonItem(image: UIImage(systemName: "ellipsis.circle"), primaryAction: nil, menu: setupMoreUIMenu())
        navigationItem.rightBarButtonItems = [moreButton, addItemButton]
    }
    
    private func setupMoreUIMenu() -> UIMenu {
        let setting = UIAction(title: "설정", image: UIImage(systemName: "gearshape")) { [weak self] _ in
            let vc = SettingViewController()
            let nav = UINavigationController(rootViewController: vc)
            self?.present(nav, animated: true)
        }
        let menu = UIMenu(children: [setting])
        return menu
    }
    
    private func setupAddUIMenu() -> UIMenu {
        var childeren: [UIAction] {
            
            let outer = UIAction(title: "\(String(describing: SelectedCategory.outer)) 추가") { [weak self] _ in
                guard let self = self else { return }
                let vc = AddViewController()
                vc.selectedCategory = String(describing: SelectedCategory.outer)
                self.transition(viewController: vc, style: .present, animated: true)
            }
            let top = UIAction(title: "\(String(describing: SelectedCategory.top)) 추가") { [weak self] _ in
                guard let self = self else { return }
                let vc = AddViewController()
                vc.selectedCategory = String(describing: SelectedCategory.top)
                self.transition(viewController: vc, style: .present, animated: true)
            }
            let bottom = UIAction(title: "\(String(describing: SelectedCategory.bottom)) 추가") { [weak self] _ in
                guard let self = self else { return }
                let vc = AddViewController()
                vc.selectedCategory = String(describing: SelectedCategory.bottom)
                self.transition(viewController: vc, style: .present, animated: true)
            }
            let shoes = UIAction(title: "\(String(describing: SelectedCategory.shoes)) 추가") { [weak self] _ in
                guard let self = self else { return }
                let vc = AddViewController()
                vc.selectedCategory = String(describing: SelectedCategory.shoes)
                self.transition(viewController: vc, style: .present, animated: true)
            }
            let acc = UIAction(title: "\(String(describing: SelectedCategory.acc)) 추가") { [weak self] _ in
                guard let self = self else { return }
                let vc = AddViewController()
                vc.selectedCategory = String(describing: SelectedCategory.acc)
                self.transition(viewController: vc, style: .present, animated: true)
            }
            
            return [outer, top, bottom, shoes, acc]
        }
        let menu = UIMenu(title: "", options: .displayInline, children: childeren)
        return menu
    }
    
    private func showHiddenEmptyLabel() {
        if items.count == 0 {
            mainView.emptyLabel.isHidden = false
            mainView.emptySubLabel.isHidden = false
        } else {
            mainView.emptyLabel.isHidden = true
            mainView.emptySubLabel.isHidden = true
        }
    }
    
    private func showSFSafariViewController(itemUrl: String) {
        
        if itemUrl != "" {
            
            let encodedUrlValue = itemUrl.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
            
            guard let url = URL(string: encodedUrlValue) else {
                showAlret(title: "유효한 URL이 아닙니다.", message: nil)
                return
            }
            
            if url.scheme == nil {
                guard let url = URL(string: "https://\(url.absoluteString)") else {
                    showAlret(title: "유효한 URL이 아닙니다.", message: nil)
                    return
                }
                
                let safariController = SFSafariViewController(url: url)
                safariController.preferredControlTintColor = .label
                present(safariController, animated: true)
                
            } else {
                let safariController = SFSafariViewController(url: url)
                safariController.preferredControlTintColor = .label
                present(safariController, animated: true)
            }
        }
    }
    
    private func checkAlertToDeleteItem(fileName: String, item: Item, IndexSet: IndexSet) {
        let alert = UIAlertController(title: "아이템을 삭제하시겠습니까?", message: nil, preferredStyle: .actionSheet)
        let delete = UIAlertAction(title: "삭제", style: .destructive) { [weak self] _ in
            guard let self = self else { return }
            self.removeImage(fileName: fileName)
            self.itemRepository.fetchDeleteItem(item: item)
            self.mainView.collectionView.reloadSections(IndexSet)
            self.showHiddenEmptyLabel()
        }
        let cancel = UIAlertAction(title: "취소", style: .cancel)
        
        alert.addAction(delete)
        alert.addAction(cancel)
        
        present(alert, animated: true)
    }
    
}

extension CompositionalViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return SelectedCategory.allCases.count
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        
        guard let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: CompositionalHeaderView.reusableIdentifier, for: indexPath) as? CompositionalHeaderView else { return UICollectionReusableView() }
        
        header.sectionTitleLabel.text = String(describing: SelectedCategory.allCases[indexPath.section])
        header.moreButton.tag = indexPath.section
        header.moreButton.addTarget(self, action: #selector(tappedMoreButton), for: .touchUpInside)
        
        return header
    }
    
    //MARK: 모두 보기 화면 전환
    @objc private func tappedMoreButton(_ sender: UIButton) {
        guard let section = SelectedCategory(rawValue: sender.tag) else { return }
        
        let vc = MoreViewController()
        
        switch section {
        case .outer:
            transferData(vc: vc, item: SelectedCategory.outer.description)
        case .top:
            transferData(vc: vc, item: SelectedCategory.top.description)
        case .bottom:
            transferData(vc: vc, item: SelectedCategory.bottom.description)
        case .shoes:
            transferData(vc: vc, item: SelectedCategory.shoes.description)
        case .acc:
            transferData(vc: vc, item: SelectedCategory.acc.description)
        }
        
        transition(viewController: vc, style: .push, animated: true)
    }
    
    private func transferData(vc: MoreViewController, item: String) {
        vc.category = item
        vc.categoryItems = itemRepository.fetchItemFilterByCategory(category: item)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch section {
        case SelectedCategory.outer.rawValue:
            return itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.outer)).count
        case SelectedCategory.top.rawValue:
            return itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.top)).count
        case SelectedCategory.bottom.rawValue:
            return itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.bottom)).count
        case SelectedCategory.shoes.rawValue:
            return itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.shoes)).count
        case SelectedCategory.acc.rawValue:
            return itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.acc)).count
        default: return 0
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CompositionalCell.reusableIdentifier, for: indexPath) as? CompositionalCell else { return UICollectionViewCell() }
        
        switch indexPath.section {
        case SelectedCategory.outer.rawValue:
            
            let ImageString = itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.outer))[indexPath.item].objectId
            
            cell.loadItemData(item: itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.outer))[indexPath.item], fitHidden: false)
            cell.productImage.image = loadImageFromImageDirectory(fileName: "\(ImageString).jpg")
            
            return cell
            
        case SelectedCategory.top.rawValue:
            
            let ImageString = itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.top))[indexPath.item].objectId
            
            cell.loadItemData(item: itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.top))[indexPath.item], fitHidden: false)
            cell.productImage.image = loadImageFromImageDirectory(fileName: "\(ImageString).jpg")
            
            return cell
            
        case SelectedCategory.bottom.rawValue:
            
            let ImageString = itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.bottom))[indexPath.item].objectId
            
            cell.loadItemData(item: itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.bottom))[indexPath.item],
                              fitHidden: false)
            cell.productImage.image = loadImageFromImageDirectory(fileName: "\(ImageString).jpg")
            
            return cell
            
        case SelectedCategory.shoes.rawValue:
            
            let ImageString = itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.shoes))[indexPath.item].objectId
            
            cell.loadItemData(item: itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.shoes))[indexPath.item],
                              fitHidden: true)
            cell.productImage.image = loadImageFromImageDirectory(fileName: "\(ImageString).jpg")
            
            return cell
            
        case SelectedCategory.acc.rawValue:
            
            let ImageString = itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.acc))[indexPath.item].objectId
            
            cell.loadItemData(item: itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.acc))[indexPath.item],
                              fitHidden: true)
            cell.productImage.image = loadImageFromImageDirectory(fileName: "\(ImageString).jpg")
            
            return cell
            
        default:
            return UICollectionViewCell()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let vc = DetailViewController()
        
        switch indexPath.section {
        case SelectedCategory.outer.rawValue:
            vc.itemData = itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.outer))[indexPath.item]
            
        case SelectedCategory.top.rawValue:
            vc.itemData = itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.top))[indexPath.item]
            
        case SelectedCategory.bottom.rawValue:
            vc.itemData = itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.bottom))[indexPath.item]
            
        case SelectedCategory.shoes.rawValue:
            vc.itemData = itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.shoes))[indexPath.item]
            
        case SelectedCategory.acc.rawValue:
            vc.itemData = itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.acc))[indexPath.item]
            
        default :
            print("문제 발생")
        }
        
        transition(viewController: vc, style: .push, animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, contextMenuConfigurationForItemAt indexPath: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {
        

        let config = UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { [weak self] _ in
            
            guard let self = self else { return nil }
            
            switch indexPath.section {
            case SelectedCategory.outer.rawValue :
                let item = self.itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.outer))[indexPath.item]
                let realSize = item.realSizeArray!
                let itemUrl = item.url
                
                let shoulder = UIAction(title: "어깨 너비: \(realSize[0] == "" ? "-" : realSize[0] ) cm", image: UIImage(systemName: "ruler")) { _ in }
                let chest = UIAction(title: "가슴 단면: \(realSize[1] == "" ? "-" : realSize[1]) cm", image: UIImage(systemName: "ruler")) { _ in }
                let sleeve = UIAction(title: "소매 길이: \(realSize[2] == "" ? "-" : realSize[2]) cm", image: UIImage(systemName: "ruler")) { _ in }
                let length = UIAction(title: "총장: \(realSize[3] == "" ? "-" : realSize[3]) cm", image: UIImage(systemName: "ruler")) { _ in }
                
                let url = UIAction(title: "링크 열기",image: UIImage(systemName: "safari"), attributes: itemUrl == "" ? .disabled : []) { [weak self] _ in
                    guard let self = self else { return }
                    self.showSFSafariViewController(itemUrl: itemUrl)
                }
                let delete = UIAction(title: "삭제", image: UIImage(systemName: "trash"), attributes: .destructive) { [weak self] _ in
                    guard let self = self else { return }
                    self.checkAlertToDeleteItem(fileName: "\(item.objectId).jpg", item: item, IndexSet: IndexSet(indexPath.section ... indexPath.section))
                }
                let urlAndDelete = UIMenu(title: "", image: nil, options: .displayInline, children: [url, delete])
                
                return UIMenu(title: InfoList.infoResult.secondaryText[item.result], image: UIImage(systemName: "ruler"), identifier: nil, options: .displayInline, children: [shoulder, chest, sleeve, length, urlAndDelete])
                
            case SelectedCategory.top.rawValue :
                let item = self.itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.top))[indexPath.item]
                let realSize = item.realSizeArray!
                let itemUrl = item.url
                
                let shoulder = UIAction(title: "어깨 너비: \(realSize[0] == "" ? "-" : realSize[0]) cm", image: UIImage(systemName: "ruler")) { _ in }
                let chest = UIAction(title: "가슴 단면: \(realSize[1] == "" ? "-" : realSize[1]) cm", image: UIImage(systemName: "ruler")) { _ in }
                let sleeve = UIAction(title: "소매 길이: \(realSize[2] == "" ? "-" : realSize[2]) cm", image: UIImage(systemName: "ruler")) { _ in }
                let length = UIAction(title: "총장: \(realSize[3] == "" ? "-" : realSize[3]) cm", image: UIImage(systemName: "ruler")) { _ in }
                
                let url = UIAction(title: "링크 열기",image: UIImage(systemName: "safari"), attributes: itemUrl == "" ? .disabled : []) { [weak self] _ in
                    guard let self = self else { return }
                    self.showSFSafariViewController(itemUrl: itemUrl)
                }
                let delete = UIAction(title: "삭제", image: UIImage(systemName: "trash"), attributes: .destructive) { [weak self] _ in
                    guard let self = self else { return }
                    self.checkAlertToDeleteItem(fileName: "\(item.objectId).jpg", item: item, IndexSet: IndexSet(indexPath.section ... indexPath.section))
                }
                let urlAndDelete = UIMenu(title: "", image: nil, options: .displayInline, children: [url, delete])
                
                return UIMenu(title: InfoList.infoResult.secondaryText[item.result], image: nil, identifier: nil, options: .displayInline, children: [shoulder, chest, sleeve, length, urlAndDelete])
                
            case SelectedCategory.bottom.rawValue :
                let item = self.itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.bottom))[indexPath.item]
                let realSize = item.realSizeArray!
                let itemUrl = item.url
                
                let waist = UIAction(title: "허리 단면: \(realSize[0] == "" ? "-" : realSize[0]) cm", image: UIImage(systemName: "ruler")) { _ in }
                let thigh = UIAction(title: "허벅지 단면: \(realSize[1] == "" ? "-" : realSize[1]) cm", image: UIImage(systemName: "ruler")) { _ in }
                let rise = UIAction(title: "밑위: \(realSize[2] == "" ? "-" : realSize[2]) cm", image: UIImage(systemName: "ruler")) { _ in }
                let ankle = UIAction(title: "밑단 단면: \(realSize[3] == "" ? "-" : realSize[3]) cm", image: UIImage(systemName: "ruler")) { _ in }
                let length = UIAction(title: "총장: \(realSize[4] == "" ? "-" : realSize[4]) cm", image: UIImage(systemName: "ruler")) { _ in }
                
                let url = UIAction(title: "링크 열기",image: UIImage(systemName: "safari"), attributes: itemUrl == "" ? .disabled : []) { [weak self] _ in
                    guard let self = self else { return }
                    self.showSFSafariViewController(itemUrl: itemUrl)
                }
                let delete = UIAction(title: "삭제", image: UIImage(systemName: "trash"), attributes: .destructive) { [weak self] _ in
                    guard let self = self else { return }
                    self.checkAlertToDeleteItem(fileName: "\(item.objectId).jpg", item: item, IndexSet: IndexSet(indexPath.section ... indexPath.section))
                }
                let urlAndDelete = UIMenu(title: "", image: nil, options: .displayInline, children: [url, delete])
                
                return UIMenu(title: InfoList.infoResult.secondaryText[item.result], image: nil, identifier: nil, options: .displayInline, children: [waist, thigh, rise, ankle, length, urlAndDelete])
                
            case SelectedCategory.shoes.rawValue :
                
                let item = self.itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.shoes))[indexPath.item]
                let itemUrl = item.url
                let url = UIAction(title: "링크 열기",image: UIImage(systemName: "safari"), attributes: itemUrl == "" ? .disabled : []) { [weak self] _ in
                    guard let self = self else { return }
                    self.showSFSafariViewController(itemUrl: itemUrl)
                }
                let delete = UIAction(title: "삭제", image: UIImage(systemName: "trash"), attributes: .destructive) { [weak self] _ in
                    guard let self = self else { return }
                    self.checkAlertToDeleteItem(fileName: "\(item.objectId).jpg", item: item, IndexSet: IndexSet(indexPath.section ... indexPath.section))
                }
                let urlAndDelete = UIMenu(title: "", options: .displayInline, children: [url, delete])
                
                return UIMenu(title: InfoList.infoResult.secondaryText[item.result], image: nil, identifier: nil, options: .displayInline, children: [urlAndDelete])
                
            case SelectedCategory.acc.rawValue :
                let item = self.itemRepository.fetchItemFilterByCategory(category: String(describing: SelectedCategory.acc))[indexPath.item]
                let itemUrl = item.url
                let url = UIAction(title: "링크 열기",image: UIImage(systemName: "safari"), attributes: itemUrl == "" ? .disabled : []) { [weak self] _ in
                    guard let self = self else { return }
                    self.showSFSafariViewController(itemUrl: itemUrl)
                }
                let delete = UIAction(title: "삭제", image: UIImage(systemName: "trash"), attributes: .destructive) { [weak self] _ in
                    guard let self = self else { return }
                    self.checkAlertToDeleteItem(fileName: "\(item.objectId).jpg", item: item, IndexSet: IndexSet(indexPath.section ... indexPath.section))
                }
                let urlAndDelete = UIMenu(title: "", options: .displayInline, children: [url, delete])
                
                return UIMenu(title: InfoList.infoResult.secondaryText[item.result], image: nil, identifier: nil, options: .displayInline, children: [urlAndDelete])
                
            default :
                print("오류 발생")
                return nil
            }
        }
        
        return config
    }
    
    func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        if let cell = collectionView.cellForItem(at: indexPath) as? CompositionalCell {
            //cell.backgroundColor = .CustomTapColor
            
            UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 1) {
                cell.transform = CGAffineTransform(scaleX: 0.96, y: 0.96)
                cell.layoutIfNeeded()
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        if let cell = collectionView.cellForItem(at: indexPath) as? CompositionalCell {
            //cell.backgroundColor = .customCellBackgroundColor
            
            UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0) {
                cell.transform = .identity
            }
        }
    }
}
