import Foundation

import RealmSwift

class Item: Object {
    @Persisted(primaryKey: true) var objectId: ObjectId
    
    @Persisted var category: String
    @Persisted var createdImageData: Date?
    @Persisted var inputValue: List<String> // [제품명, 브랜드, 사이즈, 색상, 가격, 구매일]
    @Persisted var fit: Int?
    @Persisted var result: Int
    @Persisted var realSizeValue: List<String?> // [어깨 너비, 가슴 단면, 소매 길이, 총장]
    // 또는 [허리 단면, 허벅지 단면, 밑위, 밑단 단면, 총장] 또는 [없음]
    @Persisted var createdDate = Date()
    @Persisted var url: String
    @Persisted var memo: String
    
    var inputArray: [String] {
        get {
            return inputValue.map{ $0 }
        } set {
            inputValue.removeAll()
            inputValue.append(objectsIn: newValue)
        }
    }
    
    var realSizeArray: [String]? {
        get {
            return realSizeValue.map{ $0 ?? "--" }
        } set {
            realSizeValue.removeAll()
            realSizeValue.append(objectsIn: newValue ?? ["--"])
        }
    }
    
    
    //@Persisted var fit: String?
    //@Persisted var result: String
    
    //@Persisted var outerOrTopRealSize: List<OuterOrTop>
    //@Persisted var bottomRealSize: List<Bottom>
    
    convenience init(category: String, createdImageData: Date?, fit: Int?, result: Int, createdDate: Date, url: String, memo: String) {
        self.init()
        self.category = category
        self.createdImageData = createdImageData
        self.inputValue = inputValue
        self.fit = fit
        self.result = result
        self.realSizeValue = realSizeValue
        self.createdDate = createdDate
        self.url = url
        self.memo = memo
    }
}

//class OuterOrTop: Object {
//    @Persisted var shoulder: Int? // 어깨 너비
//    @Persisted var chest: Int? // 가슴 너비
//    @Persisted var sleeve: Int? // 소매 길이
//    @Persisted var length: Int? // 총장
//}
//
//class Bottom: Object {
//    @Persisted(primaryKey: true)
//    @Persisted var waist: Int? //허리 단면
//    @Persisted var thigh: Int? // 허벅지 단면
//    @Persisted var rise: Int? // 밑위
//    @Persisted var ankle: Int? // 밑단
//    @Persisted var length: Int? // 총장
//
//}

//class Category: Object {
//    @Persisted var outer = "아우터"
//    @Persisted var top = "상의"
//    @Persisted var bottom = "하의"
//    @Persisted var shoes = "신발"
//    @Persisted var acc = "액세서리"
//}
//
//class Fit: Object {
//    @Persisted var slimSize = "슬림"
//    @Persisted var trueSize = "정사이즈"
//    @Persisted var semiOverSize = "세미오버"
//    @Persisted var overSize = "오버"
//}
//
//class Result: Object {
//    @Persisted var small = "작아요"
//    @Persisted var good = "잘 맞아요"
//    @Persisted var big = "커요"
//}

