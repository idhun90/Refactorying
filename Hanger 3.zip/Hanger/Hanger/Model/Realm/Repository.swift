import Foundation

import RealmSwift

enum ConvertFit: String {
    case slim = "슬림"
    case regular = "정사이즈"
    case semi = "세미오버"
    case over = "오버"
    
    var converToInt: Int {
        switch self {
        case .slim:
            return 0
        case .regular:
            return 1
        case .semi:
            return 2
        case .over:
            return 3
        }
    }
}

enum ConvertResult: String {
    case small = "작아요"
    case good = "잘 맞아요"
    case goodTrimmingwhitespaces = "잘맞아요"
    case big = "커요"
    
    var convertToInt: Int {
        switch self {
        case .small:
            return 0
        case .good:
            return 1
        case .goodTrimmingwhitespaces:
            return 1
        case .big:
            return 2
        }
    }
}

class ItemRepository {
    let localRealm = try! Realm()
    
    func fetchItemPath() -> URL {
        return localRealm.configuration.fileURL!
    }
    
    func fetchItem() -> Results<Item> {
        return localRealm.objects(Item.self).sorted(byKeyPath: "createdDate", ascending: false)
    }
    
    func fetchItemSort(by: String) -> Results<Item> {
        return localRealm.objects(Item.self).sorted(byKeyPath: by, ascending: false)
    }
    
    func fetchItemFilterByCategory(category: String) -> Results<Item> {
        return localRealm.objects(Item.self).filter("category CONTAINS '\(category)'").sorted(byKeyPath: "createdDate", ascending: false)
    }
    
    func convertFit(text: String) -> Int {
        // 슬림, 정사이즈, 세미오버, 오버
        guard let fit = ConvertFit(rawValue: text.trimmingCharacters(in: .whitespaces)) else { return 4 }
        
        switch fit {
        case .slim:
            return ConvertFit.slim.converToInt
        case .regular:
            return ConvertFit.regular.converToInt
        case .semi:
            return ConvertFit.semi.converToInt
        case .over:
            return ConvertFit.over.converToInt
        }
    }
    
    func convertResult(text: String) -> Int {
        // 작아요, 잘 맞아요, 커요
        guard let result = ConvertResult(rawValue: text) else { return 3 }
        
        switch result {
        case .small:
            return ConvertResult.small.convertToInt
        case .good:
            return ConvertResult.good.convertToInt
        case .goodTrimmingwhitespaces:
            return ConvertResult.goodTrimmingwhitespaces.convertToInt
        case .big:
            return ConvertResult.big.convertToInt
        }
    }
    
    func fetchItemFilterBySearchText(text: String) -> Results<Item> {
        let predicate = NSPredicate(format: "ANY inputValue CONTAINS[c] '\(text)' OR fit == \(convertFit(text: text)) OR result == \(convertResult(text: text))")
        
        return localRealm.objects(Item.self).filter(predicate).sorted(byKeyPath: "createdDate", ascending: false)
    }
    
    func fetchItemFilterByCategorySearch(category: String, text: String) -> Results<Item> {
        
        
        /*참조
         https://www.mongodb.com/docs/realm/realm-query-language/
         https://academy.realm.io/posts/nspredicate-cheatsheet/
         
         방법 1
         - 아래 조건으로 검색했을 때 글자를 모두 완성해야 결과가 검색됨. 예: '에어팟' 에서 '에'만 입력 시 결과 검색 안됨
         return fetchItemFilterByCategory(category: category).where {
                     $0.inputValue.contains(text)
         }
         
         방법 2
         - Ream에서 지원을 안 하는 것인지 작동 자체가 안됨
         return fetchItemFilterByCategory(category: category).filter("SUBQUERY(inputValue, inputValue, inputValue CONTAINS[c] '\(text)').@count > 0")
         
         방법 3
         - 실시간으로 글자 하나하나 입력할 때마다 검색 가능. 단 내가 검색하고 싶은 건 제품명/브랜드/사이즈/핏/후기지만 불필요한 요소까지 검색이 됨
         let predicate = NSPredicate(format: "ANY inputValue CONTAINS[c] %@", text)
         */
        
        
        let predicate = NSPredicate(format: "ANY inputValue CONTAINS[c] '\(text)' OR fit == \(convertFit(text: text)) OR result == \(convertResult(text: text))")

        
        //return fetchItemFilterByCategory(category: category)[index]
        return fetchItemFilterByCategory(category: category).filter(predicate)
//
        
//

        // Key paths that include a collection property must use aggregate operations 오류 발생
        //let predicate = NSPredicate(format: "inputValue == %@", text)
        
//        fetchItemFilterByCategory(category: category).where { item in
//            item.inputValue.contains(text)
//        }
//
//        }
//        let b = fetchItemFilterByCategory(category: category).filter()
        
//        return fetchItemFilterByCategory(category: category).filter("inputValue CONTAINS '[\(text)]'")
//        for _ in 0...fetchItemFilterByCategory(category: category).count {
//            fetchItemFilterByCategory(category: category).filter { $0.inputValue[0].contains(text)}
//        }
    }
    
    func fetchAddItem(item: Item) {
        do {
            try localRealm.write {
                localRealm.add(item)
                print("아이템 추가 성공")
            }
        } catch let error {
            print("아이템 추가 실패", error)
            // 토스트 사용자 알림 추가
        }
    }
    
    func fetchDeleteItem(item: Item) {
        do {
            try localRealm.write {
                localRealm.delete(item)
                print("아이템 삭제 성공")
            }
        } catch let error {
            print("아이템 삭제 실패", error)
            // 토스트 사용자 알림 추가
        }
    }
    
//    func fetchChangedItemInfo(objectId: ObjectId, image: Data?, createdDate: Date, fit: Int?, result: Int, url: String, memo: String) {
//        do {
//            try localRealm.write {
//                localRealm.create(Item.self, value: ["objectId": objectId, "image": image, "createdDate": createdDate, "fit": fit, "result": result, "url": url, "memo": memo], update: .modified)
//                print("아이템 수정 성공")
//            }
//        } catch let error {
//            print("아이템 수정 실패", error)
//        }
//    }
}

