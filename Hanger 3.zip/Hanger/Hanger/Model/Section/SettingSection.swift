import Foundation

enum SelectedCategory: Int, CaseIterable ,CustomStringConvertible {
    case outer
    case top
    case bottom
    case shoes
    case acc
    
    var description: String {
        switch self {
        case .outer:
            return "아우터"
        case .top:
            return "상의"
        case .bottom:
            return "하의"
        case .shoes:
            return "신발"
        case .acc:
            return "액세서리"
        }
    }
}

enum Section: Int, CaseIterable {
    case input
    case info
    case realSize
    case urlAndMemo
}

enum InputList: Int, CaseIterable, CustomStringConvertible {
    case inputName
    case inputBrand
    case inputSize
    case inputColor
    case inputPrice
    case inputDate
    
    var description: String {
        switch self {
        case .inputName:
            return "제품명"
        case .inputBrand:
            return "브랜드"
        case .inputSize:
            return "사이즈"
        case .inputColor:
            return "색상"
        case .inputPrice:
            return "가격"
        case .inputDate:
            return "구매일"
        }
    }
}

enum InfoList: Int, CaseIterable, CustomStringConvertible {
    
    case infoFit
    case infoResult
    
    var description: String {
        switch self {
        case .infoFit:
            return "핏"
        case .infoResult:
            return "후기"
        }
    }
    var secondaryText: [String] {
        switch self {
        case .infoFit:
            return ["슬림", "정사이즈", "세미오버", "오버"]
        case .infoResult:
            return ["작아요", "잘 맞아요", "커요"]
        }
    }
}

enum RealSizeOptions: Int, CaseIterable {
    case realSizeOuterOrTop
    case realSizeBottom
    
    var contents: [String] {
        switch self {
        case .realSizeOuterOrTop:
            return ["어깨 너비", "가슴 단면", "소매 길이", "총장"]
        case .realSizeBottom:
            return ["허리 단면", "허벅지 단면", "밑위", "밑단 단면", "총장"]
        }
    }
}

enum UrlAndMemoList: Int, CaseIterable, CustomStringConvertible {
    case url
    case memo
    
    var description: String {
        switch self {
        case .url:
            return "URL"
        case .memo:
            return "메모"
        }
    }
}
