# Hanger
# 9월 20일
# 진행 내용
- Cell 재사용 문제 해결
	- 각 섹션 별 텍스트필드 값을 담을 배열 생성
		- ![섹션별 텍스트 필드 값 담을 배열 생성](https://user-images.githubusercontent.com/51053410/191324380-2ea26120-f811-4829-8629-4094d10843bc.png)
	- 섹션별 분기처리하여 실시간으로 값을 배열에 저장
		- ![섹션별 분기처리](https://user-images.githubusercontent.com/51053410/191324422-dc5dbc2b-7323-4c54-94e8-122051b96e77.png)
# 발생했던 문제
- **실측 사이즈 저장 배열 count 문제**
	- Cell 재사용 문제 해결을 위해 5개의 스트링 값을 가지는 실측 사이즈 저장 배열을 생성함.
	- 카테고리 별로 필요한 실측 사이즈 갯수가 다르다. -> 아우터/상의는 4개, 하의는 5개
	- 카테고리 별로 배열을 만들기도 그렇고, 아우터/상의 카테고리에서는 한 개의 스트링 값이 계속 비어져있는 부분이 신경 쓰임
	- 분기처리를 통해 배열의 마지막 index를 삭제하는 방식으로 해결을 했다.
	 <img width="1299" alt="실측 사이즈 배열 갯수 분기 처리" src="https://user-images.githubusercontent.com/51053410/191324480-f40f1db1-a360-4bbd-ad30-1b22d7f2f352.png">
- **DatePicker 값 실시간으로 특정 텍스트 필드에 보여주지 않던 문제**
	- 실시간으로 텍스트필드의 값을 저장하는 도중 '구매일' 텍스트필드의 실시간 값을 저장하지 못 하는 문제가 있었다.
	- DatePicker는 '구매일' 텍스트필드의 inputView로 할당된 상태
	- DatePicker는 별도의 프로토콜이 없다. addTarget 구문을 통해 액션을 제어해야함
	- **발생 원인**
		- 메소드 매개변수에 UITextField를 받도록 구현했는데, 어떤 텍스트필드인지 알지 못 하여 반영이 안 됐었음. 잭님 감사합니다ㅠㅠ 이런 건 어떻게 캐치하는거죠?
	- **해결 방안 1**
		- DatePicker 값을 배열에 저장하고 해당 TableCell만 reload 되게끔 구현
			- 발생 문제: 리로딩되면서 Cell에 배열 값이 갱신되어 실시간으로 보여주긴 했지만, DatePicker가 내려감. -> 년도/월/일 모두를 수정하고 싶을 때 세 항목 중 하나만 수정을 하고 데이터피커가 잠깐이라도 멈추면 테이블뷰 Cell이 리로딩되어 데이터피커가 내려가서 나머지 항목 수정이 안 됨
	- **해결 방안 2**
		- DatePicker 값을 배열에 저장하고 해당 Cell에 바로 대입해주도록 처리
		- 타입 캐스팅을 통해 해당 Cell의 텍스트필드에 접근할 수 있도록 tableView.cellForRowAt(at:) 메소드 활용
		- 테이블뷰 리로딩없이 갱신 가능했다.
![데이터피커 실시간 값 반영](https://user-images.githubusercontent.com/51053410/191324559-5a815495-38e5-49d4-8cfa-893c298996b8.png)
![데이터피커 실시간 값 반영](https://user-images.githubusercontent.com/51053410/191324576-a8a2de0c-e4eb-48c8-b96f-5732f80d4baa.gif)

---
# 9월 19일 진행 내용
- 없음, 하루 종일 재사용 Cell 문제 해결 못 함.
---
# 9월 17~18일 진행 내용
## Section 열거형 관리
- **Ream & 데이터 값 전달 및 리터럴 값 제거를 위한 용도**
	- CustomStringConvertible 프로토콜 사용
		- String(description:)
## UI 변경
- **기존 '새로운 아이템' 등록화면에서 카테고리를 설정하는 구조에서 메인 화면에서 선택된 카테고리를 통해 '새로운 아이템' 등록화면에 접근하도록 수정**
	- ![메인 화면에 카테고리 분류](https://user-images.githubusercontent.com/51053410/190924423-e97621a9-75c0-4332-8b75-573df0883b52.png)
	- UIMenu 활용
	- 기존 '새로운 아이템'등록화면에서 '카테고리' 항목 삭제
	- 테이블 뷰 내부 코드 모두 수정

## 딜리게이트 패턴으로 값 전달 구현
- '핏', '후기' 화면에서 선택한 값 이전 화면으로 전달
- ![델리게이트 값전달](https://user-images.githubusercontent.com/51053410/190924449-a854d32f-7b31-412f-b32b-bd38aed32543.gif)

# 발생 문제
## Cell 재사용 문제
- 값전달 프로토콜에 테이블 뷰 리로드 구문을 작성하고 테스트 중에 Cell 재사용 문제 발견
	- 해당 섹션만 리로드 되도록 구현했을 땐 문제가 없어보이나 위, 아래로 스크롤 하여 Cell이 재사용될 때마다 각 Cell의 텍스트필드 순서가 뒤죽박죽 꼬이는 문제 발생
	- CellForRowAt 코드 처음부터 다시 작성 -> 여전히 문제 해결 안 됨
	- 모든 분기 처리를 한 것 같은데 원인을 모르겠다
	- ![Cell 재사용 꼬임 문제](https://user-images.githubusercontent.com/51053410/190924590-1cea1263-ee7b-4b14-b5d6-6adace93f012.gif)

## 테이블뷰의 특정 섹션을 리로딩할 때마다 발생하는 이상한 디버깅 오류
- 프로토콜로 가져온 값을 테이블뷰에 보여주기 위해 해당 섹션만 리로드 했을 때 발생하는 오류
- 구글링해보니 레이아웃 관련 문제인 것 같은데 따로 애플 기본 테이블뷰 구조를 이용하고 있어서 레이아웃 오류 문제는 아닌 것 같다..
<img width="1156" alt="리로딩 오류" src="https://user-images.githubusercontent.com/51053410/190924468-8c6572f4-5f8c-43d0-a330-9554e9a19ace.png">

---
# 9월 15일 진행 내용
## - Realm
- **기본 타입 외에도 EmbeddedObject, 열거형 타입 사용 가능**
- **스위프트 배열을 바로 사용할 수 없지만, List 라는 형태로 Realm에서 제공함**
- **키-값 타입으로 사용하려면 @Persisted 앞에 @objc 추가 필요**
	- 예: ```@Persisted @objc var myObject: MyClass?```
- **@Persisted로 아래 기본 프로퍼티를 설정할 때 성능에 영향을 미칠 수 있다.**
	- List
	- MutableSet
	- Dictionary
	- Decimal128
	- UUID
	- ObjectId
	- 선언 방식에 따른 성능 이슈
		- ```@Persisted @objc var listProperty: List<Int>```와 ```@Persisted @objc var listProperty: List<Int>()``` 두 방식으로 선언할 수 있는데, 후자의 경우 성능 저하가 있을 수 있다. List는 부모 객체가 생성될 때 생성되기 때문이다. 미미하지만 성능에 영향은 있으니 주의
- **Map/Dictionary**
	- Map은 Realm이 지원하는 타입을 키-값으로 저장한다.
	- Map의 키값은 오직 String 타입만 가능하다
	- 스위프트 컬렉션과 달리 참조타입이다.
	- 기존 ```Results<Value>```로 필터링 또는 정렬할 수 있다.
	- Object 서브 클래스에 있는 Map 타입의 프로퍼티는 꼭 let으로 설정되야 한다. 동적일 수 없다.
- **UIImage는 데이터 타입 (Data())로 저장할 것**
	- 최대 용량은 16MB
	- 용량이 크다면 별도 관리 권장 (도큐먼트)
		```
		let data: Data = image?.jpegData(compressionQuality: 0.9) // UIImage -> Data
		let uiImage: UIImage = UIImage(data: imageData) // Data -> UIImage
		```
## - 열거형
- CustomStringConvertible 프로토콜
	- 사용자 정의 텍스트 표현을 할 수 있는 타입. 사용자 정의 텍스트 표현은 return 또는 출력하는 용으로 사용할 수 있다.

## - 카메라 찍기 & 사진 보관함에서 앨범 가져오기
![이미지 찍거나 가져오기 위한 버튼 추가](https://user-images.githubusercontent.com/51053410/190569488-062f7a81-8f08-48a9-9d37-9a64b9e3b6b7.png)
![UIMenu 활용](https://user-images.githubusercontent.com/51053410/190569508-e07c0bb9-066a-4460-b854-a6351ab13bdc.png)
![이미지 가져온 후 버튼 타이틀 변경](https://user-images.githubusercontent.com/51053410/190569531-ac1b0c2d-c720-4b52-abb7-c8b6e241954b.png)

- Button + UIMenu 활용
	- 카메라 찍기
		- UIImagePickerController 활용
		- UIImagePickerControllerDelegate 딜리게이트에 imagePickerController( _ : didFinishPickingMediaWithInfo) 메소드 추가
			- InfoKey에 원본 이미지를 이미지 뷰에 할당하고, Button title "카메라 찍기" -> "편집" 으로 변경 구문 작성함
	- 사진 보관함
		- PHPickerViewController 활용
			- PHPickerViewControllerDelegate 딜리게이트에 picker(_ picker:, didFinishPicking:) 메소드 추가
				- LoadObject에 이미지를 로드할 수 있다면 DispatchQue.main.async 내에 이미지 뷰에 할당 및 Button title "사진 보관함" -> "편집"으로 변경 구문 추가
				
## - 디테일 화면 UI 구현
![디테일화면 UI](https://user-images.githubusercontent.com/51053410/190569630-5205bb8d-8cc2-4e03-89ec-d1bbd0a5fabb.png)

- 테이블 뷰 구현 과정은 생략

# 고민하는 문제
## - 테이블 뷰 UI 요소들
- 처음 앱 디자인을 고민할 때 특히 테이블 뷰 UI 요소는 최대한 애플스럽게 만들기 위해서 애플이 제공하는 프로퍼티를 활용하고자 했다.
- Cell에는 textLabel, detailLabel 대신 defaultContentConfiguration()를 사용했다. content.AttributedText, content.secondaryAttributedText

<img width="1040" alt="테이블뷰 Cell_defaultContentConfiguration" src="https://user-images.githubusercontent.com/51053410/190569677-25fce9cc-6c71-4728-a752-aa431badd4dd.png">

- 선택한 Cell의 text 또는 secondaryText에 할당된 String 값을 가져오고 싶은데 index만 가져올 수 있다. 이럴 줄 알았으면 UI 다 커스텀으로 할 껄 하하....
![선택 Cell, String 값 가져오기](https://user-images.githubusercontent.com/51053410/190569724-1feb8ff9-fdba-4197-a29c-b84548d35272.png)


## - 테이블 구조
![테이블 구조](https://user-images.githubusercontent.com/51053410/190569742-7a25526f-e35a-4315-b30e-587427a82d48.png)

- 피드백 주신 내용으로 수정이 필요할 것 같다.
	- 카테고리, 핏, 후기 상수 값 별도 관리 여부
	- 컬럼 수정 필요
		- ![컬럼 수정 필요](https://user-images.githubusercontent.com/51053410/190569760-4320916b-6c2a-4089-8cfa-ce3ef5adf494.png)

	- 어떤 아이템의 실측 사이즈인지 확인할 수 있는 아이템 식별 PK
---
# 9월 14일 진행 내용
### 구현 기능: 선택한 순간에만 Cell 배경색 변경 및 체크마크 표시
![선택한 순간 Cell 배경색 변경 및 체크마크 표시](https://user-images.githubusercontent.com/51053410/190391518-52bcdad5-ad73-4580-9dba-8f2bb67cf74f.gif)

- [Manage selection lists](https://developer.apple.com/documentation/uikit/uitableviewdelegate/handling_row_selection_in_a_table_view) 애플 공식 문서 예제 코드 참고하여 수정

# 발생한 문제
- **실측 사이즈 섹션 공백 시 여백 문제**
![섹션 header, footer 높이 공백](https://user-images.githubusercontent.com/51053410/190391730-9e90fc2d-a482-4d12-9c01-ee37fc835c3c.png)
	- 선택한 카테고리에 맞춰 대응되는 실측 사이즈 섹션을 구현하고자 했다.
	- 아우터, 상의
		- 어깨 너비, 가슴 단면, 소매 길이, 총장
	- 하의
		- 허리 단면, 허벅지 단면, 밑위, 밑단 단면, 총장
	- 이 외 나머지 항목
		- 비어 있음
	
하지만 위에 사진처럼 공백으로 처리될 시 섹션 사이 여백에 문제가 생겼다. 셀을 hidden 처리해도 섹션 헤더, 푸터 높이 때문인지 여전히 섹션 사이 여백이 상이했다.

``` 
시도1. view.sectionHeaderTopPadding = 0.0 // insetGrouped에서 안 됨

시도2.  func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return CGFloat.leastNonzeroMagnitude
    } // 안됨
    
시도3. tableView.sectionFooterHeight = 0 // 모든 섹션에 영향이 발생
```

[다시 읽어볼 것](https://stackoverflow.com/questions/30364067/space-between-sections-in-uitableview)
[다시 읽어볼 것2](https://stackoverflow.com/questions/1061208/how-to-hide-a-section-in-uitableview)

- 키보드 iOS 15 애플에서 제공하는 키보드 가림 문제 해결 방법
[키보드 iOS 15 UIKeyboardGuide](https://zeddios.tistory.com/1282)

# 참고 영상
- **테이블뷰 열거형 관리**
	- [테이블 뷰 열거형으로 관리하기](https://www.youtube.com/watch?v=WqPoFzVrLj8)
- **Creating Expandable TableView Cells**
	- [Creating Expandable TableView Cells](https://www.youtube.com/watch?v=samoIVHg6yQ)

---
# 9월 13일 진행 내용
- [[9월 12일 진행 내용]] '발생했던 문제'에서 선택한 checkmask만 표시되게끔 구현 하는 과정 테스트 한 차례 더 진행
	1. didSelectRowAt과 didDeselectRowAt에만 체크마크 구문 추가
	 	- 재사용 중복 쎌 문제 O
	1. didSelectRowAt과 didDeselectRowAt에만 체크마크 + cellforRowAt에 cell.accessoryType = cell.**isSelected** ? .checkmark : .none 추가
	 	- 재사용 중복 쎌 문제 X, 스크롤 시 체크 마크 함께 없어짐
	1. didSelectRowAt과 didDeselectRowAt에만 체크마크 구문 추가 + cell 파일에서 isSelect didSet 구문 추가
	 	- 재사용 중복 쎌 문제 X, 스크롤 시 체크 마크 유지
	1. **cell 파일에 SetSelected 구문 오버라이딩하여 내부에 cell.accessoryType = cell.isSelected ? .checkmark : .none 코드 추가**
	 	- **모든 문제 해결... didSelectRowAt, didDeselectRowAt에 코드 추가 불필요**
	- 결론만 말하자면 CellForRowAt에서 ``` cell.accessoryType = cell.isSelected ? .checkmark : .none ```를 추가했어도 스크롤을 하면 isSelected 값이 false로 초기화 되었다.
	- Cell 파일에서 아래 코드를 작성하면 스크롤을 해도 isSelected 값이 유지된다. (cellForRowAt에는 위 코드가 없는 상태 + didSelectRowAt과 didDeselectRowAt에만 체크마크 구문 필요)
		```
		override var isSelected: Bool {
		    didSet {
		        self.accessoryType = isSelected ? .checkmark : .none
		    }
		}
		```
	- Cell 파일에서 SetSelected 구문에서 ```accessoryType = cell.isSelected```를 추가하면 Cell이 재사용 여부와 상관없이 정확하게 선택 여부에 따라 체크마크가 표시된다. didSelectRowAt과 didDeselectRowAt에만 체크마크 구문이 없어도 말이다!!!!!
- Modern Cell Configuration in iOS 14를 한 차례 더 학습했다.
	- 아래 유튜브 영상 참고

셀을 클릭했을 때 백그라운드 색상이 남아있지 않으면서 checkmask만 표시해주는 애플 공식 자료가 있었다. 읽고 다시 수정해야할 듯

https://velog.io/@panther222128/Handling-Row-Selection-in-a-Table-View
https://developer.apple.com/documentation/uikit/uitableviewdelegate/handling_row_selection_in_a_table_view

---
# 9월 12일 진행 내용
- **'새로운 아이템' 등록 화면 dismiss 또는 취소 누를 때 actionsheet 띄움 구현**
	- 뷰의 변화를 발견하는 viewWillLayoutSubviews()에서 ```
	self.isModalInPresentation = true``` 추가 -> dismiss가 되지 않는다.
	- ```navigationController?.presentationController?.delegate = self ```프로토콜 채택 후 아래 코드 적용
		```
		func presentationControllerDidAttemptToDismiss(_ presentationController: UIPresentationController) {
		// 데이터가 있거나 데이터가 변경됐을 때 분기 필요
		showDismissAlert()
		}
		```
![UIPresentationController](https://user-images.githubusercontent.com/51053410/190390855-364def39-e2aa-43c0-9484-c536fb7e7b86.png)

- **카테고리, 핏, 만족도 섹션 구현**
	- 각 화면 구성 및 accessoryType -> checkmask 적용
- **각 텍스트필드 입력 항목에 따른 키보드 타입 변경 구현**
- **textView placeholder 구현**
- **iOS 14 모던 테이블뷰 셀 UIcontentConfiguration 으로 content text 구현**

## 발생했던 문제
- 선택한 checkmask만 표시되게끔 할 때 이미 선택한 셀의 체크항목도 지워지는 문제점 발견
	- didSelectRowAt, didDeselectRowAt에 accessoryType 분기하였고, isSelected 구문을 추가하니 체크항목이 지워지는 문제는 해결되었다. 하지만 왜 isSeleted 구문을 지우면 체크항목이 재사용될 때마다 다시 지워지는지는 모르겠다. isSeleted 구문을 작성하면 재사용이 되어도 해당 cell의 isSeleted 값이 저장되는 것일까?
<img width="687" alt="선택 또는 선택하지 않았을 때 accessoryType 분기 구문" src="https://user-images.githubusercontent.com/51053410/190393730-e7f878fa-1960-431c-9199-a5ef2587ce47.png">
<img width="540" alt="isSelected 오버라이딩 구문" src="https://user-images.githubusercontent.com/51053410/190393740-4b349db2-341d-4840-9185-26639f702cc1.png">

- 선택한 카테고리 항목 값을 가져오고 싶은데 cell.defaultContentConfiguration().attributedText 값을 불러오는 방법을 모르겠다. 아래 그림처럼 저 신발 이라는 값을 어떻게 가져와서 이전 화면에 보여줄 수 있을까
  <img width="297" alt="카테고리 선택 화면" src="https://user-images.githubusercontent.com/51053410/190390999-997909ae-9592-4fe5-a30f-636259e46ca1.png">

- 선택한 Cell의 백그라운드를 없애고 싶어 didDeselectRowAt 메소드를 didselected 메소드 내부에 호출했더니 cell이 클릭하자마자 회색 배경이 없어지는 것을 확인 -> 하지만 isSelected도 초기화가 되었는지 여러 Cell을 터치하면 checkmask 표시가 뜨는 문제가 발생 
	- https://sweetdev.tistory.com/105 (참고)
	- 일단 style을 .none으로 설정하여 처리
  
---
# 9월 10일 진행 내용
- **실측 사이즈 정보 스택뷰로 구성**
![메인화면 디자인ver2](https://user-images.githubusercontent.com/51053410/190390286-06a58117-d9e8-4b71-943f-6dda1d3107a5.png)

- **메인 화면 실측 사이즈 제거하고, 사이즈, 핏, 후기 정보만 표기하도록 수정**
![메인화면 디자인ver3](https://user-images.githubusercontent.com/51053410/190390305-08d0a6c6-3a96-4dd1-89bd-4e4e2f8d2408.png)

- **메인 화면 사이즈 Label 한 줄 표기 및 브랜드 추가**
![메인화면 디자인ver4](https://user-images.githubusercontent.com/51053410/190390319-18fd7b6e-0d9c-4887-bf40-30891fa23157.png)

- **테이블 뷰 셀 내부에 Label로 섹션 타이틀로 보여주었던 부분을 테이블 뷰 섹션 타이틀로 수정**

# 발생했던 문제
- 실측 사이즈를 메인 화면에 보여주는 목적으로 디자인을 구성했으나, 카테고리 별로 필요한 실측 사이즈가 달라서 모두 대응하기에는 어려움이 있었다.
	- 예: 상의, 하의, 모자, 가방, 신발 등등 각각 필요한 실측 사이즈가 다르다.

- 아이폰 SE에서 레이블 해상도가 깨지는 문제가 발견
		 ``` view.adjustsFontSizeToFitWidth = true ```
		``` view.minimumScaleFactor = (최소사이즈)/(현재사이즈) ```
	- 디바이스 사이즈에 따라 동적으로 줄여주는 위 코드를 사용하여 수정함.
---
# 9월 9일 진행 내용
- **테이블뷰 Cell 내부, 컬렉션뷰 및 컬렉션뷰 Cell 구현**

# 발생했던 문제
- 네비게이션 Large Title leading이 테이블뷰 헤더 섹션 뷰, 컬렉션 뷰 leading 값이 다른 문제 발견
	- `self.navigationController?.systemMinimumLayoutMargins.leading`를 사용해 네비게이션 라지 타이틀 리딩 값을 구해, 테이블뷰 헤더 섹션 뷰, 컬렉션 뷰 item insert leading 값에 할당함
- 카테고리 타이틀을 섹션 별로 나눌 것인지, 하나의 섹션으로 관리 여부
![메인화면 디자인ver1](https://user-images.githubusercontent.com/51053410/190389859-d073b8e6-e7dc-4a2a-82eb-f503f2328e49.png)

---
# 9월 8일 진행 내용
- **.gitignore 파일 생성**
	- 환율 API 고려
- **아이콘**
	- 가방: suitcase.fill 또는 bag.fill
	- 옷: tshirt.fill
	- 보관함: square.stack.fill
	- 설정: gearshape.fill
	- TinColor: https://www.schemecolor.com/hermes-logo-color.php
- **네비게이션, 탭바 색상**
	- 모든 네비게이션, 탭바 색상 변경 방법
		```
		func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {

		UINavigationBar.appearance().barTintColor = .customBackgroundColor
		UITabBar.appearance().barTintColor = .customBackgroundColor
		
		return true
		}
		```
- **테이블 뷰, 컬렉션 뷰 틀 구현**
- **+ 버튼 누를 시 등록 화면 뷰만 구현**

# 발생했던 문제
- **TableView Style에 따라 달라지는 HeaderView 스크롤 형식**
	- `.plain` Style 일 때, Cell 스크롤 여부와 상관없이 HeaderView 고정
![plain style](https://user-images.githubusercontent.com/51053410/190393227-d19a8bda-a73c-4834-b593-11b4b53ff4e5.gif)
	- `.insetGrouped` Style 일 때, Cell 스크롤과 함께 이동
![insetGrouped style](https://user-images.githubusercontent.com/51053410/190393242-7366bd38-fce2-4853-9e70-eda058a057d3.gif)

	```
	let view = UITableView(frame: .zero, style: .plain)
	let view = UITableView(frame: .zero, style: .insetGrouped)
	```
- HeaderView를 self.mainView 또는 self.ContentView에 addSubView 또는 Constraint 하는 것에 따라 정렬 위치가 달라진다. 주의하자.
